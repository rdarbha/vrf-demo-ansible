# vim: tabstop=4 shiftwidth=4 softtabstop=4
# Copyright 2016 Cumulus Networks, Inc. All rights reserved.
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc.
# 51 Franklin Street, Fifth Floor
# Boston, MA  02110-1301, USA.
from __future__ import absolute_import

from ConfigParser import NoSectionError, RawConfigParser

from netq.common.enums import DefaultPaths


class Field(object):
    """ Field object.
    """
    def __init__(self, default, reloadable=False, nullable=False):
        self.name = None
        self.section = None
        self.default = default
        self.reloadable = reloadable
        self.nullable = nullable

    def __call__(self, value):
        """ Validates the value passed to this method.
        Derived classes can override this function to provide custom
        validation.
        """
        return value

    def tostr(self, value):
        """ Returns a display friendly value.
        Derived classes can override this method to provide custom
        behavior.
        """
        # pylint: disable=no-self-use
        return value


class BooleanField(Field):

    def __call__(self, value):
        try:
            return str(value).lower() in ('1', 'on', 'yes', 'true')
        except Exception:  # pylint: disable=broad-except
            raise RuntimeError('Invalid boolean value %s' % value)


class IntegerField(Field):

    def __call__(self, value):
        try:
            return int(value)
        except Exception:  # pylint: disable=broad-except
            raise RuntimeError('Invalid integer value %s' % value)


class _ConfigMeta(type):
    """ Meta class that sets the section and name on an instance of
    ConfigField.
    """
    def __new__(mcs, name, bases, class_dict):
        for key, value in class_dict.items():
            if isinstance(value, Field):
                value.name = key
                value.section = class_dict['section']
        return type.__new__(mcs, name, bases, class_dict)


class Config(object):
    """ Generic Config class.
    """
    class CommonConfig(object):
        """ Common configuration parameters.
        """
        __metaclass__ = _ConfigMeta
        section = 'common'
        concurrency = IntegerField(default=1000)
        debug = BooleanField(default=False)
        dbconfig = Field(default=DefaultPaths.DBCONFIG)
        eventlet_backdoor_port = IntegerField(default=9001)
        logdest = Field(default='/var/log/netq-agent.log')
        logbackupcount = IntegerField(default=14)
        logfilesize = IntegerField(default=512000)
        loglevel = Field(default='INFO')
        server = Field(default=None)
        udsfile = Field(default=DefaultPaths.UDS_FILE)

    def __init__(self, config_file):
        self.__params = self.__get_fields(self.CommonConfig)
        default_dict = {field.name: field.default for field in self.__params}
        self.__config_file = config_file
        self.__config_parser = RawConfigParser(defaults=default_dict,
                                               allow_no_value=True)
        self.__config_parser.read([self.__config_file])
        for section in self.__config_parser.sections():
            mysection = next((cls for cls in [self.CommonConfig]
                              if cls.section == section), None)
            if mysection is None:
                raise RuntimeError('Invalid section %s' % section)
            myoptions = [option.name
                         for option in vars(mysection).itervalues()
                         if isinstance(option, Field)]
            for option in self.__config_parser._sections[section]: # pylint: disable=protected-access
                if option == '__name__':
                    continue
                if option not in myoptions:
                    raise RuntimeError(
                        'Invalid option %s in section %s' % (option, section)
                    )
        for field in self.__params:
            try:
                value = self.__config_parser.get(field.section, field.name)
            except NoSectionError:
                value = field.default
            setattr(self, field.name, field(value))

    @staticmethod
    def __get_fields(class_):
        """ Returns a set of ConfigField objects for a class.
        """
        return {
            field for field in class_.__dict__.itervalues()
            if isinstance(field, Field)
        }

    def set_field(self, section, option, value):
        """ Sets a field in the configuration file.
        """
        if not self.__config_parser.has_section(section):
            self.__config_parser.add_section(section)
        self.__config_parser.set(section, option, value)
        with open(self.__config_file, 'wb') as configfile:
            self.__config_parser.write(configfile)
