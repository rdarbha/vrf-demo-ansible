-- vim: tabstop=4 shiftwidth=4 softtabstop=4
-- Copyright 2016 Cumulus Networks, Inc. All rights reserved.
--
-- This program is free software; you can redistribute it and/or
-- modify it under the terms of the GNU General Public License
-- as published by the Free Software Foundation; either version 2
-- of the License, or (at your option) any later version.
--
-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
--
-- You should have received a copy of the GNU General Public License
-- along with this program; if not, write to the Free Software
-- Foundation, Inc.
-- 51 Franklin Street, Fifth Floor
-- Boston, MA  02110-1301, USA
function count_script()
    local key_idx, tmp1, tmp2
    local result = {}
    for key_idx = 1, #KEYS do
        tmp1 = redis.call("ZRANGE", KEYS[key_idx], -1, -1, "WITHSCORES")
        tmp2 = redis.call("ZREVRANGE", KEYS[key_idx], -1, -1, "WITHSCORES")
        result[#result + 1] = {KEYS[key_idx],
                               redis.call("ZCARD", KEYS[key_idx]),
                               tmp2[2],
                               tmp1[2]}
    end
    return result
end

function delregex_script()
    local new_score = ARGV[1]
    local purge = ARGV[2]
    local tmp, score, val, val_json
    local updated = {}
    for idx = 1, #KEYS do
        tmp = redis.call("ZRANGE", KEYS[idx], -1, -1, "WITHSCORES")
        val = tmp[1]
        score = tmp[2]
        if val ~= nil then
            if purge == 1 then
                redis.call("DEL", KEYS[idx])
            else
                val_json = cjson.decode(val)
                if val_json["active"] ~= "0" then
                    val_json["active"] = "0"
                    val_json["timestamp"] = new_score
                    redis.call("ZADD", KEYS[idx], new_score, cjson.encode(val_json))
                    updated[#updated + 1] = {KEYS[idx], score, val}
                    updated[#updated + 1] = {KEYS[idx], new_score, cjson.encode(val_json) }
                else
                    tmp = redis.call("ZRANGE", KEYS[idx], -2, -2, "WITHSCORES")
                    if tmp[1] ~= nil then
                        updated[#updated + 1] = {KEYS[idx], tmp[2], tmp[1]}
                    end
                    updated[#updated + 1] = {KEYS[idx], score, val}
                end
            end
        end
    end
    return updated
end

function gc_script()
    local now = math.floor(ARGV[1])
    local freed = 0
    local tmp, tmp1, tmp2, key1, idx, idx1
    for index = 1, #KEYS do
        local counters = {}
        tmp = redis.call("ZRANGE", KEYS[index], 0, 10000, "WITHSCORES")
        -- always preserve the latest, the last index in the array is the latest
        -- score
        local latest = 0
        if tmp[#tmp] then
           latest=math.ceil(tmp[#tmp])
        else
           latest=now
        end

        for idx=1, #tmp, 2 do
            local score = tmp[idx + 1]
            local ago = now - score
            if ago > 60 * 60 then
               tmp1 = math.floor(ago / (60 * 60) + 1)
               tmp2 = math.floor(now - (tmp1 - 1) * (60 * 60))
               if tmp2 >= latest then
                  tmp2 = latest - 1
               end
               key1 = tmp1..'h'
            elseif ago > 60 then
               tmp1 = math.floor(ago / 60 + 1)
               tmp2 = math.floor(now - (tmp1 - 1) * 60)
               if tmp2 >= latest then
                  tmp2 = latest - 1
               end
               key1 = tmp1..'m'
            else
               tmp1 = math.floor(ago + 1)
               tmp2 = math.floor(now - (tmp1 - 1))
               if tmp2 >= latest then
                  tmp2 = latest - 1
               end
               key1 = tmp1..'s'
            end
            if counters[key1] ~= 1 then
               freed = freed + redis.call("ZCOUNT", KEYS[index], '('..score, tmp2)
               redis.call("ZREMRANGEBYSCORE", KEYS[index], '('..score, tmp2)
               counters[key1] = 1
            end
        end
    end
    return freed
end

function keys_script()
    local match = KEYS[1]
    local tmp, keys
    local cur = 0
    local result = {}
    repeat
        tmp = redis.call("SCAN", cur, "MATCH", match)
        cur = tonumber(tmp[1])
        keys = tmp[2]
        if keys ~= nil then
            for idx = 1, #keys do
                result[#result + 1] = keys[idx]
            end
        end
    until cur == 0
    return result
end

function lpm_script()
    -- Perform a LPM against the prefix.
    -- a. Start by constructing a regex assuming keys are of a fixed format.
    -- b. In every iteration of the outer loop, we perform the logical
    --    equivalent of right shifting (by 8/16) the prefix string and
    --    decrementing the mask by 8/16 till
    --    i. all the bits in the prefix string have been zeroed out, or
    --   ii. a LPM for the hostnames passed to this method has been found
    -- c. In the inner loop, we iterate over the Routes in the database
    --    extracting the prefix, mask and hostname using the regex from a.
    --    Subsequently, we match the prefix and mask against the prefix and
    --    mask from b. If a match is found, we extract the score
    --    and value for the key and store it as the LPM for that hostname.
    local hostnames = KEYS
    local match = ARGV[1]
    local input_prefix = ARGV[2]
    local start_time = ARGV[3]
    local is_ipv6 = tonumber(ARGV[4])
    local seperator = ARGV[5]

    -- Expand the prefix if it is IPv6
    if is_ipv6 == 1 then
        input_prefix = utils.expand_ipv6(input_prefix)
    end

    -- Regex construction
    local ipv4seg = "%d%d?%d?"
    local ipv6seg = "[0-9a-fA-F]?[0-9a-fA-F]?[0-9a-fA-F]?[0-9a-fA-F]?:?:?"
    local remask = "%d+"
    -- We assume the hostname comes before the IP address
    local reipv4addr = string.format(seperator.."(.+)"..seperator.."(%s)/(%s)"..seperator.."(%s)"..seperator.."(%s)"..seperator,
                                     string.rep(ipv4seg.."%.", 3)..ipv4seg,
                                     remask,
                                     "%d+", "%d+")
    local reipv6addr = string.format(seperator.."(.+)"..seperator.."(%s)/(%s)"..seperator.."(%s)"..seperator.."(%s)"..seperator,
                                     string.rep(ipv6seg, 8),
                                     remask,
                                     "%d+", "%d+")

    -- Variable initialization
    local src_prefix_len, src_prefix_inc
    if is_ipv6 == 1 then
        src_prefix_len = 128
        src_prefix_inc = 16
    else
        src_prefix_len = 32
        src_prefix_inc = 8
    end

    local tmp, longest_key, longest_val, longest_score, h, t
    local results = {}
    local found = {}
    local key = string.gsub(match, "(%/%d?%d?)$", "")
    local prefix_len = src_prefix_len
    local prefix_str = input_prefix
    while prefix_len >= 0 do
        prefix_len = prefix_len - src_prefix_inc
        prefix_str = utils.sub_prefix(prefix_str, is_ipv6)
        local new_key = string.gsub(key, seperator..input_prefix, seperator..prefix_str)
        local cur = 0
        repeat
            tmp = redis.call("SCAN", cur, "MATCH", new_key)
            cur = tonumber(tmp[1])
            local keys = tmp[2]
            local hostname, prefix, mask, rtype, val_json, table, found_key
            if keys then
                for idx = 1, #keys do
                    if is_ipv6 == 1 then
                        hostname, prefix, mask, rtype, table = string.match(keys[idx], reipv6addr)
                    else
                        hostname, prefix, mask, rtype, table = string.match(keys[idx], reipv4addr)
                    end
                    mask = tonumber(mask)
                    if table then
                        -- Broadcast routes are of type 3
                        found_key = hostname.."+"..table
                        if hostname ~= nil and prefix ~= nil and mask ~= nil and tonumber(rtype) ~= 3 and
                                mask >= prefix_len and mask <= prefix_len + src_prefix_inc and
                                utils.is_match(prefix, input_prefix, mask, is_ipv6) and
                                (found[found_key] == nil or mask > found[found_key][1])
                        then
                            longest_key = keys[idx]
                            tmp = redis.call("ZREVRANGEBYSCORE", longest_key, start_time, 0, "WITHSCORES")
                            if tmp[1] then
                                longest_val = tmp[1]
                                longest_score = tmp[2]
                                val_json = cjson.decode(longest_val)
                                if val_json["active"] == "1" then
                                    found[found_key] = {mask, longest_key, longest_val, longest_score}
                                end
                            end
                        end
                    end
                end
            end
        until cur == 0
    end

    for k, v in pairs(found) do
        for idx = 1, #hostnames do
            h, t = string.match(k, "(.*)".."(+)"..("%d+"))
            if h == hostnames[idx] then
                longest_key = v[2]
                longest_val = v[3]
                longest_score = v[4]
                results[#results + 1] = {longest_key, longest_val, longest_score }
                break
            end
        end
    end

    return results
end

function scanregex_script()
    local match = KEYS[1]
    local nmatch = KEYS[2]
    local cur = tonumber(KEYS[3])
    local count = KEYS[4]
    local rangeapi = ARGV[1]
    local rangestart = ARGV[2]
    local rangeend = ARGV[3]
    local first = tonumber(ARGV[4])
    local rep = {}
    local tmp, keys
    repeat
        tmp = redis.call("SCAN", cur, "MATCH", match)
        cur = tonumber(tmp[1])
        keys = tmp[2]
        if keys then
            for idx = 1, #keys do
                local key_type = redis.call("TYPE", keys[idx])
                if type(key_type) == "table" then
                    -- hacky conversion from table to string
                    for _, tmp in pairs(key_type) do
                        key_type = tmp
                    end
                end
                if nmatch == ".*" or not keys[idx]:find(nmatch) then
                    if key_type == "set" or key_type == "string" then
                        rep[#rep + 1] = {keys[idx], redis.call("GET", keys[idx]), 0}
                    elseif key_type == "hash" then
                        tmp = redis.call("HGETALL", keys[idx])
                        for index = 1, #tmp do
                            rep[#rep + 1] = {keys[idx], tmp[index], 0}
                        end
                    elseif key_type == "zset" then
                        tmp = redis.call(rangeapi, keys[idx], rangestart, rangeend, "WITHSCORES")
                        for index=1, #tmp, 2 do
                            rep[#rep + 1] = {keys[idx], tmp[index], tmp[index + 1]}
                            if first == 1 then
                                break
                            end
                        end
                    end
                end
            end
        end
    until cur == 0 or (count and #rep == tonumber(count))
    return {cur, rep}
end

function update_counters_script()
    local now = ARGV[1]
    local tmp, key_idx
    local output = {}
    for key_idx=1, #KEYS do
        local key = KEYS[key_idx]
        tmp = redis.call("ZREVRANGE", key, -10000, -1, "WITHSCORES")
        local idx
        local values = {}
        for idx=1, #tmp, 2 do
            local count = tonumber(tmp[idx + 1])
            if count ~= 0 then
                local val_json = cjson.decode(tmp[idx])
                val_json[ARGV[1 + key_idx + #KEYS]] = tmp[idx + 1]
                values[#values + 1] = val_json
            end
        end
        output["data"] = values
        redis.call("ZADD", ARGV[1 + key_idx], now, cjson.encode(output))
    end
end
