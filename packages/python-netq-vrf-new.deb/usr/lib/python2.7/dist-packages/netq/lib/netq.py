# vim: tabstop=4 shiftwidth=4 softtabstop=4
# Copyright 2016 Cumulus Networks, Inc. All rights reserved.
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc.
# 51 Franklin Street, Fifth Floor
# Boston, MA  02110-1301, USA.
from __future__ import absolute_import

import calendar
import json
import re
import socket
import sys
import time
from datetime import datetime, timedelta

import ipaddr
from tabulate import tabulate

from netq.common import config, utils
from netq.common.enums import (
    BgColors,
    Heartbeat,
    DefaultPaths,
    LinkType,
    RouteType,
    InterfaceState
)
from netq.lib import parsers
from netq.orm import HOSTNAME
from netq.orm import redisdb, restapi
from netq.orm.memdb.models import (
    Lldp
)
from netq.orm.redisdb.models import (
    Address,
    BgpSession,
    ClagSession,
    Command,
    Counter,
    CounterHistory,
    Link,
    MacFdb,
    MstpInfo,
    Neighbor,
    Node,
    OspfNbr,
    Route,
    Services,
    OS,
    CPU,
    ASIC,
    Board,
    Disk,
    Memory,
)
from netq.orm.redisdb.query import RedisQuery


class AgentHealth(object):

    ROTTEN = 'Rotten'
    STALE = 'Stale'
    FRESH = 'Fresh'

    def __init__(self):
        raise NotImplementedError


class MstpStatus(object):
    """A class just to keep the status straight
    """
    BPDUGUARD_ERR = 1
    DISPUTED = 2
    BA_INCONSISTENT = 3
    TCN = 4


def get_hostname():
    # deal with -s <server-ip>|<hostname> view [around <time>] <host> <cmd>
    if sys.argv[1] == 'server':
        offset = 2
    else:
        offset = 0
    if sys.argv[offset + 1] == 'view':
        if sys.argv[offset + 2] == 'around':
            hostname = sys.argv[offset + 4]
        else:
            hostname = sys.argv[offset + 2]
    elif sys.argv[offset + 2] in ['interfaces', 'lldp', 'macs', 'addresses']:
        hostname = sys.argv[offset + 3]
    elif (sys.argv[offset + 2] in ['ip', 'ipv6'] and
          sys.argv[offset + 3] in ['neighbors', 'routes']):
        hostname = sys.argv[offset + 4]
    else:
        # all other commands have the hostname just before the
        # current arg
        hostname = sys.argv[-2]
    return hostname


class NetQException(Exception):
    def __init__(self, *args, **kwargs):
        super(NetQException, self).__init__(*args, **kwargs)


class NetQ(object): # pylint: disable=too-many-public-methods
    __INTF_REGEX = re.compile(
        r'^\d+: (?P<dev_name>\S+):\s+'
        r'<.*(?P<slave>SLAVE).*>'
        r'(?=.*inet (?P<ipv4>\S+) scope (?P<scopev4>\S+))'
        r'(?=.*inet6 (?P<ipv6>\S+) scope (?P<scopev6>\S+))'
        r'(?=.*master (?P<master>\S+))'
        r'(?=.*link/ether (?P<mac>\S+))'
    )

    __IP_ADDR_REGEX = re.compile(
        r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}(?:/\d+)?'
    )

    __TIME_REGEX = re.compile(
        r'(?:(?:(?P<days>[\d|.]+)d)|'
        r'(?:(?P<hours>[\d|.]+)h)|'
        r'(?:(?P<minutes>[\d|.]+)m)|'
        r'(?:(?P<seconds>[\d|.]+)s))'
    )

    __TRACEROUTE_REGEX = r'\s*(?P<idx>\d+).*'

    __VRR_IFACE_REGEX = r'(.*\d+)-v0\Z'

    ADDR_KEY = 'addr'
    BGP_SUMMARY_KEY = 'bgp-summary-json'
    BGP_NEIGHBOR_KEY = 'bgp-neighbors'
    CLAGCTL_JSON_KEY = 'clagctl-json'
    LLDP_NEIGHBOR_KEY = 'lldp-neighbor-json'
    UPTIME_KEY = 'uptime'
    MEMINFO_KEY = 'meminfo'

    def __init__(self, server_addr, start_time, end_time):
        self.__node_lst = None
        self.failed_node_lst = {}
        self.vrf_table_map = {}

        self.__server_addr = (
            self.__get_server_address(server_addr) or
            self.__get_config_server_addr()
        )

        self.__start_time = self.__get_time(start_time)
        self.__end_time = self.__get_time(end_time)
        if (self.__start_time is not None and self.__end_time is not None and
                self.__start_time <= self.__end_time):
            raise RuntimeError('Start time %s should be less than end '
                               'time %s' % (start_time, end_time))
        if self.__server_addr is not None and 'http' in self.__server_addr:
            restapi.set_connection_settings(self.__server_addr)
        else:
            redisdb.set_connection_settings(self.__server_addr)

    def __build_failed_node_lst(self):
        """Build list of nodes that have rotten state
        """
        self.failed_node_lst = {}
        for node in self.node_lst:
            last_beat = (datetime.utcnow() -
                         datetime.utcfromtimestamp(node.timestamp))
            if last_beat.total_seconds() > Heartbeat.HEARTBEAT_DEATH:
                if (not self.__start_time or
                        (node.timestamp <= self.__start_time)):
                    self.failed_node_lst[node.hostname] = 1000 * node.timestamp

    def __build_lldp_info(self, hostname=None):
        self.__build_failed_node_lst()

        if hostname is not None:
            nodes = sorted(Node.query.filter(hostname=hostname))
        else:
            nodes = self.node_lst

        for node in nodes:
            cmd = Command.query.get(timestamp=self.__start_time,
                                    key=NetQ.LLDP_NEIGHBOR_KEY,
                                    hostname=node.hostname)
            if cmd is not None:
                try:
                    parsers.build_lldp_summary(node.hostname, cmd.timestamp,
                                               cmd.output)
                except Exception:  # pylint: disable=broad-except
                    continue

    @staticmethod
    def __get_config_server_addr():
        try:
            conf = config.Config(DefaultPaths.CONF_FILE)
            if conf.server:
                return conf.server
        except Exception:  # pylint: disable=broad-except
            pass
        try:
            with open(DefaultPaths.DBCONFIG_RUNNING, 'r') as fd:
                base_config_json = json.load(fd)
                if 'server' in base_config_json:
                    return (
                        str(ipaddr.IPv4Network(base_config_json['server']).ip)
                    )
        except Exception:  # pylint: disable=broad-except
            raise RuntimeError('Please specify IP address of DB server')

    @staticmethod
    def __get_server_address(server_addr):
        try:
            return str(ipaddr.IPAddress(server_addr))
        except Exception:  # pylint: disable=broad-except
            try:
                return socket.gethostbyname(server_addr)
            except Exception:  # pylint: disable=broad-except
                return server_addr

    def __get_time(self, start_time):
        if start_time is None:
            return start_time
        match = self.__TIME_REGEX.match(start_time)
        if match is not None:
            groupdict = match.groupdict()
            return calendar.timegm(
                (
                    datetime.utcnow() -
                    timedelta(
                        days=float(groupdict['days'] or 0),
                        hours=float(groupdict['hours'] or 0),
                        minutes=float(groupdict['minutes'] or 0),
                        seconds=float(groupdict['seconds'] or 0)
                    )
                ).utctimetuple()
            )
        try:
            return calendar.timegm(
                datetime.strptime(start_time,
                                  '%Y-%m-%dT%H:%M:%S.%fZ').utctimetuple()
            )
        except Exception:  # pylint: disable=broad-except
            try:
                return calendar.timegm(
                    datetime.strptime(start_time, '%Y-%m-%d').utctimetuple()
                )
            except Exception:  # pylint: disable=broad-except
                try:
                    datetime.utcfromtimestamp(start_time)
                    return start_time
                except Exception:  # pylint: disable=broad-except
                    raise RuntimeError('Time format %s not understood' %
                                       start_time)

    def __top_talkers(self, count, keys):
        output = {}
        prefixes = ['if_', 'if_drop_', 'if_err_']
        for key, prefix in zip(keys, prefixes):
            if self.__start_time is not None:
                qry = CounterHistory.query.filter(timestamp=self.__start_time,
                                                  key_type=key)
                results = []
                if qry is not None:
                    data = next(qry, None)
                    if data is not None:
                        idx = 0
                        for ele in data.data:
                            scorefmt = Counter.score_fmt(key_type=key)
                            score = scorefmt.from_redis(ele.get(scorefmt.name))
                            obj = Counter.val_to_obj(json.dumps(ele))
                            obj = Counter.score_to_obj(score, key_type=key,
                                                       obj=obj)
                            obj.timestamp = data.timestamp
                            results.append(obj)
                            idx += 1
                            if idx == count:
                                break
            else:
                results = list(Counter.query.range(start=0,
                                                   end=count,
                                                   reverse=True,
                                                   key_type=key,
                                                   active=True,
                                                   first=False))
            output[prefix + 'bps'] = []
            output[prefix + 'ts'] = None
            if results:
                score_fmt = Counter.score_fmt(key_type=key)
                output[prefix + 'bps'] = [
                    (ele.hostname, ele.ifname, getattr(ele, score_fmt.name))
                    for ele in results if getattr(ele, score_fmt.name)
                ]
                if output[prefix + 'bps']:
                    output[prefix + 'ts'] = results[0].timestamp
        return output

    def __get_slaves(self, hostname, ifname):
        """Get slaves of given interface"""

        slaves = []
        for link in Link.query.filter(timestamp=self.__start_time,
                                      endtimestamp=self.__end_time,
                                      hostname=hostname, master=ifname):
            if link.ifname != ifname:
                slaves.append(link.ifname)

        return slaves

    def __get_lldp_nbr_entry(self, hostname, ifname):
        """
        Retrieve the LLDP neighbor entry for the specified interface.
        The specified interface can be a bond as well
        """
        nbr = None
        link = Link.query.get(timestamp=self.__start_time,
                              hostname=hostname, ifname=ifname)
        if not link:
            return nbr

        if link.kind == 'bond':
            for slave in self.__get_slaves(hostname, ifname):
                slave = slave.encode('ascii', 'ignore')
                nbr = Lldp.query.get(timestamp=self.__start_time,
                                     hostname=hostname, ifname=slave)
                if nbr:
                    break
        else:
            nbr = Lldp.query.get(timestamp=self.__start_time,
                                 hostname=hostname, ifname=ifname)

        return nbr

    @staticmethod
    def __compare_vlans(str1, str2):
        """Compare two VLAN list strings and return 0 if equal, else 1
        """
        list1 = []
        list2 = []

        for word in str1.split():
            if '-' in word:
                svlan, evlan = word.split('-')
                list1 += range(int(svlan), int(evlan) + 1)
            else:
                list1 += [int(word)]

        for word in str2.split():
            if '-' in word:
                svlan, evlan = word.split('-')
                list2 += range(int(svlan), int(evlan) + 1)
            else:
                list2 += [int(word)]

        return sorted(list1) == sorted(list2)

    def __get_stp_root(self, root_brmac):
        """Given a root bridge ID, get the root switch name
        """
        root_swname = None
        entries = self.show_macvlan(root_brmac, '*', '*', '*', True)
        try:
            entry = entries.next()
            root_swname = entry[0][2]
        except StopIteration:
            # When doing CLAG, the bridge ID is the CLAG sysmac
            entry = ClagSession.query.get(timestamp=self.__start_time,
                                          clag_sysmac=root_brmac)
            if entry:
                root_swname = entry.hostname

        return root_swname

    def __get_parent_bond(self, hostname, slave_if):
        """Get parent bond interface if any
        """
        for port in Link.query.filter(timestamp=self.__start_time,
                                      hostname=hostname, ifname=slave_if):
            return port.master

        return None

    @staticmethod
    def __is_route_blackholed(route_type):
        """Will this route be dead in the water ?"""
        if (route_type == RouteType.RTN_BLACKHOLE or
                route_type == RouteType.RTN_PROHIBIT or
                route_type == RouteType.RTN_UNREACHABLE):
            return True

        return False

    def __get_clag_peer_hostname(self, this_host, clag_peer_if):

        peername = '*'
        if '.' in clag_peer_if:
            peer_if = clag_peer_if.split('.')[0]
        else:
            peer_if = clag_peer_if
        lldp_peer = self.__get_lldp_nbr_entry(this_host, peer_if)
        if lldp_peer:
            peername = lldp_peer.peer_hostname

        return peername

    def __mtu_match(self, mtu, hostname, ifname):
        """Check if the link matches the MTU specified"""
        link = Link.query.get(timestamp=self.__start_time,
                              hostname=hostname, ifname=ifname)
        if not link or link.mtu == mtu:
            return True

        return False

    def __get_link_details(self, link):
        """Get link details
        """
        default_output_types = [LinkType.SWP, LinkType.ETH, LinkType.LOOPBACK,
                                LinkType.VLAN]
        details = ''
        if any(link.kind == i for i in default_output_types):
            lldp_string = ''
            lldp_peer = Lldp.query.get(self.__start_time,
                                       hostname=link.hostname,
                                       ifname=link.ifname)

            if lldp_peer is not None:
                lldp_string = '%s:%s' % (lldp_peer.peer_hostname,
                                         lldp_peer.peer_ifname)
                details = 'LLDP: %s, MTU: %s' % (lldp_string, link.mtu)
            else:
                details = 'MTU:% s' % (link.mtu)
        elif link.kind == LinkType.BOND:
            details += ''
            for slave in self.__get_slaves(link.hostname, link.ifname):
                slave = slave.encode('ascii', 'ignore')
                lldp_peer = Lldp.query.get(self.__start_time,
                                           hostname=link.hostname,
                                           ifname=slave)
                if lldp_peer is not None:
                    lldp_string = '%s:%s' % (lldp_peer.peer_hostname,
                                             lldp_peer.peer_ifname)
                else:
                    lldp_string = ''

                details += 'Slave: %s(%s), ' % (slave, lldp_string)
            details += ('VLANs: %s, PVID: %s, Master: %s, MTU: %s' %
                        (link.vlans, link.access_vlan, link.master,
                         link.mtu))

        elif link.kind == LinkType.BRIDGE:
            mstp_session = MstpInfo.query.get(timestamp=self.__start_time,
                                              hostname=link.hostname,
                                              bridge_name=link.ifname)
            if mstp_session:
                rootbr = self.__get_stp_root(
                    mstp_session.root_bridge.split('.')[2]
                )
                if not rootbr:
                    rootbr = 'No Info'
                if rootbr != link.hostname:
                    rootport = mstp_session.root_port_name
                else:
                    rootport = 'N/A'
            else:
                rootbr = 'No Info'
                rootport = 'No Info'
            root_mbrs = ','.join([i.encode('ascii', 'ignore')
                                  for i in self.__get_slaves(link.hostname,
                                                             link.ifname)])
            details = (
                'Members: %s, Root Bridge: %s, Root port %s, MTU: %d' %
                (root_mbrs, rootbr, rootport, link.mtu)
            )
        elif link.kind == LinkType.VXLAN:
            details = ('VNI: %s, PVID: %s, Master: %s, VTEP: %s, MTU: %s' %
                       (link.vni, link.access_vlan, link.master,
                        link.localip, link.mtu))
        elif link.kind == LinkType.MACVLAN:
            details = 'MAC: %s, Mode: Private' % link.mac_address
        return details

    def __process_show_fdb_entry(self, macfdb, nexthop, origin, known_nodes):
        """Return the appropriate values we need for displaying MAC entries"""

        if macfdb.mac_address == '00:00:00:00:00:00':
            return None

        if nexthop != '*' and macfdb.nexthop != nexthop:
            return None

        # If peer is unknwon or not in our DB, we mark that too as the
        # origin
        if macfdb.dst:
            vtep_addr = Address.query.get(timestamp=self.__start_time,
                                          prefix=macfdb.dst)
            if vtep_addr:
                nexth = '%s:%s' %(macfdb.nexthop, vtep_addr.hostname)
            else:
                nexth = '%s:%s' %(macfdb.nexthop, macfdb.dst)
            nbr = None
        else:
            nbr = self.__get_lldp_nbr_entry(macfdb.hostname, macfdb.nexthop)
            nexth = macfdb.nexthop
            if nbr is None or nbr.peer_hostname not in known_nodes:
                macfdb.origin = True

        if origin != '*' and origin != macfdb.origin:
            return None

        if macfdb.vlan == 0:
            vlan = 'Intf'
        elif macfdb.vlan == -1:
            vlan = '??'
        else:
            vlan = macfdb.vlan
        return([macfdb.mac_address, vlan, macfdb.hostname,
                nexth, macfdb.origin, macfdb.timestamp])

    def __build_vrf_table_map(self, hostname):
        """Get VRF to table ID mapping for the network or specified host"""

        self.vrf_table_map = {}
        # No VRFs, just define the default tables for all known hosts
        for node in self.node_lst:
            self.vrf_table_map[node.hostname] = {}
            self.vrf_table_map[node.hostname]['vrf'] = (
                {'default': 254, 'local': 255}
            )
            self.vrf_table_map[node.hostname]['table'] = (
                {254: 'default', 255: 'local'}
            )

        if not hostname:
            hostname = '*'

        for link in Link.query.filter(timestamp=self.__start_time,
                                      hostname=hostname, kind='vrf'):
            if link.hostname not in self.vrf_table_map:
                # In case we catch a stale entry
                self.vrf_table_map[link.hostname] = {}
                self.vrf_table_map[link.hostname]['vrf'] = (
                    {'default': 254, 'local': 255}
                )
                self.vrf_table_map[link.hostname]['table'] = (
                    {254: 'default', 255: 'local'}
                )

            self.vrf_table_map[link.hostname]['vrf'][link.ifname] = int(
                link.rt_table_id)
            self.vrf_table_map[link.hostname]['table'][int(link.rt_table_id)] = \
                link.ifname

        return self.vrf_table_map

    def path_trace_mac(self, mac, vlan, start, top, visited_nodes):
        """
        """
        subtree = []
        infostr = None

        self.__build_lldp_info()
        self.__build_failed_node_lst()

        if not start:
            start = HOSTNAME

        for entry in MacFdb.query.filter(timestamp=self.__start_time,
                                         hostname=start,
                                         mac_address=mac,
                                         vlan=vlan):
            nexthop = entry.nexthop
            link = Link.query.get(timestamp=self.__start_time,
                                  hostname=entry.hostname,
                                  ifname=nexthop)

            if link and link.kind == LinkType.VXLAN:
                if not entry.dst:
                    # Sometimes entries get created before we've had a
                    # chance to get the remote dst port and correct vlan
                    ventry = MacFdb.query.get(timestamp=self.__start_time,
                                              hostname=start,
                                              mac_address=mac,
                                              vlan=0)
                    if ventry:
                        entry.dst = ventry.dst

            if link:
                if link.kind == LinkType.BOND:
                    for slave in self.__get_slaves(link.hostname, link.ifname):
                        nbrs = Lldp.query.filter(timestamp=self.__start_time,
                                                 hostname=entry.hostname,
                                                 ifname=slave)
                        peer_nif = '%s:%s' % (entry.hostname, slave)
                        for nbr in nbrs:
                            if nbr.peer_hostname in visited_nodes:
                                sys.stderr.write(
                                    utils.color_wrap(
                                        BgColors.RED,
                                        'Detected Bridging Loop. Node  %s '
                                        '(now via %s) visited twice.\n' %
                                        (nbr.peer_hostname, visited_nodes)
                                    )
                                )
                                subtree.append([
                                    {'node': '%s:%s' % (nbr.hostname,
                                                        nbr.ifname),
                                     'info': 'Error: Loop',
                                     'subtree': [{'node': nbr.peer_hostname,
                                                  'info': 'Error: Loop',
                                                  'subtree': ''}]}])
                                output = ([{'node': start,
                                            'info': None,
                                            'subtree': subtree}])
                                return output

                            # MTU check
                            old_infostr = infostr
                            if not self.__mtu_match(link.mtu, nbr.peer_hostname,
                                                    nbr.peer_ifname):
                                if infostr:
                                    infostr = 'Error: MTU mismatch, ' + infostr
                                else:
                                    infostr = 'Error: MTU mismatch'
                                sys.stderr.write(utils.color_wrap(
                                    BgColors.RED, 'MTU mismatch between '
                                    '%s:%s and %s:%s\n' % (link.hostname,
                                                           link.ifname,
                                                           nbr.peer_hostname,
                                                           nbr.peer_ifname)))
                            visited_nodes.add(link.hostname)
                            subtree.append([{'node': peer_nif, 'info': infostr,
                                             'subtree': self.path_trace_mac(
                                                 mac, vlan, nbr.peer_hostname,
                                                 False, visited_nodes)}])
                            visited_nodes.remove(link.hostname)
                            infostr = old_infostr
                            break
                        else:
                            subtree.append([{'node': peer_nif, 'subtree': ''}])
                elif link.kind == LinkType.VXLAN and entry.dst:
                    remotenodes = Address.query.filter(
                        timestamp=self.__start_time,
                        prefix=entry.dst
                    )
                    one_entry = False
                    peer_nif = '%s:%s' % (entry.hostname, entry.nexthop)
                    for rnode in remotenodes:
                        one_entry = True
                        vxlink = Link.query.get(timestamp=self.__start_time,
                                                hostname=rnode.hostname,
                                                kind=LinkType.VXLAN,
                                                vni=link.vni)
                        if vxlink:
                            old_infostr = infostr
                            if link.mtu != vxlink.mtu:
                                if infostr:
                                    infostr = 'Error: MTU mismatch, ' + infostr
                                else:
                                    infostr = 'Error: MTU mismatch'
                                sys.stderr.write(utils.color_wrap(
                                    BgColors.RED, 'MTU mismatch between '
                                    '%s:%s and %s:%s\n' % (link.hostname,
                                                           link.ifname,
                                                           nbr.peer_hostname,
                                                           nbr.peer_ifname)))
                            subtree.append([{'node': peer_nif,
                                             'info': infostr,
                                             'vtep': 'Ingress',
                                             'vni': link.vni,
                                             'subtree': self.path_trace_route(
                                                 entry.dst, entry.hostname,
                                                 vxlink.localip, None,
                                                 False, visited_nodes, mac,
                                                 vlan, vxlink.ifname)}])
                            infostr = old_infostr
                            break
                        else:
                            subtree.append([{
                                'node': peer_nif, 'info': infostr,
                                'subtree': [{
                                    'node': rnode.hostname,
                                    'info': None, 'subtree': None}]}])
                    if not one_entry:
                        subtree.append([{'node': entry.dst, 'subtree': ''}])

                else:
                    peer_nif = '%s:%s' % (entry.hostname, entry.nexthop)
                    nbrs = Lldp.query.filter(timestamp=self.__start_time,
                                             hostname=entry.hostname,
                                             ifname=entry.nexthop)
                    for nbr in nbrs:
                        if nbr.peer_hostname in visited_nodes:
                            sys.stderr.write(
                                utils.color_wrap(
                                    BgColors.RED,
                                    'Detected Bridging Loop. Node %s (now '
                                    'via %s) visited twice.\n'
                                    % (nbr.peer_hostname, nbr.peer_ifname)
                                )
                            )
                            subtree.append([{
                                'node': '%s:%s' % (nbr.peer_hostname,
                                                   nbr.ifname),
                                'info': 'Error: Loop',
                                'subtree': [{'node': nbr.peer_hostname,
                                             'info': 'Error: Loop',
                                             'subtree': ''}]
                            }])
                            output = ([{'node': start,
                                        'info': None,
                                        'subtree': subtree}])
                            return output

                        old_infostr = infostr
                        if not self.__mtu_match(link.mtu, nbr.peer_hostname,
                                                nbr.peer_ifname):
                            if infostr:
                                infostr = 'Error: MTU mismatch, ' + infostr
                            else:
                                infostr = 'Error: MTU mismatch'
                            sys.stderr.write(utils.color_wrap(
                                BgColors.RED, 'MTU mismatch between '
                                '%s:%s and %s:%s\n' % (link.hostname,
                                                       link.ifname,
                                                       nbr.peer_hostname,
                                                       nbr.peer_ifname)))
                        visited_nodes.add(link.hostname)
                        subtree.append([{'node': peer_nif, 'info': infostr,
                                         'subtree': self.path_trace_mac(
                                             mac, vlan, nbr.peer_hostname,
                                             False, visited_nodes)}])
                        visited_nodes.remove(link.hostname)
                        infostr = old_infostr
                        break
                    else:
                        subtree.append([{'node': peer_nif, 'subtree': ''}])

        if not subtree:
            if not top:
                subtree.append([{'node': start, 'info': None, 'subtree': ''}])
        elif top:
            subtree = [{'node': start, 'info': None, 'subtree': subtree}]

        return subtree

    def path_trace_route(self, ip, start, srcip, vrf,
                         top, visited_nodes, mac, vlan,
                         remote_vxlink):
        """L3 control plane trace path
        """

        if top:
            self.__build_lldp_info()
            self.__build_failed_node_lst()
            self.__build_vrf_table_map(start)

        subtree = []
        is_ipv6 = ':' in ip
        table = '*'

        if vrf:
            if start in self.vrf_table_map:
                if vrf in self.vrf_table_map[start]['vrf']:
                    table = self.vrf_table_map[start]['vrf'][vrf]

        # We need a SRC IP address used in the trace to do reverse path check
        if top:
            if srcip and not start:
                nodes = [node.hostname for node in self.node_lst]
                rt_orig_entries = Route.query.lpm(srcip, nodes, table,
                                                  timestamp=self.__start_time,
                                                  is_ipv6=is_ipv6)
                for entry in rt_orig_entries:
                    if entry.origin:
                        start = entry.hostname
                        table = entry.rt_table_id
                        if not vrf and start in self.vrf_table_map:
                            vrf = self.vrf_table_map[start]['table'].get(table,
                                                                         '*')
                        break
                else:
                    raise NetQException(
                        'Unable to find source node for IP %s' % srcip)
            elif start and not srcip:
                # Maybe we can skip this because docopt will prevent an unknown
                # host from running
                for node in self.node_lst:
                    if start == node.hostname:
                        break
                else:
                    raise NetQException(
                        'Unable to find starting node %s' % start)
                # OK, now get the route entry from this node and see if a src
                # IP is specified
                rt_entry = Route.query.lpm(ip, [start], table,
                                           timestamp=self.__start_time,
                                           is_ipv6=is_ipv6)
                for entry in rt_entry:
                    if entry.src != 'None':
                        srcip = entry.src
                        break
                else:
                    # Need to handle VRF here
                    for addr in Address.query.filter(
                            timestamp=self.__start_time, hostname=start,
                            ifname='lo'):
                        if (addr.prefix.startswith('::1') or
                                (not is_ipv6 and addr.prefix.startswith(
                                    '127'))):
                            continue
                        else:
                            srcip = addr.prefix
                            break

        if not srcip or not start:
            raise NetQException(
                'Unable to find source/starting node for %s' % start)

        if mac:
            infostr = 'VxLAN L3'
        else:
            infostr = None

        # Verify that the srcip is reachable from this node
        if not top:
            for src_entry in Route.query.lpm(srcip, [start], table,
                                             timestamp=self.__start_time,
                                             is_ipv6=is_ipv6):
                if self.__is_route_blackholed(src_entry.route_type):
                    if infostr:
                        infostr = 'Error: Reverse path Blackholed, ' + infostr
                    else:
                        infostr = 'Error: Reverse path Blackholed'
                    sys.stderr.write(utils.color_wrap(
                        BgColors.RED,
                        'Reverse path to source %s blackholed from node %s\n'
                        %(srcip, start)))
                    break
                else:
                    break
            else:
                if infostr:
                    infostr = 'Error: No route to Reverse path, ' + infostr
                else:
                    infostr = 'Error: No route to Reverse path'
                sys.stderr.write(utils.color_wrap(BgColors.RED,
                                                  'No reverse path route to '
                                                  '%s from node %s\n' %
                                                  (srcip, start)))

        for entry in Route.query.lpm(ip, [start], table,
                                     timestamp=self.__start_time,
                                     is_ipv6=is_ipv6):

            if self.__is_route_blackholed(entry.route_type):
                if top:
                    subtree = [[{
                        'node': start, 'info': 'Blackhole',
                        'subtree': subtree}]]
                if subtree:
                    return subtree
                else:
                    return [[{
                        'node': start, 'info': 'Blackhole', 'subtree': ''}]]

            if entry.origin and mac:
                # We've reached the end of the L3 part
                subtree.append([{
                    'node': '%s:%s' % (start, remote_vxlink),
                    'info': None, 'vtep': 'Egress',
                    'subtree': self.path_trace_mac(
                        mac, vlan, start, False, visited_nodes)}])

                return subtree

            # Pick the preferred src IP address
            if top and entry.src != 'None':
                srcip = entry.src

            for nhop in entry.nexthops:
                nexthop = nhop[1].encode('ascii', 'ignore')
                link = Link.query.get(timestamp=self.__start_time,
                                      hostname=entry.hostname,
                                      ifname=nexthop)
                if link and link.kind == LinkType.VLAN:
                    link = Link.query.get(timestamp=self.__start_time,
                                      hostname=entry.hostname,
                                      ifname=link.parent_if)
                if link:
                    if link.kind == LinkType.BOND:
                        for slave in self.__get_slaves(link.hostname,
                                                       link.ifname):
                            nbrs = Lldp.query.filter(
                                timestamp=self.__start_time,
                                hostname=entry.hostname,
                                ifname=slave
                            )
                            peer_nif = '%s:%s' % (entry.hostname, slave)
                            for nbr in nbrs:
                                if nbr.peer_hostname in visited_nodes:
                                    sys.stderr.write(
                                        utils.color_wrap(
                                            BgColors.RED,
                                            'Detected Routing Loop. Node  %s '
                                            '(now via %s) visited twice.\n' %
                                            (nbr.peer_hostname, visited_nodes)
                                        )
                                    )
                                    subtree.append([
                                        {'node': '%s:%s' % (nbr.hostname,
                                                            nbr.ifname),
                                         'info': 'Error: Loop',
                                         'subtree': [[{'node': nbr.peer_hostname,
                                                       'info': 'Error: Loop',
                                                       'subtree': ''}]]}])
                                    output = ([{'node': start,
                                                'info': None,
                                                'subtree': subtree}])
                                    return output

                                # MTU check
                                old_infostr = infostr
                                if not self.__mtu_match(link.mtu,
                                                        nbr.peer_hostname,
                                                        nbr.peer_ifname):
                                    if infostr:
                                        infostr = (
                                            "Error: MTU mismatch, " + infostr)
                                    else:
                                        infostr = "Error: MTU mismatch"
                                    sys.stderr.write(utils.color_wrap(
                                        BgColors.RED, 'MTU mismatch between'
                                        ' %s:%s and %s:%s\n' % (
                                            link.hostname,
                                            link.ifname,
                                            nbr.peer_hostname,
                                            nbr.peer_ifname)))
                                visited_nodes.add(start)
                                subtree.append([{
                                    'node': peer_nif,
                                    'info': infostr,
                                    'subtree': self.path_trace_route(
                                        ip, nbr.peer_hostname, srcip, vrf,
                                        False, visited_nodes, mac, vlan,
                                        remote_vxlink)}])
                                visited_nodes.remove(start)
                                infostr = old_infostr
                                break
                            else:
                                subtree.append([{'node': peer_nif,
                                                 'info': infostr,
                                                 'subtree': ''}])
                    else:
                        nbrs = Lldp.query.filter(timestamp=self.__start_time,
                                                 hostname=entry.hostname,
                                                 ifname=link.ifname)
                        peer_nif = '%s:%s' % (entry.hostname, nexthop)
                        for nbr in nbrs:
                            if nbr.peer_hostname in visited_nodes:
                                sys.stderr.write(
                                    utils.color_wrap(
                                        BgColors.RED,
                                        'Detected Routing Loop. Node %s (now '
                                        'via %s) visited twice.\n'
                                        % (nbr.peer_hostname, nbr.peer_ifname)
                                    )
                                )
                                subtree.append([{
                                    'node': '%s:%s' % (nbr.peer_hostname,
                                                       nbr.ifname),
                                    'info': 'Error: Loop',
                                    'subtree': [[{
                                        'node': nbr.peer_hostname,
                                        'info': 'Error: Loop',
                                        'subtree': ''}]]}])
                                output = ([{'node': start,
                                            'info': None,
                                            'subtree': subtree}])
                                return output

                            # MTU check
                            old_infostr = infostr
                            if not self.__mtu_match(link.mtu, nbr.peer_hostname,
                                                    nbr.peer_ifname):
                                if infostr:
                                    infostr = "Error: MTU mismatch, " + infostr
                                else:
                                    infostr = "Error: MTU mismatch"
                                sys.stderr.write(utils.color_wrap(
                                    BgColors.RED, 'MTU mismatch between'
                                    ' %s:%s and %s:%s\n' % (link.hostname,
                                                            link.ifname,
                                                            nbr.peer_hostname,
                                                            nbr.peer_ifname)))
                            visited_nodes.add(start)
                            subtree.append([{
                                'node': peer_nif,
                                'info': infostr,
                                'subtree': self.path_trace_route(
                                    ip, nbr.peer_hostname, srcip, vrf, False,
                                    visited_nodes, mac, vlan, remote_vxlink)}])
                            visited_nodes.remove(start)
                            infostr = old_infostr
                            break
                        else:
                            subtree.append([{'node': peer_nif, 'info': infostr,
                                             'subtree': ''}])
                            break
                else:
                    subtree.append([{'node': '%s:%s' % (entry.hostname,
                                                        nexthop),
                                     'info': infostr, 'subtree': ''}])

        if not subtree:
            if not top:
                subtree.append([{'node': start, 'info': None, 'subtree': ''}])
        elif top:
            subtree = [{'node': start, 'sourceIP': srcip, 'from': start,
                        'info': None, 'subtree': subtree}]

        return subtree

    def build_stp_topo(self, node_at, brname, visit_peer, top, visited_nodes):
        """Generate the active spanning tree topology
        """

        peername = None

        # Lets get the peer node name if there's one
        entry = ClagSession.query.get(timestamp=self.__start_time,
                                      hostname=node_at)
        if entry:
            nbr = self.__get_lldp_nbr_entry(node_at,
                                            entry.peer_if.split('.')[0])
            if nbr:
                peername = nbr.peer_hostname

        br_mstp_info = MstpInfo.query.get(timestamp=self.__start_time,
                                          hostname=node_at, bridge_name=brname)
        if not br_mstp_info:
            # This can happen if the agent is not running on the root bridge
            return [{'info': 'Warning: No info about root bridge',
                     'node': node_at, 'subtree': ''}]

        subtree = []
        for port in br_mstp_info.ports.keys():
            if br_mstp_info.ports[port]['role'] == 'Designated':
                port = port.encode('ascii', 'ignore')
                if br_mstp_info.ports[port]['clagIsl']:
                    nbr = self.__get_lldp_nbr_entry(node_at, port)
                    if nbr:
                        subtree.append([{'node': '%s:%s' % (node_at, port),
                                         'info': 'ClagIsl',
                                         'subtree': [[{
                                             'node': nbr.peer_hostname,
                                             'info': None,
                                             'subtree': ''}]]}])
                    continue

                nbr = self.__get_lldp_nbr_entry(node_at, port)
                if nbr:
                    # We have to verify the peer is also in Fwd state on this
                    # port, but only if its not an edge port
                    if port in br_mstp_info.edge_ports:
                        subtree.append([{'node': '%s:%s' % (node_at, port),
                                         'info': 'STP Edge',
                                         'subtree': [[{
                                             'node': nbr.peer_hostname,
                                             'info': None,
                                             'subtree': ''}]]}])
                        continue

                    peer_mstp_info = MstpInfo.query.get(
                        timestamp=self.__start_time, hostname=nbr.peer_hostname,
                        bridge_name=brname
                    )
                    if peer_mstp_info:
                        if nbr.peer_ifname in peer_mstp_info.ports:
                            mstp_pinfo = peer_mstp_info.ports[nbr.peer_ifname]
                            pbif = nbr.peer_ifname
                        else:
                            # This might be part of a bond, and so get parent
                            pbif = self.__get_parent_bond(nbr.peer_hostname,
                                                          nbr.peer_ifname)
                            if pbif and pbif in peer_mstp_info.ports:
                                mstp_pinfo = peer_mstp_info.ports[pbif]
                            else:
                                continue

                        if mstp_pinfo['state'] != 'forwarding':
                            peer_bond = self.__get_parent_bond(
                                nbr.peer_hostname, nbr.peer_ifname)
                            if not peer_bond:
                                peer_bond = nbr.peer_ifname
                            subtree.append([{
                                'node': '%s:%s' % (node_at, port),
                                'info': None,
                                'subtree': [[{
                                    'node': '%s:%s' \
                                    %(nbr.peer_hostname, peer_bond),
                                    'info': 'STP Blocked', 'subtree': ''}]]}])
                            continue

                        if nbr.peer_hostname in visited_nodes:
                            sys.stderr.write(
                                utils.color_wrap(BgColors.RED,
                                                 'Detected STP Loop. Node %s'
                                                 '(now via %s) visited twice.\n'
                                                 % (nbr.peer_hostname, pbif)))
                            subtree.append([{'node': '%s:%s' % (node_at, port),
                                             'info': 'Error: Loop',
                                             'subtree': [[{
                                                 'node': nbr.peer_hostname,
                                                 'info': 'Error: Loop',
                                                 'subtree': ''}]]}])
                            continue

                        visited_nodes.append(nbr.peer_hostname)
                        subtree.append([{'node': '%s:%s' % (node_at, port),
                                         'info': None,
                                         'subtree': self.build_stp_topo(
                                             nbr.peer_hostname, brname,
                                             True, False,
                                             visited_nodes)}])
                    else:
                        subtree.append([{'node': '%s:%s' % (node_at, port),
                                         'info': None,
                                         'subtree': [[{
                                             'node': nbr.peer_hostname,
                                             'info': None, 'subtree': ''}]]}])
                else:
                    if port in br_mstp_info.edge_ports:
                        subtree.append([{'node': '%s:%s' % (node_at, port),
                                         'info': 'STP Edge', 'subtree': ''}])
                    else:
                        subtree.append([{'node': '%s:%s' % (node_at, port),
                                         'info': None, 'subtree': ''}])

        stppeermap = []
        if visit_peer and peername:
            # We empty the visited nodes when visiting peer because
            # we can potentially be visiting the same nodes again via the peer
            stppeermap = self.build_stp_topo(peername, brname, False, False, [])

        if top:
            subtree = [{'node': '%s' % node_at, 'info': 'Root',
                        'subtree': subtree}]
            if visit_peer and peername:
                subtree.append([{'node': '%s' % peername,
                                 'info': 'Peer Root',
                                 'subtree': stppeermap}])
        elif visit_peer and peername:
            subtree = subtree + stppeermap

        if not subtree:
            subtree.append([{'node': node_at, 'info': None, 'subtree': ''}])

        return subtree

    def get_stp_topo(self, hostname, brname, visit_peer):
        """Do some initial work before handing off to building the topo
        """
        bridges = {}
        entries = MstpInfo.query.filter(timestamp=self.__start_time,
                                        hostname=hostname,
                                        bridge_name=brname)
        for entry in entries:
            if entry.root_bridge not in bridges:
                bridges[entry.root_bridge] = []
            bridges[entry.root_bridge].append([entry.hostname,
                                               entry.bridge_name])
        if not bridges:
            raise NetQException('No bridges found')
        elif len(bridges) > 1:
            err_str = ('Multiple disconnected bridges found. '
                       'Please specify host and/or bridge name')
            if bridges:
                err_str += '\nbridges: %s' % bridges
            raise NetQException(err_str)

        for key in bridges.keys(): #pylint: disable=consider-iterating-dictionary
            root = key.split('.')[2]

            # Identify node name that is the root bridge
            node_at = self.__get_stp_root(root)
            if not node_at:
                raise NetQException(
                    'Error: Unable to identify root bridge %s' % root
                )
            self.__build_lldp_info()
            self.__build_failed_node_lst()
            return self.build_stp_topo(node_at, bridges[key][0][1], visit_peer,
                                       True, [])

    def resolve_output(self):
        """Replace the IP address in output with node name & interface
        if possible.
        """
        prev = HOSTNAME
        traceroute = False
        pmtu_failure = False
        mtu_string = ''
        out = []

        for line in sys.stdin:
            addresses = {}
            prev_save = None
            if not traceroute and line.startswith('traceroute'):
                self.__build_lldp_info()
                traceroute = True
                mtu = 0
                mtu_string = ''

            for addr in self.__IP_ADDR_REGEX.findall(line):
                try:
                    if '/' in addr:
                        _ = ipaddr.IPNetwork(addr)
                        prefix, mask = addr.split('/')
                        addrobj = Address.query.get(
                            timestamp=self.__start_time,
                            prefix=prefix,
                            mask=mask
                        )
                    else:
                        _ = ipaddr.IPAddress(addr)
                        addrobj = Address.query.get(
                            timestamp=self.__start_time,
                            prefix=addr
                        )
                except Exception:  # pylint: disable=broad-except
                    continue

                if addrobj is None:
                    # See if we can find the route origin to identify the i/f
                    route_entry = Route.query.get(timestamp=self.__start_time,
                                                  prefix=addr, origin=True)
                    if route_entry:
                        if route_entry.nexthops is not None:
                            if len(route_entry.nexthops) == 1:
                                addrobj = Address.query.get(
                                    timestamp=self.__start_time,
                                    hostname=route_entry.hostname,
                                    ifname=route_entry.nexthops[0][1].encode(
                                        'ascii', 'ignore'))

                if addrobj is None:
                    continue

                if traceroute and prev is not None:
                    pmtu_error = ''
                    lldp = Lldp.query.get(hostname=prev,
                                          peer_hostname=addrobj.hostname)
                    if lldp is not None:
                        local_link = Link.query.get(
                            timestamp=self.__start_time,
                            ifname=lldp.ifname,
                            hostname=prev)
                        if local_link:
                            if mtu == 0:
                                mtu = int(local_link.mtu)
                                mtu_string = '%s:%s, MTU %d' % (prev,
                                                                lldp.ifname,
                                                                mtu)

                            if mtu != local_link.mtu:
                                pmtu_error = '*'
                                pmtu_failure = True
                        remote_link = Link.query.get(
                            timestamp=self.__start_time,
                            ifname=lldp.peer_ifname,
                            hostname=lldp.peer_hostname
                        )
                        if remote_link and mtu != int(remote_link.mtu):
                            pmtu_error = '*'
                            pmtu_failure = True

                        if '*' in pmtu_error:
                            addr_tuple = (
                                utils.color_wrap(BgColors.RED,
                                                 lldp.peer_hostname),
                                utils.color_wrap(BgColors.RED,
                                                 lldp.peer_ifname),
                                pmtu_error)
                        else:
                            addr_tuple = (
                                utils.color_wrap(BgColors.GREEN,
                                                 lldp.peer_hostname),
                                utils.color_wrap(BgColors.GREEN,
                                                 lldp.peer_ifname))

                        addresses[addr] = addr_tuple
                    else:
                        addr_tuple = (
                            utils.color_wrap(BgColors.GREEN, addrobj.hostname),
                            utils.color_wrap(BgColors.GREEN, addrobj.ifname)
                        )
                        addresses[addr] = addr_tuple
                else:
                    addr_tuple = (
                        utils.color_wrap(BgColors.GREEN, addrobj.hostname),
                        utils.color_wrap(BgColors.GREEN, addrobj.ifname)
                    )
                    addresses[addr] = addr_tuple

                if not line.startswith('traceroute') and not prev_save:
                    prev_save = addrobj.hostname

            for addr in addresses:
                addr_str = '%s (%s)' % (addr, ':'.join(addresses[addr]))
                if traceroute:
                    line = line.replace(addr, addr_str, 1)
                    line = line.replace(' (%s)' % addr, '', 1)
                else:
                    line = line.replace(addr, addr_str)
            out.append(line)

            if not line.startswith('traceroute'):
                prev = prev_save

        if pmtu_failure:
            out.append(
                '* - Links with mismatched MTU from origin %s' %
                mtu_string
            )
        elif traceroute:
            if mtu == 0:
                out.append('Path MTU couldn\'t be determined')
            else:
                out.append('Path MTU is %d' % mtu)

        return ''.join(out)

    def show_address_history(self, node, iface, ip_address, is_ipv6, vrf='*'):
        """Show history of IPv4/v6 addresses associated"""
        out = []

        now = time.time()
        vrr_active_entries = []
        vrr_inactive_entries = []
        vrr_iface = None

        mask = '*'
        if '/' in ip_address:
            prefix, mask = ip_address.split('/')
        else:
            prefix = ip_address

        reverse = self.__end_time is not None

        active_entries = Address.query.rangebyscore(
            prefix=prefix, mask=mask, active=True, is_ipv6=is_ipv6,
            hostname=node, ifname=iface, start=self.__start_time or 0,
            end=self.__end_time or now, first=False, reverse=reverse
        )
        inactive_entries = Address.query.rangebyscore(
            prefix=prefix, mask=mask, active=False, is_ipv6=is_ipv6,
            hostname=node, ifname=iface, start=self.__start_time or 0,
            end=self.__end_time or now, first=False, reverse=reverse
        )

        # We need to get VRR entries too if i/f is specified and is SVI
        if iface != '*':
            link = Link.query.get(timestamp=self.__start_time,
                                  endtimestamp=self.__end_time,
                                  hostname=node, ifname=iface)
            if link and link.kind == LinkType.VLAN:
                # Thanks to NCLU, we may have one of two formats for the
                # VLAN interface: <if>.<vlanid> or just vlan<id>
                if '.' in iface:
                    ifsplit = iface.split('.')
                    vrr_iface = '%s-%s-v0' % (ifsplit[0], ifsplit[1])
                else:
                    vrr_iface = '%s-v0' % iface

                vrr_active_entries = Address.query.rangebyscore(
                    start=self.__start_time or 0, end=self.__end_time or now,
                    first=False, reverse=reverse, hostname=node,
                    ifname=vrr_iface, active=True)
                vrr_inactive_entries = Address.query.rangebyscore(
                    start=self.__start_time or 0, end=self.__end_time or now,
                    first=False, reverse=reverse, hostname=node,
                    ifname=vrr_iface, active=False)

        for address in sorted(list(active_entries) + list(inactive_entries) +
                              list(vrr_active_entries) +
                              list(vrr_inactive_entries),
                              key=lambda x: x.timestamp,
                              reverse=True):
            ipa = address.prefix + '/' + str(address.mask)
            loopback_addr = ['127.0.0.1/8', '::1/128']
            if ipa in loopback_addr:
                continue
            if re.search(self.__VRR_IFACE_REGEX, address.ifname):
                if address.prefix.startswith('fe80::'):
                    continue
                address.ifname = re.sub(self.__VRR_IFACE_REGEX, r'\1.VRR',
                                        address.ifname)
            if address.active:
                state = 'Add'
            else:
                state = 'Del'
            out.append(('/'.join((address.prefix, str(address.mask))),
                        address.hostname, address.ifname, address.timestamp,
                        state))
        return out

    def show_addresses(self, node, iface, ip_address, is_ipv6, vrf='*'):
        """Show IPv4/v6 address associated with an interface or vice-versa"""

        vrr_iface = None
        vrr_entries = []
        prefix = '*'

        mask = '*'
        if ip_address != '*':
            if '/' in ip_address:
                prefix, mask = ip_address.split('/')
            else:
                prefix = ip_address

        if ip_address == '*':
            # MAC and IP are unspecified, so its node/interface specific
            entries = Address.query.filter(timestamp=self.__start_time,
                                           endtimestamp=self.__end_time,
                                           hostname=node, ifname=iface,
                                           prefix=prefix, mask=mask,
                                           is_ipv6=is_ipv6)
            # Get link type and if its a VLAN, see if it has a VRR component
            if iface != '*':
                link = Link.query.get(timestamp=self.__start_time,
                                      endtimestamp=self.__end_time,
                                      hostname=node, ifname=iface)
                if link and link.kind == LinkType.VLAN:
                    # Thanks to NCLU, we may have one of two formats for the
                    # VLAN interface: <if>.<vlanid> or just vlan<id>
                    if '.' in iface:
                        ifsplit = iface.split('.')
                        vrr_iface = '%s-%s-v0' % (ifsplit[0], ifsplit[1])
                    else:
                        vrr_iface = '%s-v0' % iface

                    vrr_entries = Address.query.filter(
                        timestamp=self.__start_time,
                        endtimestamp=self.__end_time, hostname=node,
                        ifname=vrr_iface)

            entries = list(entries) + list(vrr_entries)
        else:
            entries = Address.query.filter(timestamp=self.__start_time,
                                           endtimestamp=self.__end_time,
                                           hostname=node, ifname=iface,
                                           prefix=prefix, mask=mask,
                                           is_ipv6=is_ipv6)
        out = []
        for address in entries:
            if not address:
                # Don't understand why we need this, but getting TB otherwise
                continue

            ipa = address.prefix + '/' + str(address.mask)
            loopback_addr = ['127.0.0.1/8', '::1/128']
            if ipa in loopback_addr:
                continue
            if re.search(self.__VRR_IFACE_REGEX, address.ifname):
                if address.prefix.startswith('fe80::'):
                    continue
                address.ifname = re.sub(self.__VRR_IFACE_REGEX, r'\1.VRR',
                                        address.ifname)
            out.append(('/'.join((address.prefix, str(address.mask))),
                        address.hostname, address.ifname,
                        address.timestamp))

            if len(out) >= RedisQuery.PAGE_SIZE:
                yield out
                out = []
        if out:
            yield out

    @staticmethod
    def show_agent_history(hostname=None):
        if hostname is not None:
            query = Node.query.range(start=0,
                                     end=-1,
                                     first=False,
                                     reverse=True,
                                     active=True,
                                     hostname=hostname)
        else:
            query = Node.query.range(start=0,
                                     end=-1,
                                     first=False,
                                     active=True,
                                     reverse=True)
        for obj in query:
            yield obj.hostname, obj.lastboot, obj.timestamp

    def show_asn(self, asn):
        out = []
        if asn is None:
            nodes = BgpSession.query.all(timestamp=self.__start_time)
        else:
            nodes = BgpSession.query.filter(timestamp=self.__start_time,
                                            asn=asn)
        for node in nodes:
            out.append((node.peer_asn, node.hostname, node.peer_router_id))
        return out

    def check_bgp_status(self, vrf):
        out = []
        good_out = []
        self.__build_failed_node_lst()
        self.__build_lldp_info()  # Also builds the failed node set

        for node in self.failed_node_lst:
            err_str = 'Rotten Agent State'
            out.append([node, '', '', err_str, self.failed_node_lst[node]])

        for node in self.node_lst:
            for session in BgpSession.query.filter(timestamp=self.__start_time,
                                                   hostname=node.hostname,
                                                   vrf=vrf):
                if session.state != 'Established':
                    if session.peer_hostname != '':
                        out.append([session.hostname, session.peer_name,
                                    session.peer_hostname, session.reason,
                                    session.last_reset_time])
                    else:
                        out.append([session.hostname, session.peer_name,
                                    session.peer_router_id, session.reason,
                                    session.last_reset_time])
                elif node not in self.failed_node_lst:
                    if session.peer_hostname != '':
                        good_out.append([session.hostname, session.peer_name,
                                         session.peer_hostname, '', 0])
                    else:
                        good_out.append([session.hostname, session.peer_name,
                                         session.peer_router_id, '', 0])

        return good_out, out

    def check_ospf_status(self):
        out = []
        good_out = []
        self.__build_failed_node_lst()
        self.__build_lldp_info()  # Also builds the failed node set

        for node in self.failed_node_lst:
            err_str = 'Rotten Agent State'
            out.append([node, '', '', err_str, self.failed_node_lst[node]])

        for node in self.node_lst:
            for session in OspfNbr.query.filter(timestamp=self.__start_time,
                                                hostname=node.hostname):
                if session.state != 'Fail':
                    good_out.append([session.hostname, session.ifname,
                                     session.peer_id, session.peer_addr,
                                     session.timestamp])
                else:
                    out.append([session.hostname, session.ifname,
                                session.peer_id, session.peer_addr,
                                session.timestamp])

        return good_out, out

    @staticmethod
    def show_keys(hostname):
        out = []
        key_map = {}
        cmds = Command.query.filter(hostname=hostname, key='*')
        for cmd in cmds:
            key_map[Command.obj_to_key(cmd.__dict__)] = cmd
        for key, count, oldest, newest in Command.query.count(
                key_map.keys()): # pylint: disable=consider-iterating-dictionary
            out.append((key_map[key].key.replace('-', ' '), float(oldest),
                        float(newest), count))
        return out

    def check_clag_status(self):
        out = []
        good_out = []
        warn_out = []
        rotten_nodenames = []
        clag_sysmac_dict = {}

        self.__build_failed_node_lst()
        self.__build_lldp_info()

        for node in self.failed_node_lst:
            err_str = 'Rotten Agent State'
            out.append([node, err_str])
            rotten_nodenames.append(node)

        for clag in ClagSession.query.filter(timestamp=self.__start_time):
            failed = 0
            peerlen = len(clag_sysmac_dict.get(clag.clag_sysmac, []))
            if not peerlen:
                peername = self.__get_clag_peer_hostname(clag.hostname,
                                                         clag.peer_if)
                clag_sysmac_dict[clag.clag_sysmac] = [clag.hostname, peername]
                if clag.backup_ip != '':
                    peer_ipif = Address.query.get(
                        timestamp=self.__start_time,
                        prefix=clag.backup_ip,
                        is_ipv6=':' in clag.backup_ip
                    )
                    if(peer_ipif and peername != '*' and
                       peer_ipif.hostname != peername):
                        out.append(
                            [clag.hostname,
                             ('Backup IP %s set to wrong host: %s '
                              'instead of %s' % (peer_ipif.prefix,
                                                 peer_ipif.hostname,
                                                 clag.hostname))]
                        )
                        failed = 1
            elif '*' in clag_sysmac_dict[clag.clag_sysmac]:
                # We couldn't identify the peers due to lack of lldp
                # this one takes the cake as the peer for now
                peers = clag_sysmac_dict[clag.clag_sysmac]
                if peers[0] == '*':
                    clag_sysmac_dict[clag.clag_sysmac] = [clag.hostname,
                                                          peers[1]]
                else:
                    clag_sysmac_dict[clag.clag_sysmac] = [peers[0],
                                                          clag.hostname]
            elif clag.hostname not in clag_sysmac_dict[clag.clag_sysmac]:
                dup_peers = clag_sysmac_dict[clag.clag_sysmac]
                out.append([clag.hostname,
                            ('Duplicate sysmac with %s/%s' %
                             (dup_peers[0], dup_peers[1]))])

                failed = 1
            else:
                peers = clag_sysmac_dict[clag.clag_sysmac]
                if peers[0] == clag.hostname:
                    peername = peers[1]
                else:
                    peername = peers[0]
                peer_ipif = Address.query.get(timestamp=self.__start_time,
                                              prefix=clag.backup_ip,
                                              is_ipv6=':' in clag.backup_ip
                                             )
                if (peer_ipif and peername != '*' and
                        peer_ipif.hostname != peername):
                    out.append([clag.hostname,
                                ('Backup IP %s set to wrong host: %s '
                                 'instead of %s' % (peer_ipif.prefix,
                                                    peer_ipif.hostname,
                                                    peername))]

                              )
                    failed = 1

            if not clag.peer_state:
                err_str = 'Peer Connectivity failed'
                out.append([clag.hostname, err_str])
                failed = 1
            if clag.conflicted_bonds:
                ele_list = []
                for ele in clag.conflicted_bonds:
                    ele_list.append('%s:%s' % (ele[0].encode('ascii',
                                                             'ignore'),
                                               ele[1].encode('ascii',
                                                             'ignore')))
                err_str = 'Conflicted Bonds: %s' % (', '.join(ele_list))
                out.append([clag.hostname, err_str])
                failed = 1
            if clag.proto_down_bonds:
                ele_list = []
                for ele in clag.proto_down_bonds:
                    ele_list.append('%s:%s' % (ele[0].encode('ascii',
                                                             'ignore'),
                                               ele[1].encode('ascii',
                                                             'ignore')))
                err_str = 'Protodown Bonds: %s' % (', '.join(ele_list))
                out.append([clag.hostname, err_str])
                failed = 1

            if clag.single_bonds:
                ele_list = []
                link_down_bonds = []
                for ele in clag.single_bonds:
                    # Check if the link is down
                    iface = ele.encode('ascii', 'ignore')
                    link = Link.query.get(timestamp=self.__start_time,
                                          endtimestamp=self.__end_time,
                                          hostname=clag.hostname,
                                          ifname=iface, kind='bond')
                    if link and link.oper_state != InterfaceState.UP:
                        link_down_bonds.append(iface)
                    else:
                        ele_list.append('%s' % iface)
                if ele_list:
                    err_str = 'Singly Attached Bonds: %s' % (', '.join(ele_list))
                    warn_out.append([clag.hostname, err_str])
                if link_down_bonds:
                    err_str = 'Link Down: %s' % (', '.join(link_down_bonds))
                    warn_out.append([clag.hostname, err_str])
                failed = 1

            if not clag.backup_ip_active and clag.peer_state:
                warn_out.append([clag.hostname, 'Backup IP Failed'])
                failed = 1

            if not failed and clag.hostname not in rotten_nodenames:
                good_out.append([clag.hostname, ''])

        return good_out, warn_out, out

    def check_stp_failed_status(self):
        """Show health of STP across the fabric
        """
        out = []
        rotten_nodenames = []

        self.__build_failed_node_lst()
        for node in self.failed_node_lst:
            err_str = 'Rotten Agent State'
            out.append([node, err_str])
            rotten_nodenames.append(node)

        # Verify that for all bridges, the root is the same
        # Verify that designated agreement exists on both sides (except
        # alternate root)
        for node in self.node_lst:
            for mstpi in MstpInfo.query.filter(timestamp=self.__start_time,
                                               hostname=node.hostname):
                if mstpi.bpduguard_err_ports:
                    err_str = (
                        'BPDUGuard Error %s' %
                        ' '.join(mstpi.bpduguard_err_ports)
                    )
                    out.append([MstpStatus.BPDUGUARD_ERR, err_str,
                                mstpi.hostname])
                if mstpi.disputed_ports:
                    err_str = ('Disputed ports: %s' %
                               ' '.join(mstpi.disputed_ports))
                    out.append([MstpStatus.DISPUTED, err_str, mstpi.hostname])
                if mstpi.ba_inconsistent_ports:
                    err_str = ('BA Inconsistent ports: %s' %
                               ' '.join(mstpi.ba_inconsistent_ports))
                    out.append([MstpStatus.BA_INCONSISTENT, err_str,
                                mstpi.hostname])

    def get_bgp_status_details(self, hostname, peername, asn, vrf):
        """Return detailed BGP status"""

        out = []
        bad = []

        self.__build_failed_node_lst()

        for entry in BgpSession.query.filter(timestamp=self.__start_time,
                                             hostname=hostname,
                                             peer_name=peername, asn=asn,
                                             vrf=vrf):
            failed = False
            if (not entry.hostname in self.failed_node_lst and
                    entry.state == 'Established'):
                if entry.ipv4_pfx_rcvd and entry.ipv6_pfx_rcvd:
                    details = ('state: Estd, v4PfxRx: %d, v6PfxRx: %d,'
                               ' vrf: %s' % (entry.ipv4_pfx_rcvd,
                                            entry.ipv6_pfx_rcvd, entry.vrf)
                               )
                elif entry.ipv4_pfx_rcvd:
                    details = ('state: Estd, v4PfxRx: %d, '
                               'vrf: %s' % (entry.ipv4_pfx_rcvd, entry.vrf)
                               )
                elif entry.ipv6_pfx_rcvd:
                    details = ('state: Estd, v6PfxRx: %d, '
                               'vrf: %s' % (entry.ipv6_pfx_rcvd, entry.vrf)
                               )
                else:
                    details = ('state: Estd, v4PfxRx: 0, v6PfxRx: 0, '
                               'vrf: %s' % (entry.vrf)
                               )

                out.append([entry.hostname, '%s(%s)' % (entry.peer_name,
                                                        entry.peer_hostname),
                            entry.asn, entry.peer_asn, details])
            else:
                if entry.hostname in self.failed_node_lst:
                    details = 'state: Rotten, vrf %s' % (entry.vrf)
                else:
                    details = ('state: failed, reason: %s, vrf: %s' %
                               (entry.reason, entry.vrf)
                               )
                bad.append([entry.hostname, '%s(%s)' % (entry.peer_name,
                                                        entry.peer_hostname),
                            entry.asn, entry.peer_asn, details])

        return out, bad

    def get_bgp_status_history(self, hostname, peername, asn, vrf):
        """"""
        out = []
        bad = []
        now = time.time()
        reverse = self.__end_time is not None

        self.__build_failed_node_lst()

        active_entries = BgpSession.query.rangebyscore(
            hostname=hostname, peer_name=peername, asn=asn, vrf=vrf,
            start=self.__start_time or 0, end=self.__end_time or now,
            first=False, reverse=reverse, active=True,
        )
        inactive_entries = BgpSession.query.rangebyscore(
            hostname=hostname, peer_name=peername, asn=asn, vrf=vrf,
            start=self.__start_time or 0, end=self.__end_time or now,
            first=False, reverse=reverse, active=False,
        )
        for entry in list(active_entries) + list(inactive_entries):
            failed = False

            if entry.active:
                oper = 'Add'
            else:
                oper = 'Del'

            if ((self.failed_node_lst.get(entry.hostname, 0) / 1000) >
                    entry.timestamp):
                state = 'Rotten'
                failed = True
            elif entry.state == 'Established':
                state = 'Estd'
                if entry.ipv4_pfx_rcvd and entry.ipv6_pfx_rcvd:
                    details = ('state: Estd, v4PfxRx: %d, v6PfxRx: %d,'
                               ' vrf: %s' % (entry.ipv4_pfx_rcvd,
                                            entry.ipv6_pfx_rcvd, entry.vrf)
                           )
                elif entry.ipv4_pfx_rcvd:
                    details = ('state: Estd, v4PfxRx: %d, '
                               ' vrf: %s' % (entry.ipv4_pfx_rcvd, entry.vrf)
                               )
                elif entry.ipv6_pfx_rcvd:
                    details = ('state: Estd, v6PfxRx: %d, '
                               ' vrf: %s' % (entry.ipv6_pfx_rcvd, entry.vrf)
                               )
                else:
                    details = ('state: Estd, v4PfxRx: 0, v6PfxRx: 0, '
                               ' vrf: %s' % (entry.vrf)
                               )

                out.append([entry.hostname, '%s(%s)' % (entry.peer_name,
                                                        entry.peer_hostname),
                            entry.asn, entry.peer_asn, details, oper,
                            entry.timestamp])
            else:
                state = 'Failed'
                failed = True

            if failed:
                 details = 'state: %s, reason: %s, vrf: %s' % (state,
                                                               entry.reason,
                                                               entry.vrf)
                 bad.append([entry.hostname, '%s(%s)' % (entry.peer_name,
                                                         entry.peer_hostname),
                             entry.asn, entry.peer_asn, details, oper,
                             entry.timestamp])

        return out, bad

    def get_clag_status_details(self, hostname):
        """Return detailed CLAG status"""

        out = []
        bad = []
        self.__build_lldp_info()
        self.__build_failed_node_lst()

        for entry in ClagSession.query.filter(timestamp=self.__start_time,
                                              hostname=hostname):

            dual_bond_cnt = len(entry.dual_bonds)
            total_bonds = (dual_bond_cnt + len(entry.single_bonds) +
                           len(entry.conflicted_bonds) +
                           len(entry.proto_down_bonds))

            failed = False
            myname = entry.hostname
            peern = self.__get_clag_peer_hostname(entry.hostname,
                                                  entry.peer_if)
            if entry.role == 'primary':
                myname = '%s(P)' % myname
            else:
                peern = '%s(P)' % peern

            if entry.hostname in self.failed_node_lst:
                state = 'bad'
                backup = 'bad'
                failed = True
            else:
                if entry.peer_state:
                    state = 'up'
                else:
                    state = 'down'
                    failed = True

                if entry.backup_ip:
                    if entry.backup_ip_active:
                        backup = 'up'
                    else:
                        backup = 'down'
                        failed = True
                else:
                    backup = 'n/a'

            if total_bonds != dual_bond_cnt:
                failed = True

            if failed:
                bad.append([myname, peern, entry.clag_sysmac, state, backup,
                            total_bonds, dual_bond_cnt])
            else:
                out.append([myname, peern, entry.clag_sysmac, state, backup,
                            total_bonds, dual_bond_cnt])

        return out, bad

    def get_clag_status_history(self, hostname):
        """"""
        out = []
        bad = []
        now = time.time()
        reverse = self.__end_time is not None
        self.__build_lldp_info()
        self.__build_failed_node_lst()

        active_entries = ClagSession.query.rangebyscore(
            hostname=hostname, start=self.__start_time or 0,
            end=self.__end_time or now,
            first=False, reverse=reverse, active=True,
        )
        inactive_entries = ClagSession.query.rangebyscore(
            hostname=hostname, start=self.__start_time or 0,
            end=self.__end_time or now,
            first=False, reverse=reverse, active=False,
        )
        for entry in list(active_entries) + list(inactive_entries):
            failed = False
            dual_bond_cnt = len(entry.dual_bonds)
            total_bonds = (dual_bond_cnt
                           + len(entry.single_bonds)
                           + len(entry.conflicted_bonds)
                           + len(entry.proto_down_bonds))

            myname = entry.hostname
            peern = self.__get_clag_peer_hostname(entry.hostname, entry.peer_if)
            if entry.role == 'primary':
                myname = '%s(P)' % myname
            else:
                peern = '%s(P)' % peern

            if ((self.failed_node_lst.get(entry.hostname, 0)/1000)
                    > entry.timestamp):
                state = 'bad'
                backup = 'bad'
                failed = True
            else:
                if entry.peer_state:
                    state = 'up'
                else:
                    state = 'down'
                    failed = True

                if entry.backup_ip:
                    if entry.backup_ip_active:
                        backup = 'up'
                    else:
                        backup = 'down'
                        failed = True
                else:
                    backup = 'n/a'

            if entry.active:
                oper = 'Add'
            else:
                oper = 'Del'

            if total_bonds != dual_bond_cnt:
                failed = True

            if failed:
                bad.append([myname, peern, entry.clag_sysmac, state, backup,
                            total_bonds, len(entry.dual_bonds), oper,
                            entry.timestamp])
            else:
                out.append([myname, peern, entry.clag_sysmac, state, backup,
                            total_bonds, len(entry.dual_bonds), oper,
                            entry.timestamp])

        return out, bad

    def get_services_status(self, hostname, service):
        """Get status of (specified)service for (specified)hosts
        """
        out = []

        self.__build_failed_node_lst()
        for svc in Services.query.filter(timestamp=self.__start_time,
                                         hostname=hostname, name=service):
            if svc.hostname in self.failed_node_lst:
                status = svc.timestamp
            else:
                status = 'current'
            out.append([svc.hostname, svc.name,
                        'yes' if svc.is_enabled else 'no',
                        'yes' if svc.is_active else 'no',
                        'yes' if svc.is_monitored else 'no',
                        'yes' if svc.is_failed else 'no', status])

        return out

    def get_os_status(self, hostname, search_str=None):
        """ Get OS info for (specified) hosts
        """
        out = []
        sstr = None
        if search_str:
            sstr = search_str.lower()
        self.__build_failed_node_lst()
        for oss in OS.query.filter(
                timestamp=self.__start_time, hostname=hostname):
            if sstr:
                if (oss.version_id.startswith(sstr) or
                        sstr in oss.name.lower()):
                    out.append([oss.hostname, oss.name, oss.version_id])
            else:
                out.append([oss.hostname, oss.name, oss.version_id])
        return out

    def get_cpu_status(self, hostname, search_str=None):
        """ Get CPU info for (specified) hosts
        """
        out = []
        sstr = None
        if search_str:
            sstr = search_str.lower()
        self.__build_failed_node_lst()

        for proc in CPU.query.filter(
                timestamp=self.__start_time, hostname=hostname):
            if sstr:
                if (sstr in proc.arch.lower() or
                        sstr in proc.model.lower()):
                    out.append([
                        proc.hostname, proc.arch, proc.model,
                        proc.max_freq, proc.nos, proc.mem_total])
            else:
                out.append([
                    proc.hostname, proc.arch, proc.model,
                    proc.max_freq, proc.nos, proc.mem_total])
        return out

    def get_asic_status(self, hostname, search_str=None):
        """ Get Network ASIC info for (specified) hosts
        """
        out = []
        sstr = None
        if search_str:
            sstr = search_str.lower()
        self.__build_failed_node_lst()
        for proc in ASIC.query.filter(
                timestamp=self.__start_time, hostname=hostname):
            if sstr:
                if (sstr in proc.vendor.lower() or
                        sstr in proc.model.lower() or
                        sstr in proc.model_id.lower() or
                        sstr in proc.ports.lower()):
                    out.append([
                        proc.hostname, proc.vendor, proc.model,
                        proc.model_id, proc.core_bw, proc.ports])
            else:
                out.append([
                    proc.hostname, proc.vendor, proc.model,
                    proc.model_id, proc.core_bw, proc.ports])
        return out

    def get_board_status(self, hostname, search_str=None):
        """ Get Board info for (specified) hosts
        """
        out = []
        self.__build_failed_node_lst()
        sstr = None
        if search_str:
            sstr = search_str.lower()
        for board in Board.query.filter(
                timestamp=self.__start_time, hostname=hostname):
            if sstr:
                if (sstr in board.vendor.lower() or # pylint: disable=too-many-boolean-expressions
                        sstr in board.model.lower() or
                        sstr in board.base_mac.lower() or
                        sstr in board.part_number.lower() or
                        sstr in board.serial_number.lower() or
                        sstr in board.label_revision.lower()):
                    out.append([
                        board.hostname, board.vendor, board.model,
                        board.base_mac, board.serial_number,
                        board.part_number, board.label_revision,
                        board.mfg_date])
            else:
                out.append([
                    board.hostname, board.vendor, board.model,
                    board.base_mac, board.serial_number,
                    board.part_number, board.label_revision,
                    board.mfg_date])
        return out

    def get_disk_status(self, hostname, search_str=None):
        """ Get Board info for (specified) hosts
        """
        out = []
        self.__build_failed_node_lst()
        sstr = None
        if search_str:
            sstr = search_str.lower()
        for disk in Disk.query.filter(
                timestamp=self.__start_time, hostname=hostname):
            if sstr:
                if (sstr in disk.name.lower() or # pylint: disable=too-many-boolean-expressions
                        sstr in disk.d_type.lower() or
                        sstr in disk.vendor.lower() or
                        sstr in disk.transport.lower() or
                        sstr in disk.model.lower() or
                        disk.size.startswith(sstr)):
                    out.append([
                        disk.hostname, disk.name, disk.d_type,
                        disk.transport, disk.size, disk.vendor, disk.model])
            else:
                out.append([
                    disk.hostname, disk.name, disk.d_type,
                    disk.transport, disk.size, disk.vendor, disk.model])
        return out

    def get_memory_status(self, hostname, search_str=None):
        """ Get Board info for (specified) hosts
        """
        out = []
        self.__build_failed_node_lst()
        sstr = None
        if search_str:
            sstr = search_str.lower()
        for memory in Memory.query.filter(
                timestamp=self.__start_time, hostname=hostname):
            if sstr:
                if (sstr in memory.name.lower() or # pylint: disable=too-many-boolean-expressions
                        sstr in memory.m_type.lower() or
                        sstr in memory.vendor.lower() or
                        sstr in memory.name.lower() or
                        sstr in memory.serial_number.lower() or
                        memory.size.startswith(sstr)):
                    out.append([
                        memory.hostname, memory.name, memory.m_type,
                        memory.size, memory.speed, memory.vendor,
                        memory.serial_number])
            else:
                out.append([
                    memory.hostname, memory.name, memory.m_type,
                    memory.size, memory.speed, memory.vendor,
                    memory.serial_number])
        return out

    def get_inventory_status(self, hostname):
        out = []
        switch = ''
        proc_arch = ''
        asic_info = ''
        asic_ports = ''

        self.__build_failed_node_lst()
        for oss in OS.query.filter(
                timestamp=self.__start_time, hostname=hostname):
            host = oss.hostname
            os_name = oss.name
            if oss.name is not 'N/A':
                os_name = oss.name + ' ' + oss.version_id[:5]
            for proc in CPU.query.filter(
                    timestamp=self.__start_time, hostname=host):
                proc_arch = proc.arch
            for asic in ASIC.query.filter(
                    timestamp=self.__start_time, hostname=host):
                asic_info = asic.model
                asic_ports = asic.ports.strip()
            for board in Board.query.filter(
                    timestamp=self.__start_time, hostname=host):
                switch = board.model
            out.append([host, switch, os_name, proc_arch, asic_info, asic_ports])
        return out

    def show_info(self, ip_address=None, mac_address=None, node=None):
        """
        Get all relevant info about provided input
        """
        display = []
        self.__build_lldp_info(None)
        self.__build_failed_node_lst()

        if ip_address is not '*':
            # Attempt to determine if we can identify the end node
            out = []
            neighbors = Neighbor.query.filter(timestamp=self.__start_time,
                                              ip_address=ip_address)
            for neighbor in neighbors:
                macs = MacFdb.query.filter(timestamp=self.__start_time,
                                           mac_address=neighbor.mac_address)
                for entry in macs:
                    lldpnbrs = Lldp.query.filter(timestamp=self.__start_time,
                                                 hostname=neighbor.hostname,
                                                 ifname=entry.nexthop)
                    for lldpnbr in lldpnbrs:
                        display.append(
                            '%s belongs to %s, connected to %s:%s\n' % (
                                ip_address, lldpnbr.peer_hostname,
                                neighbor.hostname, entry.nexthop)
                        )
                out.append((neighbor.ip_address, neighbor.hostname,
                            neighbor.ifname, neighbor.mac_address))
                if out:
                    display.append('IP Neighbor Information:')
                    display.append(tabulate(sorted(out),
                                            headers=['IP', 'Node', 'Interface',
                                                     'MAC']))

        elif mac_address is not '*':
            mac_entries = MacFdb.query.filter(timestamp=self.__start_time,
                                              mac_address=mac_address)
            for entry in mac_entries:
                lldpnbrs = Lldp.query.filter(timestamp=self.__start_time,
                                             hostname=entry.hostname,
                                             ifname=entry.nexthop)
                for lldpnbr in lldpnbrs:
                    display.append('%s belongs to %s, connected to %s:%s\n' %
                                   (mac_address, lldpnbr.peer_hostname,
                                    entry.hostname, entry.nexthop))
            neighbors = Neighbor.query.filter(timestamp=self.__start_time,
                                              mac_address=mac_address,
                                              is_ipv6=False)
            out = []
            for neighbor in neighbors:
                out.append((neighbor.ip_address, neighbor.hostname,
                            neighbor.ifname, neighbor.mac_address))
            if out:
                display.append('List of IP Neighbor entries')
                display.append(tabulate(sorted(out),
                                        headers=['IP', 'Node', 'Interface',
                                                 'MAC']))

        elif node is not '*':
            if Node.query.get(hostname=node) is None:
                raise NetQException('No information about %s found' % node)

            # OK, this is a hostname. Display all valid info about host
            display.append('Info about node %s' % node)

            uptime = Command.query.get(timestamp=self.__start_time,
                                       hostname=node,
                                       key=NetQ.UPTIME_KEY)
            if uptime is not None:
                display.append('uptime %s' % uptime.output.strip())

            meminfo = Command.query.get(timestamp=self.__start_time,
                                        hostname=node,
                                        key=NetQ.MEMINFO_KEY)
            if meminfo is not None:
                display.append('Free Memory: %s' %
                               meminfo.output.split('\n')[1].
                               split(':')[1].strip())

            routes = Route.query.filter(timestamp=self.__start_time,
                                        hostname=node)
            macs = MacFdb.query.filter(timestamp=self.__start_time,
                                       hostname=node)

            display.append('Total routes: %d' % len(list(routes)))
            display.append('Total macs: %d' % len(list(macs)))

            out = self.get_services_status(hostname=node, service='*')
            active_svcs = []
            for line in out:
                # Check if service is active
                if line[3] is True:
                    active_svcs.append(line[1])
            active_svcs = sorted(active_svcs)
            active_svcs_str = ''
            if len(active_svcs):
                active_svcs_str = active_svcs[0]
                for svcs in active_svcs[1:-1]:
                    active_svcs_str += ', %s' %svcs
            display.append('Services running: %s' %active_svcs_str)

        return '\n'.join(display)

    def show_ip_neighbor_history(self, hostname='*', ifname='*',
                                 ip_address='*', mac='*', ipv6=False, vrf='*'):
        out = []
        now = time.time()

        reverse = self.__end_time is not None

        if hostname != '*' and ifname != '*':
            active_entries = Neighbor.query.rangebyscore(
                hostname=hostname, ifname=ifname, active=True,
                mac_address=mac, is_ipv6=ipv6,
                start=self.__start_time or 0, end=self.__end_time or now,
                first=False, reverse=reverse
            )
            inactive_entries = Neighbor.query.rangebyscore(
                hostname=hostname, ifname=ifname, active=False,
                mac_address=mac, is_ipv6=ipv6,
                start=self.__start_time or 0, end=self.__end_time or now,
                first=False, reverse=reverse
            )
        else:
            active_entries = Neighbor.query.rangebyscore(
                ip_address=ip_address, active=True, mac_address=mac,
                is_ipv6=ipv6, start=self.__start_time or 0,
                end=self.__end_time or now, first=False, reverse=reverse
            )
            inactive_entries = Neighbor.query.rangebyscore(
                ip_address=ip_address, active=False, mac_address=mac,
                is_ipv6=ipv6, start=self.__start_time or 0,
                end=self.__end_time or now, first=False, reverse=reverse
            )
        for neighbor in sorted(list(active_entries) + list(inactive_entries),
                               key=lambda x: x.timestamp,
                               reverse=True):
            if neighbor.active:
                state = 'Add'
            else:
                state = 'Del'
            out.append((neighbor.ip_address, neighbor.hostname,
                        neighbor.ifname, neighbor.mac_address,
                        neighbor.timestamp, state))
        return out

    def show_ip_neighbors(self, ip_address, hostname, iface, mac, ipv6=False,
                          vrf='*'):
        out = []
        for neighbor in Neighbor.query.filter(timestamp=self.__start_time,
                                              endtimestamp=self.__end_time,
                                              ip_address=ip_address,
                                              hostname=hostname,
                                              ifname=iface,
                                              mac_address=mac,
                                              is_ipv6=ipv6):
            if neighbor is None:
                out.append(None)
                continue
            if neighbor.ifname == 'lo':
                continue
            if neighbor.ip_address == 'None':
                continue
            out.append((neighbor.ip_address, neighbor.hostname,
                        neighbor.ifname, neighbor.mac_address,
                        neighbor.timestamp))
            if len(out) >= RedisQuery.PAGE_SIZE:
                yield out
                out = []
        if out:
            yield out

    def show_link_history(self, hostname, ifname, kind='*'):
        self.__build_failed_node_lst()
        self.__build_lldp_info(None)
        out = []
        now = time.time()
        reverse = self.__end_time is not None

        active_entries = list(
            Link.query.rangebyscore(hostname=hostname,
                                    ifname=ifname, kind=kind, active=True,
                                    start=self.__start_time or 0,
                                    end=self.__end_time or now, first=False,
                                    reverse=reverse)
        )
        inactive_entries = list(
            Link.query.rangebyscore(hostname=hostname, ifname=ifname, kind=kind,
                                    active=False, start=self.__start_time or 0,
                                    end=self.__end_time or now, first=False,
                                    reverse=reverse)
        )
        for link in sorted(active_entries + inactive_entries,
                           key=lambda x: x.timestamp,
                           reverse=True):
            details = self.__get_link_details(link)
            if link.active:
                state = 'Add'
            else:
                state = 'Del'
            out.append((link.hostname, link.ifname, link.oper_state,
                        details, link.timestamp, state))
        return out

    def show_links(self, hostname=None, ifname=None, kind='*'):
        self.__build_failed_node_lst()
        self.__build_lldp_info(None)
        out = []
        links = Link.query.filter(timestamp=self.__start_time,
                                  endtimestamp=self.__end_time,
                                  hostname=hostname,
                                  ifname=ifname, kind=kind)
        self.__end_time = None
        for link in links:
            if link is None:
                out.append(None)
                continue
            self.__start_time = link.timestamp
            details = self.__get_link_details(link)
            out.append((link.hostname, link.ifname, link.kind, link.oper_state,
                        details, link.timestamp))
            if len(out) >= RedisQuery.PAGE_SIZE:
                yield out
                out = []
        if out:
            yield out

    def show_mac_history(self, mac_address, vlan='*', hostname='*',
                         nexthop='*', origin='*'):
        out = []
        now = time.time()
        self.__build_lldp_info()
        known_nodes = [node.hostname for node in self.node_lst]
        reverse = self.__end_time is not None

        active_entries = MacFdb.query.rangebyscore(
            mac_address=mac_address, hostname=hostname, vlan=vlan,
            active=True, start=self.__start_time or 0,
            end=self.__end_time or now, first=False, reverse=reverse
        )
        inactive_entries = MacFdb.query.rangebyscore(
            mac_address=mac_address, hostname=hostname, vlan=vlan,
            active=False, start=self.__start_time or 0,
            end=self.__end_time or now, first=False, reverse=reverse
        )

        for macfdb in sorted(list(active_entries) + list(inactive_entries),
                             key=lambda x: x.timestamp,
                             reverse=True):
            if macfdb:
                result = self.__process_show_fdb_entry(macfdb, nexthop,
                                                       origin, known_nodes)
                if not result:
                    continue

                if macfdb.active:
                    state = 'Add'
                else:
                    state = 'Del'

                result.extend([state])
                out.append(result)

                if len(out) >= RedisQuery.PAGE_SIZE:
                    yield out
                    out = []
        if out:
            yield out

    def show_macvlan(self, mac_address, vlan, hostname, nexthop='*',
                     origin='*'):

        self.__build_lldp_info()
        out = []
        known_nodes = [node.hostname for node in self.node_lst]

        fdb_entries = MacFdb.query.filter(timestamp=self.__start_time,
                                          endtimestamp=self.__end_time,
                                          hostname=hostname,
                                          mac_address=mac_address, vlan=vlan)

        for entry in fdb_entries:
            if entry:
                result = self.__process_show_fdb_entry(entry, nexthop, origin,
                                                       known_nodes)
                if result:
                    out.append(result)

                if len(out) >= RedisQuery.PAGE_SIZE:
                    yield out
                    out = []
        if out:
            yield out

    def show_neighbors(self, node, iface):
        self.__build_failed_node_lst()
        self.__build_lldp_info(node)
        out = []
        parent_iface = ''
        if iface is not '*':
            lldplist = []
            # Check what type of link it is, if bond get slave list
            links = Link.query.filter(
                timestamp=self.__start_time, hostname=node, ifname=iface)
            for link in links:
                if link.kind == LinkType.SWP:
                    lldpobj = Lldp.query.filter(
                        timestamp=self.__start_time, hostname=node,
                        ifname=iface)
                    lldplist.extend(list(lldpobj))

                elif link.kind == LinkType.BOND:
                    parent_iface = iface
                    for slave in self.__get_slaves(link.hostname, link.ifname):
                        lldpobj = Lldp.query.filter(
                            timestamp=self.__start_time, hostname=node,
                            ifname=slave)
                        lldplist.extend(list(lldpobj))
                else:
                    raise NetQException('LLDP is not valid for non-physical '
                                        'or bond links')
        else:
            lldplist = Lldp.query.all(timestamp=self.__start_time)
        for lldpobj in lldplist:
            if parent_iface != '':
                local_master = self.__get_parent_bond(node, lldpobj.ifname)
                peer_master = self.__get_parent_bond(lldpobj.peer_hostname,
                                                     lldpobj.peer_ifname)
                if peer_master:
                    peer_master = '%s:' % peer_master
                else:
                    peer_master = ''
                out.append((
                    lldpobj.hostname, '%s:%s' %(local_master, lldpobj.ifname),
                    lldpobj.peer_hostname,
                    '%s%s' % (peer_master, lldpobj.peer_ifname),
                    lldpobj.timestamp))
            else:
                out.append((
                    lldpobj.hostname, lldpobj.ifname, lldpobj.peer_hostname,
                    lldpobj.peer_ifname, lldpobj.timestamp))
        return out

    def show_route_history(self, ip_address, hostname='*', ipv6=False,
                           origin='*', vrf='*'):
        out = []
        now = time.time()
        reverse = self.__end_time is not None
        skip_ipv4_addr = {'127.0.0.0/8', '127.0.0.1/32', '127.0.0.0/32',
                          '127.255.255.255/32', '169.254.0.1/32'}
        skip_ipv6_addr = {'fe80::/64', '::/0', '::1/128', 'ff00::/8'}

        # DO lpm query to get all matching routes first
        if hostname is not '*':
            nodes = [hostname]
        else:
            nodes = [node.hostname for node in self.node_lst]

        # Get table associated with VRF, if VRF is specified
        self.__build_vrf_table_map(hostname)
        table = '*'
        table_local = 255

        if vrf != '*':
            if hostname != '*':
                table = self.vrf_table_map[hostname]['vrf'][vrf]
            else:
                for node in nodes:
                    if (node in self.vrf_table_map and
                            vrf in self.vrf_table_map[node]['vrf']):
                        table = self.vrf_table_map[node]['vrf'][vrf]
                        break
                else:
                    return []

        if ip_address is not '*':
            active_entries = []
            inactive_entries = []
            for entry in Route.query.lpm(ip_address, nodes, table,
                                         timestamp=self.__start_time,
                                         is_ipv6=ipv6):
                active_entries += list(Route.query.rangebyscore(
                    prefix=entry.prefix, hostname=hostname, active=True,
                    is_ipv6=ipv6,
                    start=self.__start_time or 0, end=self.__end_time or now,
                    first=False, reverse=reverse
                ))
                inactive_entries += list(Route.query.rangebyscore(
                    prefix=entry.prefix, hostname=hostname, active=False,
                    is_ipv6=ipv6,
                    start=self.__start_time or 0, end=self.__end_time or now,
                    first=False, reverse=reverse
                ))
        else:
            active_entries = Route.query.rangebyscore(
                prefix=ip_address, hostname=hostname, active=True,
                is_ipv6=ipv6,
                start=self.__start_time or 0, end=self.__end_time or now,
                first=False, reverse=reverse
            )
            inactive_entries = Route.query.rangebyscore(
                prefix=ip_address, hostname=hostname, active=False,
                is_ipv6=ipv6,
                start=self.__start_time or 0, end=self.__end_time or now,
                first=False, reverse=reverse
            )

        for route in sorted(list(active_entries) + list(inactive_entries),
                            key=lambda x: x.timestamp,
                            reverse=True):
            if not route.is_ipv6 and route.prefix in skip_ipv4_addr:
                continue
            if route.is_ipv6 and route.prefix in skip_ipv6_addr:
                continue
            if (table != '*' and (route.rt_table_id != table and
                                  route.rt_table_id != table_local)):
                continue
            if not route.nexthops:
                route.nexthops = [['None', 'Local']]
            if self.__is_route_blackholed(route.route_type):
                route.nexthops = [['None', 'Blackhole']]
            if origin is '*' or origin == route.origin:
                nexthops = ', '.join(
                    '%s: %s' % (nh[0], nh[1]) if nh[0] != 'None'
                    else '%s' % nh[1] for nh in sorted(route.nexthops)
                )
                route.rt_table_id = int(route.rt_table_id)

                if (route.hostname in self.vrf_table_map and
                    route.rt_table_id in self.vrf_table_map[route.hostname]['table']):
                    table_name = (
                        self.vrf_table_map[route.hostname]['table'][route.rt_table_id]
                    )
                else:
                    table_name = str(route.rt_table_id)

                if route.active:
                    state = 'Add'
                else:
                    state = 'Del'

                out.append((route.origin, table_name, route.prefix,
                            route.hostname, nexthops, route.timestamp, state))
        return out

    def show_router_id(self, router_id):
        out = []
        nodes = BgpSession.query.all(timestamp=self.__start_time)
        for node in nodes:
            if router_id is not None and node.peer_router_id != router_id:
                continue
            out.append((node.peer_router_id, node.hostname, node.peer_asn))
        return out

    def show_routes(self, prefix, hostname, ipv6=False, origin='*', vrf='*'):
        skip_ipv4_addr = {'127.0.0.0/8', '127.0.0.1/32', '127.0.0.0/32',
                          '127.255.255.255/32', '169.254.0.1/32'}
        skip_ipv6_addr = {'fe80::/64', '::/0', '::1/128', 'ff00::/8'}
        if hostname is not '*':
            nodes = [hostname]
        else:
            nodes = [node.hostname for node in self.node_lst]

        # Get table associated with VRF, if VRF is specified
        self.__build_vrf_table_map(hostname)
        table = '*'
        table_local = 255

        if vrf != '*':
            if hostname != '*':
                table = self.vrf_table_map[hostname]['vrf'][vrf]
            else:
                for node in nodes:
                    if (node in self.vrf_table_map and
                          vrf in self.vrf_table_map[node]['vrf']):
                        table = self.vrf_table_map[node]['vrf'][vrf]
                        break
                else:
                    yield []

        if prefix is not '*':
            entries = Route.query.lpm(prefix, nodes, table,
                                      timestamp=self.__start_time,
                                      is_ipv6=ipv6)
        elif hostname is not '*':
            entries = Route.query.filter(timestamp=self.__start_time,
                                         endtimestamp=self.__end_time,
                                         hostname=hostname, is_ipv6=ipv6)
        else:
            entries = Route.query.filter(timestamp=self.__start_time,
                                         endtimestamp=self.__end_time,
                                         is_ipv6=ipv6)
        out = []
        for route in entries:
            if route is None:
                out.append(None)
                continue
            route.rt_table_id = int(route.rt_table_id)
            if not route.is_ipv6 and route.prefix in skip_ipv4_addr:
                continue
            if route.is_ipv6 and route.prefix in skip_ipv6_addr:
                continue
            if (table != '*' and (route.rt_table_id != table and
                                  route.rt_table_id != table_local)):
                continue   # Need this to handle lpm which is not vrf specific
            if not route.nexthops:
                route.nexthops = [['None', 'Local']]
            if self.__is_route_blackholed(route.route_type):
                route.nexthops = [['None', 'Blackhole']]
            if origin is '*' or origin == route.origin:
                nexthops = ', '.join(
                    '%s: %s' % (nh[0], nh[1]) if nh[0] != 'None'
                    else '%s' % nh[1] for nh in sorted(route.nexthops)
                )
                if (route.hostname in self.vrf_table_map and
                       route.rt_table_id in self.vrf_table_map[route.hostname]['table']):
                    table_name = (
                        self.vrf_table_map[route.hostname]['table'][route.rt_table_id]
                    )
                else:
                    table_name = str(route.rt_table_id)
                out.append((route.origin,
                            table_name,
                            route.prefix,
                            route.hostname,
                            nexthops,
                            route.timestamp))
                if len(out) >= RedisQuery.PAGE_SIZE:
                    yield out
                    out = []
        if out:
            yield out

    def show_status(self):
        out = []
        for node in self.node_lst:
            ago = node.timestamp
            last_beat = (datetime.utcnow() -
                         datetime.utcfromtimestamp(int(node.timestamp)))
            if last_beat.total_seconds() > Heartbeat.HEARTBEAT_DEATH:
                status = AgentHealth.ROTTEN
            elif last_beat.total_seconds() <= Heartbeat.LIVELINESS_RATE:
                status = AgentHealth.FRESH
            else:
                status = AgentHealth.STALE
            out.append([str(node), node.lastboot, ago, status])
        return out

    def top_talkers_rx(self, count):
        return self.__top_talkers(count,
                                  [Counter.RX_BPS,
                                   Counter.RX_DROP_BPS,
                                   Counter.RX_ERR_BPS])

    def top_talkers_tx(self, count):
        return self.__top_talkers(count,
                                  [Counter.TX_BPS,
                                   Counter.TX_DROP_BPS,
                                   Counter.TX_ERR_BPS])

    def view(self, node, key):
        cmd = Command.query.get(timestamp=self.__start_time,
                                hostname=node,
                                key='-'.join(key))
        if cmd is None:
            raise NetQException(
                'Could\'nt locate command output for key %s' % ' '.join(key)
            )
        return cmd.timestamp, cmd.output

    def check_vlan_consistency(self, hostname='*', ifname=None):
        """Check all links have consistent VLANs
        """
        visited_links = {}
        unverified_links = []
        pvid_mismatch_links = []
        output = []

        self.__build_failed_node_lst()
        self.__build_lldp_info()
        br_ifname = '*'

        if ifname:
            link_if = Link.query.get(timestamp=self.__start_time,
                                     hostname=hostname, ifname=ifname)
            if link_if:
                if link_if.kind == LinkType.BRIDGE:
                    br_ifname = ifname
                elif link_if.kind == LinkType.BOND:
                    pass
                elif link_if.kind == LinkType.SWP:
                    if link_if.master != '':
                        master_if = Link.query.get(timestamp=self.__start_time,
                                                   hostname=hostname,
                                                   ifname=link_if.master)
                        if master_if:
                            if master_if.kind == LinkType.BOND:
                                ifname = master_if.ifname
                            elif master_if.kind == LinkType.BRIDGE:
                                br_ifname = master_if.ifname
                            else:
                                raise NetQException(
                                    'Link %s is not of type bond or bridge '
                                    'or swp' % link_if.ifname
                                )
                else:
                    raise NetQException(
                        'Link %s is not of type bond or bridge '
                        'or swp' % link_if.ifname
                    )

        bridges = Link.query.filter(timestamp=self.__start_time,
                                    hostname=hostname, ifname=br_ifname,
                                    kind=LinkType.BRIDGE)

        # For each bridge listed, visit every link and verify its vlan
        # consistency.
        for bridge in bridges:
            if not bridge.is_vlan_filtering:
                # Support coming in a later release
                continue

            for br_ifname in self.__get_slaves(bridge.hostname, bridge.ifname):
                br_ifname = br_ifname.encode('ascii', 'ignore')
                if ifname and br_ifname != ifname:
                    continue
                if bridge.hostname not in visited_links:
                    visited_links[bridge.hostname] = []

                if br_ifname in visited_links[bridge.hostname]:
                    continue
                else:
                    visited_links[bridge.hostname].append(br_ifname)

                br_if = Link.query.get(timestamp=self.__start_time,
                                       hostname=bridge.hostname,
                                       ifname=br_ifname)
                if not br_if:
                    continue

                # Now get its peer and check its vlan list
                nbr = None
                if br_if.kind and br_if.kind == LinkType.BOND:
                    for bond_slave in self.__get_slaves(br_if.hostname,
                                                        br_if.ifname):
                        bond_slave = bond_slave.encode('ascii', 'ignore')
                        nbr = Lldp.query.get(timestamp=self.__start_time,
                                             hostname=bridge.hostname,
                                             ifname=bond_slave)
                        if nbr:
                            break
                    # Check if this is part of CLAG and if so that
                    # its peer has the same config
                    clag_session = ClagSession.query.get(
                        timestamp=self.__start_time, hostname=bridge.hostname
                    )
                    if clag_session:
                        clag_peer_if = clag_session.dual_bonds.get(
                            br_ifname, None
                        )
                        peer_hostname = self.__get_clag_peer_hostname(
                            bridge.hostname, clag_session.peer_if)
                        if peer_hostname != '*' and clag_peer_if:
                            c_if = Link.query.get(
                                timestamp=self.__start_time,
                                hostname=peer_hostname,
                                ifname=clag_peer_if.encode('ascii', 'ignore')
                            )
                            if c_if:
                                if not self.__compare_vlans(br_if.vlans,
                                                            c_if.vlans):
                                    output.append(
                                        [bridge.hostname, br_if.ifname,
                                         br_if.vlans, peer_hostname,
                                         c_if.ifname, c_if.vlans])

                                if br_if.access_vlan != c_if.access_vlan:
                                    pvid_mismatch_links.append([
                                        bridge.hostname, br_if.ifname,
                                        br_if.access_vlan, peer_hostname,
                                        c_if.ifname, c_if.access_vlan])
                elif br_if.kind == LinkType.VXLAN:
                    # Should we be comparing the VNI/VLAN mapping ?
                    continue
                else:
                    nbr = Lldp.query.get(timestamp=self.__start_time,
                                         hostname=bridge.hostname,
                                         ifname=br_if.ifname)

                if not nbr:
                    unverified_links.append([bridge.hostname,
                                             br_if.ifname, br_if.vlans, '', ''])
                    continue

                if nbr.peer_hostname not in visited_links:
                    visited_links[nbr.peer_hostname] = []

                r_if = Link.query.get(timestamp=self.__start_time,
                                      hostname=nbr.peer_hostname,
                                      ifname=nbr.peer_ifname)
                if not r_if:
                    # We don't check any other type because LLDP is only on
                    # physical links
                    unverified_links.append([bridge.hostname,
                                             br_if.ifname, br_if.vlans,
                                             nbr.peer_hostname,
                                             nbr.peer_ifname])
                    if nbr.peer_ifname in visited_links[nbr.peer_hostname]:
                        visited_links[nbr.peer_hostname].append(
                            nbr.peer_ifname
                        )
                    continue

                if r_if.master != '':
                    # So we have a master link. Get that link's info.
                    m_if = Link.query.get(timestamp=self.__start_time,
                                          hostname=nbr.peer_hostname,
                                          ifname=r_if.master)
                    if not m_if or m_if.vlans == '':
                        unverified_links.append([bridge.hostname,
                                                 br_if.ifname,
                                                 br_if.vlans,
                                                 nbr.peer_hostname,
                                                 nbr.peer_ifname])
                        continue

                    if not self.__compare_vlans(br_if.vlans, m_if.vlans):
                        output.append([bridge.hostname, br_if.ifname,
                                       br_if.vlans, nbr.peer_hostname,
                                       m_if.ifname, m_if.vlans])

                    if br_if.access_vlan != m_if.access_vlan:
                        pvid_mismatch_links.append([bridge.hostname,
                                                    br_if.ifname,
                                                    br_if.access_vlan,
                                                    nbr.peer_hostname,
                                                    m_if.ifname,
                                                    m_if.access_vlan])

                    if m_if.ifname not in visited_links[nbr.peer_hostname]:
                        visited_links[nbr.peer_hostname].append(m_if.ifname)

                elif r_if.vlans != '':
                    if not self.__compare_vlans(br_if.vlans, r_if.vlans):
                        output.append([bridge.hostname, br_if.ifname,
                                       br_if.vlans, nbr.peer_hostname,
                                       r_if.ifname, r_if.vlans])

                    if br_if.access_vlan != r_if.access_vlan:
                        pvid_mismatch_links.append([bridge.hostname,
                                                    br_if.ifname,
                                                    br_if.access_vlan,
                                                    nbr.peer_hostname,
                                                    r_if.ifname,
                                                    r_if.access_vlan])

                    if nbr.peer_ifname in visited_links[nbr.peer_hostname]:
                        visited_links[nbr.peer_hostname].append(
                            nbr.peer_ifname
                        )

        return unverified_links, pvid_mismatch_links, output

    @staticmethod
    def update_config(server_address):
        try:
            redisdb.ping_server(server_address)
        except Exception:  # pylint: disable=broad-except
            raise RuntimeError('Could not connect to server %s' %
                               server_address)
        conf = config.Config(DefaultPaths.CONF_FILE)
        try:
            conf.set_field(config.Config.CommonConfig.section,
                           config.Config.CommonConfig.server.name,
                           server_address)
        except Exception as ex:
            raise RuntimeError('Failed to update config file %s. Error %s' %
                               (DefaultPaths.CONF_FILE, ex))
        return 'Success!'

    ##########################
    # TAB Completion functions
    ##########################
    @staticmethod
    def view_complete(hostname):
        """Return possible completions for current pos.
        """
        server_addr = NetQ.__get_config_server_addr()
        if server_addr is None:
            return
        if server_addr is not None and 'http' in server_addr:
            restapi.set_connection_settings(server_addr)
        else:
            redisdb.set_connection_settings(server_addr)
        if not hostname:
            return []
        choices = [cmd.key.replace('-', ' ')
                   for cmd in Command.query.filter(hostname=hostname, key='*')]
        return sorted(choices)

    @staticmethod
    def hostname_complete(args, # pylint: disable=unused-argument
                          ended_with_space, last_argv):
        """
        Completion for hostname
        """
        out = []
        server_addr = NetQ.__get_config_server_addr()
        if server_addr is None:
            return []
        if server_addr is not None and 'http' in server_addr:
            restapi.set_connection_settings(server_addr)
        else:
            redisdb.set_connection_settings(server_addr)
        for node in Node.query.all():
            if ended_with_space or node.hostname.startswith(last_argv):
                out.append((node.hostname, node.hostname))

        if not out:
            out.append(('<hostname>', 'Remote hostname'))

        return out

    @staticmethod
    def hostname_match(argv_word, use_fuzzy, tab_completing=False):
        """
        <as-path-access-list>
        """
        try:
            if ipaddr.IPAddress(argv_word):
                return False
        except ValueError:
            pass

        server_addr = NetQ.__get_config_server_addr()
        if server_addr is None:
            return True
        if server_addr is not None and 'http' in server_addr:
            restapi.set_connection_settings(server_addr)
        else:
            redisdb.set_connection_settings(server_addr)

        node_lst = sorted(node.hostname for node in Node.query.all())
        if use_fuzzy:
            if ' ' not in argv_word:
                return True
        else:
            for node in node_lst:
                if tab_completing and node.startswith(argv_word):
                    return True
                if argv_word in node:
                    return True
        return False

    @staticmethod
    def interface_complete(args, ended_with_space, last_argv):
        """
        Completion for remote interface name
        """
        out = []
        server_addr = NetQ.__get_config_server_addr()
        if server_addr is None:
            return []
        if server_addr is not None and 'http' in server_addr:
            restapi.set_connection_settings(server_addr)
        else:
            redisdb.set_connection_settings(server_addr)

        hostname = args.get('<hostname>')
        if not hostname:
            return []
        elif isinstance(hostname, list):
            hostname = hostname[0]

        plinks = Link.query.filter(hostname=hostname)
        links = plinks

        for link in links:
            if ended_with_space or link.ifname.startswith(last_argv):
                out.append((link.ifname, link.ifname))

        if not out:
            out.append(('<remote-interface>', 'Interface name on %s' %
                        hostname))
        return out

    @staticmethod
    def physical_interface_complete(args, ended_with_space, last_argv):
        """
        Completion for remote physical interface name
        """
        out = []
        server_addr = NetQ.__get_config_server_addr()
        if server_addr is None:
            return []
        if server_addr is not None and 'http' in server_addr:
            restapi.set_connection_settings(server_addr)
        else:
            redisdb.set_connection_settings(server_addr)

        hostname = args.get('<hostname>')
        if not hostname:
            return []
        elif isinstance(hostname, list):
            hostname = hostname[0]

        links = Link.query.filter(hostname=hostname)

        for link in links:
            if link.kind in (LinkType.BOND, LinkType.SWP):
                if ended_with_space or link.ifname.startswith(last_argv):
                    out.append((link.ifname, link.ifname))

        if not out:
            out.append(('<remote-physical-interface>', 'Interface name on %s' %
                        hostname))
        return out

    @staticmethod
    def interface_match(argv_word, use_fuzzy, # pylint: disable=unused-argument
                        tab_completing=False): # pylint: disable=unused-argument
        """
        Match for remote interface name
        """
        keywords = ['around', 'history', 'origin', 'json', 'vlan', 'bond',
                    'bridge', 'eth', 'swp', 'vlan', 'vxlan', 'loopback',
                    'macvlan']

        if argv_word in keywords:
            return False

        try:
            if ipaddr.IPAddress(argv_word):
                return False
        except ValueError:
            pass

        try:
            if ipaddr.IPNetwork(argv_word):
                return False
        except ValueError:
            if (re.match(r'(?:[0-9A-Fa-f]{2}[:-]){5}[0-9A-Fa-f]{2}',
                         argv_word) or
                    re.match(r'[0-9A-Fa-f]{4}\.[0-9A-Fa-f]{4}\.[0-9A-Fa-f]{4}',
                             argv_word)):
                return False

        server_addr = NetQ.__get_config_server_addr()
        if server_addr is None:
            return []
        if server_addr is not None and 'http' in server_addr:
            restapi.set_connection_settings(server_addr)
        else:
            redisdb.set_connection_settings(server_addr)

        hostname = get_hostname()
        if not hostname:
            return []

        plinks = Link.query.filter(hostname=hostname)
        links = plinks
        if links:
            return True
        return False

    @staticmethod
    def os_match(argv_word, use_fuzzy, # pylint: disable=unused-argument
                 tab_completing=False): # pylint: disable=unused-argument
        """
        Match for os entries
        """
        server_addr = NetQ.__get_config_server_addr()
        if server_addr is None:
            return []
        if server_addr is not None and 'http' in server_addr:
            restapi.set_connection_settings(server_addr)
        else:
            redisdb.set_connection_settings(server_addr)

        hostname = get_hostname()
        if not hostname:
            return []

        hosts = OS.query.filter(hostname=hostname)
        if hosts:
            return True
        return False

    @staticmethod
    def os_version_complete(args, ended_with_space, last_argv):
        """
        Completion for os version
        """
        out = []
        server_addr = NetQ.__get_config_server_addr()
        if server_addr is None:
            return []
        if server_addr is not None and 'http' in server_addr:
            restapi.set_connection_settings(server_addr)
        else:
            redisdb.set_connection_settings(server_addr)

        hostname = args.get('<hostname>')
        if not hostname:
            hostname = '*'
        elif isinstance(hostname, list):
            hostname = hostname[0]
        oses = OS.query.filter(hostname=hostname)

        for oss in oses:
            if ended_with_space or oss.version_id.startswith(last_argv):
                out.append((oss.version_id,
                            '%s version' %oss.name))
        if not out:
            out.append(('<os-version>', 'Operating System version'))
        return out

    @staticmethod
    def os_name_complete(args, ended_with_space, last_argv):
        """
        Completion for os version
        """
        out = []
        server_addr = NetQ.__get_config_server_addr()
        if server_addr is None:
            return []
        if server_addr is not None and 'http' in server_addr:
            restapi.set_connection_settings(server_addr)
        else:
            redisdb.set_connection_settings(server_addr)

        hostname = args.get('<hostname>')
        if not hostname:
            hostname = '*'
        elif isinstance(hostname, list):
            hostname = hostname[0]
        oses = OS.query.filter(hostname=hostname)

        for os in oses:
            if ended_with_space or (last_argv.lower() in os.name.lower()):
                out.append((os.name, 'Operating System name'))
        if not out:
            out.append(('<os-name>', 'Operating System name'))
        return out

    @staticmethod
    def cpu_match(argv_word, use_fuzzy, # pylint: disable=unused-argument
                  tab_completing=False): # pylint: disable=unused-argument
        """
        Match for cpu
        """
        server_addr = NetQ.__get_config_server_addr()
        if server_addr is None:
            return []
        if server_addr is not None and 'http' in server_addr:
            restapi.set_connection_settings(server_addr)
        else:
            redisdb.set_connection_settings(server_addr)

        hostname = get_hostname()
        if not hostname:
            return []

        hosts = CPU.query.filter(hostname=hostname)
        if hosts:
            return True
        return False

    @staticmethod
    def cpu_arch_complete(args, ended_with_space, last_argv):
        """
        Completion for processor architecture
        """
        out = []
        server_addr = NetQ.__get_config_server_addr()
        if server_addr is None:
            return []
        if server_addr is not None and 'http' in server_addr:
            restapi.set_connection_settings(server_addr)
        else:
            redisdb.set_connection_settings(server_addr)

        hostname = args.get('<hostname>')
        if not hostname:
            hostname = '*'
        elif isinstance(hostname, list):
            hostname = hostname[0]
        procs = CPU.query.filter(hostname=hostname)

        for proc in procs:
            if ended_with_space or (last_argv.lower() in proc.arch.lower()):
                out.append((proc.arch, 'CPU Architecture'))
        if not out:
            out.append(('<cpu-arch>', 'CPU Architecture'))
        return out

    @staticmethod
    def cpu_model_complete(args, ended_with_space, last_argv):
        """
        Completion for processor model
        """
        out = []
        server_addr = NetQ.__get_config_server_addr()
        if server_addr is None:
            return []
        if server_addr is not None and 'http' in server_addr:
            restapi.set_connection_settings(server_addr)
        else:
            redisdb.set_connection_settings(server_addr)

        hostname = args.get('<hostname>')
        if not hostname:
            hostname = '*'
        elif isinstance(hostname, list):
            hostname = hostname[0]
        procs = CPU.query.filter(hostname=hostname)

        for proc in procs:
            if ended_with_space or (last_argv.lower() in proc.model.lower()):
                out.append((proc.model, 'CPU Model'))
        if not out:
            out.append(('<cpu-model>', 'CPU Model'))
        return out

    @staticmethod
    def asic_match(argv_word, use_fuzzy, # pylint: disable=unused-argument
                   tab_completing=False): # pylint: disable=unused-argument
        """
        Match for mgmt processor architecture
        """
        server_addr = NetQ.__get_config_server_addr()
        if server_addr is None:
            return []
        if server_addr is not None and 'http' in server_addr:
            restapi.set_connection_settings(server_addr)
        else:
            redisdb.set_connection_settings(server_addr)

        hostname = get_hostname()
        if not hostname:
            return []

        hosts = ASIC.query.filter(hostname=hostname)
        if hosts:
            return True
        return False

    @staticmethod
    def asic_vendor_complete(args, ended_with_space, last_argv):
        """
        Completion for network ASIC vendor
        """
        out = []
        server_addr = NetQ.__get_config_server_addr()
        if server_addr is None:
            return []
        if server_addr is not None and 'http' in server_addr:
            restapi.set_connection_settings(server_addr)
        else:
            redisdb.set_connection_settings(server_addr)

        hostname = args.get('<hostname>')
        if not hostname:
            hostname = '*'
        elif isinstance(hostname, list):
            hostname = hostname[0]
        procs = ASIC.query.filter(hostname=hostname)

        for proc in procs:
            if ended_with_space or (last_argv.lower() in proc.vendor.lower()):
                out.append((proc.vendor, 'Network ASIC Vendor'))
        if not out:
            out.append(('<asic-vendor>',
                        'Network ASIC Vendor'))
        return out

    @staticmethod
    def asic_model_complete(args, ended_with_space, last_argv):
        """
        Completion for network processor model
        """
        out = []
        server_addr = NetQ.__get_config_server_addr()
        if server_addr is None:
            return []
        if server_addr is not None and 'http' in server_addr:
            restapi.set_connection_settings(server_addr)
        else:
            redisdb.set_connection_settings(server_addr)

        hostname = args.get('<hostname>')
        if not hostname:
            hostname = '*'
        elif isinstance(hostname, list):
            hostname = hostname[0]
        procs = ASIC.query.filter(hostname=hostname)

        for proc in procs:
            if ended_with_space or (last_argv.lower() in proc.model.lower()):
                out.append((proc.model, 'Network ASIC Model'))
        if not out:
            out.append(('<asic-model>', 'Network ASIC Model'))
        return out

    @staticmethod
    def asic_model_id_complete(args, ended_with_space, last_argv):
        """
        Completion for network processor model id
        """
        out = []
        server_addr = NetQ.__get_config_server_addr()
        if server_addr is None:
            return []
        if server_addr is not None and 'http' in server_addr:
            restapi.set_connection_settings(server_addr)
        else:
            redisdb.set_connection_settings(server_addr)

        hostname = args.get('<hostname>')
        if not hostname:
            hostname = '*'
        elif isinstance(hostname, list):
            hostname = hostname[0]
        procs = ASIC.query.filter(hostname=hostname)

        for proc in procs:
            if ended_with_space or (last_argv.lower() in proc.model_id.lower()):
                out.append((proc.model_id, 'Network ASIC Model ID'))
        if not out:
            out.append(('<asic-model-id>', 'Network ASIC Model ID'))
        return out

    @staticmethod
    def board_match(argv_word, use_fuzzy, # pylint: disable=unused-argument
                    tab_completing=False): # pylint: disable=unused-argument
        """
        Match for os entries
        """
        server_addr = NetQ.__get_config_server_addr()
        if server_addr is None:
            return []
        if server_addr is not None and 'http' in server_addr:
            restapi.set_connection_settings(server_addr)
        else:
            redisdb.set_connection_settings(server_addr)

        hostname = get_hostname()
        if not hostname:
            return []

        boards = Board.query.filter(hostname=hostname)
        if boards:
            return True
        return False

    @staticmethod
    def board_vendor_complete(args, ended_with_space, last_argv):
        """
        Completion for board vendor
        """
        out = []
        server_addr = NetQ.__get_config_server_addr()
        if server_addr is None:
            return []
        if server_addr is not None and 'http' in server_addr:
            restapi.set_connection_settings(server_addr)
        else:
            redisdb.set_connection_settings(server_addr)

        hostname = args.get('<hostname>')
        if not hostname:
            hostname = '*'
        elif isinstance(hostname, list):
            hostname = hostname[0]
        boards = Board.query.filter(hostname=hostname)

        for board in boards:
            if ended_with_space or (last_argv.lower() in board.vendor.lower()):
                out.append((board.vendor, 'Board Vendor'))

        if not out:
            out.append(('<board-vendor>', 'Board Vendor'))
        return out

    @staticmethod
    def board_model_complete(args, ended_with_space, last_argv):
        """
        Completion for switch model
        """
        out = []
        server_addr = NetQ.__get_config_server_addr()
        if server_addr is None:
            return []
        if server_addr is not None and 'http' in server_addr:
            restapi.set_connection_settings(server_addr)
        else:
            redisdb.set_connection_settings(server_addr)

        hostname = args.get('<hostname>')
        if not hostname:
            hostname = '*'
        elif isinstance(hostname, list):
            hostname = hostname[0]
        boards = Board.query.filter(hostname=hostname)

        for board in boards:
            if ended_with_space or (last_argv.lower() in board.model.lower()):
                out.append((board.model, 'Board Model'))

        if not out:
            out.append(('<board-model>', 'Board Model'))
        return out

    @staticmethod
    def disk_match(argv_word, use_fuzzy, # pylint: disable=unused-argument
                   tab_completing=False): # pylint: disable=unused-argument
        """
        Match for os entries
        """
        server_addr = NetQ.__get_config_server_addr()
        if server_addr is None:
            return []
        if server_addr is not None and 'http' in server_addr:
            restapi.set_connection_settings(server_addr)
        else:
            redisdb.set_connection_settings(server_addr)

        hostname = get_hostname()
        if not hostname:
            return []

        disks = Disk.query.filter(hostname=hostname)
        if disks:
            return True
        return False

    @staticmethod
    def disk_name_complete(args, ended_with_space, last_argv):
        """
        Completion for disk name
        """
        out = []
        server_addr = NetQ.__get_config_server_addr()
        if server_addr is None:
            return []
        if server_addr is not None and 'http' in server_addr:
            restapi.set_connection_settings(server_addr)
        else:
            redisdb.set_connection_settings(server_addr)

        hostname = args.get('<hostname>')
        if not hostname:
            hostname = '*'
        elif isinstance(hostname, list):
            hostname = hostname[0]
        disks = Disk.query.filter(hostname=hostname)

        for disk in disks:
            if ended_with_space or (last_argv.lower() in disk.name.lower()):
                out.append((disk.name, 'Disk Name'))

        if not out:
            out.append(('<disk-name>', 'Disk Name'))
        return out

    @staticmethod
    def disk_size_complete(args, ended_with_space, last_argv):
        """
        Completion for disk size
        """
        out = []
        server_addr = NetQ.__get_config_server_addr()
        if server_addr is None:
            return []
        if server_addr is not None and 'http' in server_addr:
            restapi.set_connection_settings(server_addr)
        else:
            redisdb.set_connection_settings(server_addr)

        hostname = args.get('<hostname>')
        if not hostname:
            hostname = '*'
        elif isinstance(hostname, list):
            hostname = hostname[0]
        disks = Disk.query.filter(hostname=hostname)

        for disk in disks:
            if ended_with_space or (disk.lower().startswith(last_argv.lower())):
                out.append((disk.size, 'Disk Size'))

        if not out:
            out.append(('<disk-size>', 'Disk Size'))
        return out

    @staticmethod
    def disk_transport_complete(args, ended_with_space, last_argv):
        """
        Completion for disk transport
        """
        out = []
        server_addr = NetQ.__get_config_server_addr()
        if server_addr is None:
            return []
        if server_addr is not None and 'http' in server_addr:
            restapi.set_connection_settings(server_addr)
        else:
            redisdb.set_connection_settings(server_addr)

        hostname = args.get('<hostname>')
        if not hostname:
            hostname = '*'
        elif isinstance(hostname, list):
            hostname = hostname[0]
        disks = Disk.query.filter(hostname=hostname)

        for disk in disks:
            if ended_with_space or (last_argv.lower() in disk.transport.lower()):
                out.append((disk.size, 'Disk Transport'))

        if not out:
            out.append(('<disk-transport>', 'Disk Transport'))
        return out

    @staticmethod
    def disk_vendor_complete(args, ended_with_space, last_argv):
        """
        Completion for disk vendor
        """
        out = []
        server_addr = NetQ.__get_config_server_addr()
        if server_addr is None:
            return []
        if server_addr is not None and 'http' in server_addr:
            restapi.set_connection_settings(server_addr)
        else:
            redisdb.set_connection_settings(server_addr)

        hostname = args.get('<hostname>')
        if not hostname:
            hostname = '*'
        elif isinstance(hostname, list):
            hostname = hostname[0]
        disks = Disk.query.filter(hostname=hostname)

        for disk in disks:
            if ended_with_space or (last_argv.lower() in disk.vendor.lower()):
                out.append((disk.vendor, 'Disk Vendor'))

        if not out:
            out.append(('<disk-vendor>', 'Disk Vendor'))
        return out

    @staticmethod
    def memory_match(argv_word, use_fuzzy, # pylint: disable=unused-argument
                     tab_completing=False): # pylint: disable=unused-argument
        """
        Match for memory entries
        """
        server_addr = NetQ.__get_config_server_addr()
        if server_addr is None:
            return []
        if server_addr is not None and 'http' in server_addr:
            restapi.set_connection_settings(server_addr)
        else:
            redisdb.set_connection_settings(server_addr)

        hostname = get_hostname()
        if not hostname:
            return []

        memorys = Memory.query.filter(hostname=hostname)
        if memorys:
            return True
        return False

    @staticmethod
    def memory_type_complete(args, ended_with_space, last_argv):
        """
        Completion for memory type
        """
        out = []
        server_addr = NetQ.__get_config_server_addr()
        if server_addr is None:
            return []
        if server_addr is not None and 'http' in server_addr:
            restapi.set_connection_settings(server_addr)
        else:
            redisdb.set_connection_settings(server_addr)

        hostname = args.get('<hostname>')
        if not hostname:
            hostname = '*'
        elif isinstance(hostname, list):
            hostname = hostname[0]
        memorys = Memory.query.filter(hostname=hostname)

        for memory in memorys:
            if ended_with_space or (last_argv.lower() in memory.m_type.lower()):
                out.append((memory.m_type, 'Memory type'))

        if not out:
            out.append(('<memory-type>', 'Memory type'))
        return out

    @staticmethod
    def memory_size_complete(args, ended_with_space, last_argv):
        """
        Completion for memory size
        """
        out = []
        server_addr = NetQ.__get_config_server_addr()
        if server_addr is None:
            return []
        if server_addr is not None and 'http' in server_addr:
            restapi.set_connection_settings(server_addr)
        else:
            redisdb.set_connection_settings(server_addr)

        hostname = args.get('<hostname>')
        if not hostname:
            hostname = '*'
        elif isinstance(hostname, list):
            hostname = hostname[0]
        memorys = Memory.query.filter(hostname=hostname)

        for memory in memorys:
            if ended_with_space or (memory.size.lower().startswith(last_argv.lower())):
                out.append((memory.size, 'Memory size'))

        if not out:
            out.append(('<memory-size>', 'Memory Size'))
        return out

    @staticmethod
    def memory_vendor_complete(args, ended_with_space, last_argv):
        """
        Completion for memory vendor
        """
        out = []
        server_addr = NetQ.__get_config_server_addr()
        if server_addr is None:
            return []
        if server_addr is not None and 'http' in server_addr:
            restapi.set_connection_settings(server_addr)
        else:
            redisdb.set_connection_settings(server_addr)

        hostname = args.get('<hostname>')
        if not hostname:
            hostname = '*'
        elif isinstance(hostname, list):
            hostname = hostname[0]
        memorys = Memory.query.filter(hostname=hostname)

        for memory in memorys:
            if ended_with_space or (last_argv.lower() in memory.vendor.lower()):
                out.append((memory.vendor, 'Memory vendor'))

        if not out:
            out.append(('<memory-vendor>', 'Memory Vendor'))
        return out

    @staticmethod
    def ip_server_match(argv_word,
                        use_fuzzy, # pylint: disable=unused-argument
                        tab_completing=False): # pylint: disable=unused-argument
        """
        Match only for IP addresses
        """
        try:
            if ipaddr.IPAddress(argv_word):
                return True
        except ValueError:
            pass
        return False

    @staticmethod
    def vrf_complete(args, ended_with_space, last_argv):
        """
        Completion for list of VRFs
        """
        out = []
        server_addr = NetQ.__get_config_server_addr()
        if server_addr is None:
            return []
        if server_addr is not None and 'http' in server_addr:
            restapi.set_connection_settings(server_addr)
        else:
            redisdb.set_connection_settings(server_addr)

        for link in Link.query.filter(kind='vrf'):
            if ended_with_space or link.ifname.startswith(last_argv):
                out.append((link.ifname, link.ifname))

        if not out:
            out.append('<vrf>', 'Name of VRF')

        return out

    @staticmethod
    def vrf_match(argv_word,
                  use_fuzzy,  # pylint: disable=unused-argument
                  tab_completing=False):  # pylint: disable=unused-argument
        """
        """
        keywords = ['around', 'history', 'origin', 'json', 'vlan', 'bond',
                    'bridge', 'eth', 'swp', 'vlan', 'vrf', 'vxlan', 'loopback',
                    'macvlan', 'os', 'cpu', 'board', 'asic', 'disk']

        if argv_word in keywords:
            return False

        try:
            if ipaddr.IPAddress(argv_word):
                return False
        except ValueError:
            pass

        try:
            if ipaddr.IPNetwork(argv_word):
                return False
        except ValueError:
            if (re.match(r'(?:[0-9A-Fa-f]{2}[:-]){5}[0-9A-Fa-f]{2}',
                         argv_word) or
                    re.match(r'[0-9A-Fa-f]{4}\.[0-9A-Fa-f]{4}\.[0-9A-Fa-f]{4}',
                             argv_word)):
                return False

        server_addr = NetQ.__get_config_server_addr()
        if server_addr is None:
            return True
        if server_addr is not None and 'http' in server_addr:
            restapi.set_connection_settings(server_addr)
        else:
            redisdb.set_connection_settings(server_addr)

        vrfs = []
        for link in Link.query.filter(kind='vrf'):
            vrfs.append(link.ifname)

        return vrfs

    @staticmethod
    def generic_match(argv_word,
                      use_fuzzy, # pylint: disable=unused-argument
                      tab_completing=False): # pylint: disable=unused-argument
        """
        Reject keywords & IP Addr from being accepted as value for params
        """
        keywords = ['around', 'history', 'origin', 'json', 'vlan', 'bond',
                    'bridge', 'eth', 'swp', 'vlan', 'vrf', 'vxlan', 'loopback',
                    'macvlan', 'os', 'cpu', 'board', 'asic', 'disk']

        if argv_word in keywords:
            return False

        try:
            if ipaddr.IPAddress(argv_word):
                return False
        except ValueError:
            pass

        try:
            if ipaddr.IPNetwork(argv_word):
                return False
        except ValueError:
            if (re.match(r'(?:[0-9A-Fa-f]{2}[:-]){5}[0-9A-Fa-f]{2}',
                         argv_word) or
                    re.match(r'[0-9A-Fa-f]{4}\.[0-9A-Fa-f]{4}\.[0-9A-Fa-f]{4}',
                             argv_word)):
                return False

        return True

    @property
    def node_lst(self):
        if self.__node_lst is None:
            self.__node_lst = sorted(Node.query.all())
        return self.__node_lst
