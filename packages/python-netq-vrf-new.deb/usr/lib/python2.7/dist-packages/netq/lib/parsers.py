# vim: tabstop=4 shiftwidth=4 softtabstop=4
# Copyright 2016 Cumulus Networks, Inc. All rights reserved.
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc.
# 51 Franklin Street, Fifth Floor
# Boston, MA  02110-1301, USA.
from __future__ import absolute_import

import json
import subprocess
import time

from netq.common.enums import (
    Daemons,
    RunningService
)
from netq.orm import HOSTNAME
from netq.orm.memdb.models import (
    Lldp
)
from netq.orm.redisdb.models import (
    BgpSession,
    ClagSession,
    MstpInfo,
    OspfIf,
    OspfNbr,
    Services,
    OS,
    CPU,
    ASIC,
    Board,
    Disk,
    Memory)


def build_lldp_summary(hostname, timestamp, cmd_output):
    try:
        json_op = json.loads(cmd_output)
    except ValueError:
        return

    for values in json_op.itervalues():
        for value in values:
            try:
                for lldp in value['interface']:
                    lldpobj = Lldp()
                    lldpobj.hostname = hostname
                    lldpobj.timestamp = timestamp

                    try:
                        lldpobj.ifname = str(lldp['name'])
                        lldpobj.peer_hostname = str(
                            lldp['chassis'][0]['name'][0]['value']
                        )
                        if '.' in lldpobj.peer_hostname:
                            lldpobj.peer_hostname = (
                                lldpobj.peer_hostname.split('.')[0]
                            )
                        lldpobj.peer_ifname = str(
                            lldp['port'][0]['id'][0]['value']
                        )

                        for cap in lldp['chassis'][0]['capability']:
                            if cap['type'] == 'Bridge':
                                lldpobj.lldp_peer_bridge = cap['enabled']
                            elif cap['type'] == 'Router':
                                lldpobj.lldp_peer_router = cap['enabled']

                        lldpobj.lldp_peer_os = str(
                            lldp['chassis'][0]['descr'][0]['value']
                        )
                    except Exception:
                        continue
                    else:
                        lldpobj.save()
            except Exception:
                continue

def is_bridge_vlan_filtering(name):
    """Determine if this bridge is a vlan filtering bridge or not
    """
    try:
        with open('/sys/class/net/%s/bridge/vlan_filtering' % name, 'r') \
          as fname:
            return int(fname.readline().strip()) == 1
    except IOError:
        return False


def process_bgp_neighbors(output, svc_failed=False):
    """Build summary of BGP node info, such as ASN & RID
    """
    try:
        json_out = json.loads(output)
    except ValueError:
        # We treat invalid JSON as the infomation terminating
        m_bgp_session = BgpSession.memmodel()
        for entry in m_bgp_session.query.filter(hostname=HOSTNAME):
            old_bgp_entry = BgpSession()
            old_bgp_entry.copy(entry)
            if not svc_failed:
                old_bgp_entry.delete()
            else:
                old_bgp_entry.state = 'Fail'
                old_bgp_entry.save()
        return -1

    now = long(time.time())

    for vrf in json_out:
        vrf_id = json_out[vrf]['vrfId']
        for key in json_out[vrf]:
            if key == 'vrfName' or key == 'vrfId':
                continue

            session = json_out[vrf][key]

            bgp_nbr = BgpSession()
            bgp_nbr.vrf = vrf.encode('ascii', 'ignore')
            bgp_nbr.vrfid = vrf_id
            bgp_nbr.peer_name = key.encode('ascii', 'ignore')
            bgp_nbr.state = session['bgpState'].encode('ascii', 'ignore')
            bgp_nbr.peer_router_id = (
                session['remoteRouterId'].encode('ascii', 'ignore')
            )
            bgp_nbr.peer_asn = session['remoteAs']
            bgp_nbr.peer_hostname = session.get('hostname', '').encode('ascii',
                                                                       'ignore')
            bgp_nbr.asn = int(session['localAs'])
            bgp_nbr.reason = 'N/A'
            if bgp_nbr.state == 'Established':
                if 'bgpTimerUpEstablishedEpoch' in session:
                    bgp_nbr.up_time = \
                        long(now - session['bgpTimerUpEstablishedEpoch'])
                else:
                    bgp_nbr.up_time = long((now * 1000) - session['bgpTimerUp'])
            else:
                bgp_nbr.up_time = 0L
            bgp_nbr.upd8_rx = session['messageStats']['updatesRecv']
            bgp_nbr.upd8_tx = session['messageStats']['updatesSent']
            afi_session = session['addressFamilyInfo']
            if 'lastResetDueTo' in afi_session:
                bgp_nbr.reason = (
                    afi_session['lastResetDueTo'].encode('ascii', 'ignore')
                )
                bgp_nbr.last_reset_time = (
                    long((now * 1000) - afi_session['lastResetTimerMsecs'])
                )
            else:
                bgp_nbr.last_reset_time = 0L
            if 'IPv4 Unicast' in session['addressFamilyInfo']:
                bgp_nbr.ipv4_pfx_rcvd = (
                    int(afi_session['IPv4 Unicast']['acceptedPrefixCounter'])
                )
            else:
                bgp_nbr.ipv4_pfx_rcvd = 0
            if 'IPv6 Unicast' in session['addressFamilyInfo']:
                bgp_nbr.ipv6_pfx_rcvd = (
                    int(afi_session['IPv6 Unicast']['acceptedPrefixCounter'])
                )
            else:
                bgp_nbr.ipv6_pfx_rcvd = 0
            if afi_session.has_key('connectionsDropped'):
                bgp_nbr.conn_dropped = afi_session['connectionsDropped']
                bgp_nbr.conn_estd = afi_session['connectionsEstablished']
            elif session.has_key('connectionsDropped'):
                bgp_nbr.conn_dropped = session['connectionsDropped']
                bgp_nbr.conn_estd = session['connectionsEstablished']
            bgp_nbr.save()

    return 0


def process_clagctl(cmd_output, svc_failed=False):
    """Build clag info for node
    """
    try:
        json_out = json.loads(cmd_output)
    except ValueError:
        # We treat invalid JSON as the infomation terminating
        m_clag_session = ClagSession.memmodel()
        for entry in m_clag_session.query.filter(hostname=HOSTNAME):
            old_clag_entry = ClagSession()
            old_clag_entry.copy(entry)
            if not svc_failed:
                old_clag_entry.delete()
            else:
                old_clag_entry.peer_state = 'Fail'
                old_clag_entry.save()
        return -1

    if 'errorMsg' in json_out:
        m_clag_session = ClagSession.memmodel()
        for entry in m_clag_session.query.filter(hostname=HOSTNAME):
            old_clag_entry = ClagSession()
            old_clag_entry.copy(entry)
            if not svc_failed:
                old_clag_entry.delete()
            else:
                old_clag_entry.state = 'Fail'
                old_clag_entry.save()
        return -1

    clag_conflicted_bonds = []
    clag_singly_attached_bonds = []
    clag_proto_down_bonds = []
    dual_attach_bonds = {}

    clag_session = ClagSession()

    clag_session.peer_state = json_out['status']['peerAlive']

    clag_session.peer_if = (
        json_out['status']['peerIf'].encode('ascii', 'ignore')
    )
    clag_session.peer_role = json_out['status']['peerRole'].encode('ascii',
                                                                   'ignore')
    clag_session.role = json_out['status']['ourRole'].encode('ascii', 'ignore')
    clag_session.clag_sysmac = json_out['status']['sysMac'].encode('ascii',
                                                                   'ignore')
    clag_session.backup_ip = (
        json_out['status']['backupIp'].encode('ascii', 'ignore')
    )
    clag_session.backup_ip_active = json_out['status']['backupActive']

    for iface in json_out['clagIntfs']:
        if json_out['clagIntfs'][iface]['status'] == 'dual':
            dual_attach_bonds[iface] = json_out['clagIntfs'][iface]['peerIf']
        else:
            clag_singly_attached_bonds.append(iface)
        if 'conflicts' in json_out['clagIntfs'][iface]:
            clag_conflicted_bonds.append(
                [iface,
                 json_out['clagIntfs'][iface]['conflicts'][0].
                 encode('ascii', 'ignore')]
            )
        if 'protoDown' in json_out['clagIntfs'][iface]:
            string = (
                json_out['clagIntfs'][iface]['protoDown'][0].encode('ascii',
                                                                    'ignore')
            )
            clag_proto_down_bonds.append([iface, string])

    clag_session.conflicted_bonds = clag_conflicted_bonds
    clag_session.single_bonds = clag_singly_attached_bonds
    clag_session.proto_down_bonds = clag_proto_down_bonds
    clag_session.dual_bonds = dual_attach_bonds

    # If the CLAG sysmac changed, we need to delete the older entry.
    m_clag_session = ClagSession.memmodel()
    for entry in m_clag_session.query.filter(hostname=HOSTNAME):
        if entry.clag_sysmac != clag_session.clag_sysmac:
            old_clag_entry = ClagSession()
            old_clag_entry.copy(entry)
            old_clag_entry.delete()
    clag_session.save()
    return 0

def process_ospf_neighbors(cmd_output, svc_failed=False):
    """Process OSPF neighbors info
    """
    try:
        json_out = json.loads(cmd_output)
    except ValueError:
        pass

    m_ospfnbr = OspfNbr.memmodel()
    for entry in m_ospfnbr.query.filter(hostname=HOSTNAME):
        new_entry = OspfNbr()
        key = entry.peer_id
        if key not in json_out:
            new_entry.copy(entry)
            if svc_failed:
                new_entry.delete()
            else:
                new_entry.state = 'Fail'
                new_entry.save()

    # Handle new entries
    for key in json_out:
        entry = OspfNbr()
        entry.peer_id = key.encode('ascii', 'ignore')
        entry.peer_addr = json_out[key]['address'].encode('ascii', 'ignore')
        entry.state = json_out[key]['state'].encode('ascii', 'ignore')
        entry.ifname = json_out[key]['ifaceName'].encode('ascii',
                                                         'ignore').split(':')[0]
        entry.save()


def process_mstpall(cmd_output, svc_failed=False):
    """Build mstp info for node
    """
    try:
        json_out = json.loads(cmd_output)
    except ValueError:
        # We treat invalid JSON as the infomation terminating
        m_mstp_session = MstpInfo.memmodel()
        for entry in m_mstp_session.query.filter(hostname=HOSTNAME):
            old_mstp_entry = MstpInfo()
            old_mstp_entry.copy(entry)
            if not svc_failed:
                old_mstp_entry.delete()
            else:
                old_mstp_entry.state = False
        return -1

    now = long(time.time())

    for key in json_out:
        bridge = json_out[key][key]
        # We don't handle vlan-unaware bridges yet
        if not 'vlanFilter' in bridge:
            continue
        mstp_session = MstpInfo()
        edge_ports = []
        network_ports = []
        disputed_ports = []
        bpduguard_ports = []
        bpduguard_err_ports = []
        bpdufilter_ports = []
        ba_inconsistent_ports = []
        ports = {}

        mstp_session.bridge_name = key.encode('ascii', 'ignore')
        if 'rootPortName' in bridge:
            mstp_session.root_port_name = (
                bridge['rootPortName'].encode('ascii', 'ignore')
            )
        mstp_session.root_bridge = bridge['dsgnRoot'].encode('ascii',
                                                             'ignore').lower()
        mstp_session.topo_chg_ports = [
            bridge['topoChngPort'].encode('ascii', 'ignore'),
            bridge['lastTopoChngPort'].encode('ascii', 'ignore')
        ]
        mstp_session.topo_chg_cntr = bridge['topoChngCounter']
        mstp_session.bridge_id = bridge['bridgeId'].encode('ascii',
                                                           'ignore').lower()
        mstp_session.time_since_tcn = (
            now - long(bridge['timeSinceLastTopoChng'])
        )
        mstp_session.is_vlan_filtering = is_bridge_vlan_filtering(key)

        for port in json_out[key]:
            if port == key or port == 'bridgeIndex':
                continue

            # All the following sections assume that the key exists only if the
            # value is True. This is the current behavior of mstpctl.
            for portid in json_out[key][port]:
                portinfo = json_out[key][port][portid]
                if 'operEdgePort' in portinfo:
                    edge_ports.append(port)
                if 'networkPort' in portinfo:
                    network_ports.append(port)
                if 'baInconsistent' in portinfo:
                    ba_inconsistent_ports.append(port)
                if 'bpduGuardPort' in portinfo:
                    bpduguard_ports.append(port)
                if 'bpduGuardError' in portinfo:
                    bpduguard_err_ports.append(port)
                if 'disputed' in portinfo:
                    disputed_ports.append(port)
                if 'bpduFilterPort' in portinfo:
                    bpdufilter_ports.append(port)

                ports[port] = {}
                ports[port]['role'] = portinfo['role']
                ports[port]['state'] = portinfo['state']
                ports[port]['clagDualConnMac'] = (
                    portinfo['clagDualConnMac'].lower()
                )
                ports[port]['sendRstp'] = portinfo['allInformation']['sendRstp']
                ports[port]['clagIsl'] = 'clagIsl' in portinfo or False

        mstp_session.edge_ports = edge_ports
        mstp_session.network_ports = network_ports
        mstp_session.disputed_ports = disputed_ports
        mstp_session.bpduguard_ports = bpduguard_ports
        mstp_session.bpduguard_err_ports = bpduguard_err_ports
        mstp_session.bpdufilter_ports = bpdufilter_ports
        mstp_session.ba_inconsistent_ports = ba_inconsistent_ports
        mstp_session.ports = ports
        mstp_session.state = True

        mstp_session.save()

    return 0

def process_systemctl(cmd_out):
    lines = cmd_out.splitlines()
    lineno = 0
    total_lines = len(lines)
    mcls = Services.memmodel()
    while lineno < total_lines:
        # Assumed format is the following for each systemctl entry:
        # Names=ssh.service
        # ActiveState=active
        # UnitFileState=enabled
        # <blank line>
        if not lines[lineno]:
            break
        name = lines[lineno].split('=')[1].split('.')[0]
        is_active = lines[lineno + 1].split('=')[1].strip() == 'active'
        is_enabled = (
            lines[lineno + 2].split('=')[1].strip() == 'enabled'
        )
        if name == RunningService.QUAGGA:
            quagga_daemons = [Daemons.BGPD, Daemons.OSPFD,
                              Daemons.OSPF6D, Daemons.ZEBRA]
            for daemon in quagga_daemons:
                newsvc = Services()
                oldsvc = mcls.query.get(hostname=HOSTNAME, name=daemon)
                if is_active:
                    cmdstr = (
                        '/usr/bin/sudo vtysh -d %s -c quit' % daemon
                    )
                    try:
                        subprocess.check_output(cmdstr)
                    except Exception:  # pylint: disable=broad-except
                        pass
                if oldsvc:
                    newsvc.copy(oldsvc)
                else:
                    newsvc.name = daemon
                newsvc.is_active = 0
                newsvc.is_enabled = is_enabled
                newsvc.save()
        else:
            newsvc = Services()
            oldsvc = mcls.query.get(hostname=HOSTNAME, name=name)
            if oldsvc:
                newsvc.copy(oldsvc)
            else:
                newsvc.name = name
            newsvc.is_active = is_active
            newsvc.is_enabled = is_enabled
            newsvc.save()
        lineno += 4
    return 0

def process_platform_info(platform, os_release, decode_syseeprom, lscpu, # pylint: disable=unused-argument
                          meminfo, platform_json, meminfo_dmi, lsblk):
    os = OS()
    cpu = CPU()
    asic = ASIC()
    board = Board()

    os.name = 'N/A'
    os.version = 'N/A'
    os.version_id = 'N/A'
    cpu.arch = 'N/A'
    cpu.nos = 'N/A'
    cpu.model = 'N/A'
    cpu.max_freq = 'N/A'
    cpu.mem_total = 'N/A'
    asic.vendor = 'N/A'
    asic.model = 'N/A'
    asic.model_id = 'N/A'
    asic.core_bw = 'N/A'
    asic.ports = 'N/A'
    board.vendor = 'N/A'
    board.model = 'N/A'
    board.base_mac = 'N/A'
    board.part_number = 'N/A'
    board.mfg_date = 'N/A'
    board.serial_number = 'N/A'
    board.label_revision = 'N/A'

    if os_release is not None:
        for line in os_release.splitlines():
            if line.startswith('NAME='):
                os.name = line.split('=')[1].strip('\"')
            if line.startswith('VERSION='):
                os.version = line.split('=')[1].strip('\"')
            if line.startswith('VERSION_ID='):
                os.version_id = line.split('=')[1].strip('\"')

    if lscpu is not None:
        for line in lscpu.splitlines():
            if line.startswith('Architecture'):
                cpu.arch = line.split(':')[1].strip()
            if line.startswith('CPU(s)'):
                cpu.nos = line.split(':')[1].strip()
            if line.startswith('Model name'):
                cpu_info = line.split(':')[1].strip()
                model_freq = cpu_info.split('@')
                if len(model_freq) == 1:
                    cpu.model = model_freq[0].replace('  ', '').replace('CPU', '')
                elif len(model_freq) == 2:
                    cpu.model = model_freq[0].replace('  ', '').replace('CPU', '')
                    cpu.max_freq = model_freq[1]

    if platform_json:
        asic.vendor = platform_json['soc']['vendor'].encode('ascii', 'ignore')
        asic.model = platform_json['soc']['model'].encode('ascii', 'ignore')
        asic.model_id = platform_json['soc']['model_id'].encode('ascii', 'ignore')
        asic.core_bw = '%s%s' %(
            platform_json['soc']['core_bw'].encode('ascii', 'ignore'),
            platform_json['soc']['core_bw_unit'].encode('ascii', 'ignore'))
        asic.ports = platform_json['ports']['layout'].encode('ascii', 'ignore')
        board.model = platform_json['model_name'].encode('ascii', 'ignore')
        board.vendor = platform_json['vendor'].encode('ascii', 'ignore')

    if decode_syseeprom is not None:
        json_op = json.loads(decode_syseeprom)
        tlvs = json_op['tlv']
        if tlvs.has_key("Base MAC Address"):
            board.base_mac = tlvs["Base MAC Address"]["value"].encode(
                'ascii', 'ignore')
        if tlvs.has_key("Part Number"):
            board.part_number = tlvs["Part Number"]["value"].encode('ascii', 'ignore')
        if tlvs.has_key("Manufacture Date"):
            board.mfg_date = tlvs["Manufacture Date"]["value"][:10].encode(
                'ascii', 'ignore')
        if tlvs.has_key("Serial Number"):
            board.serial_number = tlvs["Serial Number"]["value"].encode(
                'ascii', 'ignore')
        if tlvs.has_key("Label Revision"):
            board.label_revision = tlvs["Label Revision"]["value"].encode(
                'ascii', 'ignore')

    if lsblk is not None:
        for line in lsblk.splitlines():
            disk = Disk()
            disk.name = 'N/A'
            disk.size = 'N/A'
            disk.d_type = 'N/A'
            disk.vendor = 'N/A'
            disk.transport = 'N/A'
            disk.rev = 'N/A'
            disk.model = 'N/A'
            d_str = line.split()
            if len(d_str) > 0:
                disk.name = d_str[0]
            if len(d_str) > 1:
                disk.size = d_str[1]
            if len(d_str) > 2:
                disk.d_type = d_str[2]
            if len(d_str) > 3:
                disk.vendor = d_str[3]
            if len(d_str) > 4:
                disk.transport = d_str[4]
            if len(d_str) > 5:
                disk.rev = d_str[5]
            if len(d_str) > 6:
                disk.model = d_str[6]
            if len(d_str) > 7:
                disk.model += ' ' + d_str[7]
            disk.save()

    mem_size = []
    mem_locator = []
    mem_b_locator = []
    mem_m_type = []
    mem_serial = []
    mem_mfg = []
    mem_speed = []
    if meminfo_dmi is not None:
        for line in meminfo_dmi.splitlines():
            line = line.strip()
            if line.startswith('Size:'):
                _, val = line.split(':')
                mem_size.append(val)
            elif line.startswith('Bank Locator:'):
                _, val = line.split(':')
                mem_b_locator.append(val)
            elif line.startswith('Locator:'):
                _, val = line.split(':')
                mem_locator.append(val)
            elif line.startswith('Speed:'):
                _, val = line.split(':')
                mem_speed.append(val)
            elif line.startswith('Type:'):
                _, val = line.split(':')
                mem_m_type.append(val)
            elif line.startswith('Serial Number:'):
                _, val = line.split(':')
                mem_serial.append(val)
            elif line.startswith('Manufacturer:'):
                _, val = line.split(':')
                mem_mfg.append(val)
    if (len(mem_size) == 0) and (meminfo is not None):
        for line in meminfo.splitlines():
            if line.startswith('MemTotal'):
                mem_str = float(line.split(':')[1].strip().split()[0])
                mem_size.append('%.2f' %(mem_str/1024) + 'MB')
                mem_locator.append('N/A')
                mem_b_locator.append('')
                mem_m_type.append('N/A')
                mem_mfg.append('N/A')
                mem_serial.append('N/A')
                mem_speed.append('N/A')
                break

    for i in range(0, len(mem_size)):
        if 'no' in mem_size[i].lower():
            continue
        mem = Memory()
        mem.size = mem_size[i]
        mem.name = mem_locator[i]
        if not 'no' in mem_b_locator[i].lower():
            mem.name += mem_b_locator[i]
        mem.m_type = mem_m_type[i]
        if len(mem_mfg) > i:
            mem.vendor = mem_mfg[i]
        if len(mem_serial) > i:
            mem.serial_number = mem_serial[i]
        if len(mem_speed) > i:
            mem.speed = mem_speed[i]
        mem.save()

    os.save()
    cpu.save()
    asic.save()
    board.save()
