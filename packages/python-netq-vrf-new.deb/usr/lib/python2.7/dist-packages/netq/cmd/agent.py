# vim: tabstop=4 shiftwidth=4 softtabstop=4
# Copyright 2016 Cumulus Networks, Inc. All rights reserved.
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc.
# 51 Franklin Street, Fifth Floor
# Boston, MA  02110-1301, USA.
"""
netq-agent - Daemon that implements pushes interesting data to a distributed KV store

Usage:
   netq-agent [--server <ip-server>|--server <text-server>] [--config <text-configfile>] [--uds <text-udsfile>] [--debug]
   netq-agent [--server <ip-server>|--server <text-server>] --daemon [--config <text-configfile>] [--pidfile <text-pidfile>] [--uds <text-udsfile>] [--debug]

Options:
   --config           : Provide path to the config file
   --daemon           : Run as a daemon program
   --debug            : Set log level to debug
   --pidfile          : Provide path to the PID file
   --server           : Specify IP address of DB server
   --uds              : Provide path to the Unix domain socket
   <ip-server>        : IP address of DB server
   <text-configfile>  : File name for the config file. Default is /etc/netq/netq-agent.conf
   <text-pidfile>     : File name for the PID file. Default is /var/run/netq-agent.pid
   <text-udsfile>     : File name for the Unix domain socket. Default: /var/run/netq-agent.sock

Help:
   -h --help         : Show this screen
"""
from __future__ import absolute_import

import bisect
import hashlib
import json
import os
import socket
import subprocess
import sys
import time
import uuid

import eventlet
import eventlet.pools
import greenlet
from network_docopt import NetworkDocopt, get_network_docopt_info

from netq.common import config
from netq.common import netlink, utils
from netq.common.enums import (
    Daemons,
    DefaultPaths,
    NetDevFmt,
    Heartbeat,
    InterfaceState,
    NeighborState,
    LinkType,
    Platform,
    RunningService
)
from netq.common.service import Service
from netq.common.utils import NetlinkCopy
from netq.lib import parsers
from netq.orm import HOSTNAME
from netq.orm.redisdb import (
    curr_pipeline,
    new_pipeline,
    reset_connection_settings,
    scripts,
    set_connection_settings,
    RedisException
)
from netq.orm.redisdb.models import (
    Address,
    BgpSession,
    ClagSession,
    Command,
    Counter,
    CounterHistory,
    Link,
    MacFdb,
    MstpInfo,
    Neighbor,
    Node,
    Route,
    Services)

_PROC_NAME = 'netq-agent'


class _Command(object):
    """Command class.
    """
    # pylint: disable=too-few-public-methods
    def __init__(self, period, key, command, service, callback=None):
        self.period = period
        self.key = key
        self.command = command
        self.service = service
        # function to parse & push out structured data
        self.callback = callback

    def __cmp__(self, other):
        return cmp(self.period, other.period)

    def __eq__(self, other):
        return self.key == other.key and self.command == other.command

    def __ne__(self, other):
        return not self == other

    def __repr__(self):
        return '%s(period=%d, key=%s, command=%s)' % (
            self.__class__.__name__, self.period, self.key, self.command
        )


class _Thread(object):
    """Thread class.
    """
    def __init__(self):
        self.__function = None
        self.__pool = None
        self.__start_time = None
        self.__stop_checker = None
        self.green_thread = None
        self.pipeline = None

    def kill(self):
        eventlet.kill(self.green_thread)

    def link(self, stop_checker):
        self.__stop_checker = stop_checker
        self.green_thread.link(stop_checker)

    @classmethod
    def spawn(cls, epoch, pool, function, pipeline=None):
        thread = cls()
        thread.__function = function # pylint: disable=protected-access
        thread.__pool = pool # pylint: disable=protected-access
        thread.__start_time = epoch # pylint: disable=protected-access
        thread.pipeline = pipeline
        if pipeline is not None:
            thread.green_thread = pool.spawn(function, pipeline)
        else:
            thread.green_thread = pool.spawn(function)
        return thread

    def stale(self, now):
        return now - self.__start_time >= Heartbeat.HEARTBEAT_DEATH

    def respawn(self, epoch):
        self.kill()
        thread = self.spawn(epoch, self.__pool, self.__function,
                            pipeline=self.pipeline)
        return thread


class _ClDbPush(Service):
    """
    This class defines the main workhorse class of this file.
    It parses the args, fires off the command event monitoring
    threads, and processes the outputs posted by these threads
    and adds them to a redis database.
    """
    __BRIDGE_FBD_REGEX = (
        r'(?:(?P<deleted>^Deleted)\s+)?'
        r'(?P<mac_address>\S+)'
        r'\s+\S+\s+(?P<nexthop>\S+)'
        r'(?=.*vlan\s+(?P<vlan_id>\d+))?'
        r'(?=.*\s+(?P<origin>permanent$))?'
        r'(?=.*dst\s+(?P<dst>\S+))?'
        r'(?=.*master\s+(?P<port>\S+))?'
    )

    __COUNTERS_RATE = 10

    __CMD_TIMEOUT = 5

    __GC_RATE = 5 * 60

    __INT_CMDS = {
        'bgpd': [
            {
                "period": "15",
                "key": "bgp-neighbors",
                "command": "vtysh -c 'show ip bgp vrf all neighbors json'",
                "callback": parsers.process_bgp_neighbors
            },
        ],
        'ospfd': [
            {
                "period": "15",
                "key": "ospf-neighbor-json",
                "command": "vtysh -c 'show ip ospf neighbor json'",
                "callback": parsers.process_ospf_neighbors
            }
        ],
        'clagd': [
            {
                "period": "15",
                "key": "clagctl-json",
                "command": "clagctl -j",
                "callback": parsers.process_clagctl
            }
        ],
        'mstpd': [
            {
                "period": "15",
                "key": "mstpctl-bridge-json",
                "command": "mstpctl showall json",
                "callback": parsers.process_mstpall
            }
        ],
        "lldpd": [
            {
                "period": "30",
                "key": "lldp-neighbor-json",
                "command": "lldpctl -f json",
                "callback": None
            }
        ]
    }

    __MAX_REDIS_CONNECTIONS = 10

    __PIPELINE_RATE = 2

    __REDISTRIBUTE_NBR_TABLE_ID = 10

    def __init__(self, conf):
        super(_ClDbPush, self).__init__(conf, _PROC_NAME)
        self.__commands = []
        self.__command_buffer = {}
        self.__gc_keys = None
        self.__gc_ready = True
        self.__heartbeat_gt = None
        self.__hostname = HOSTNAME
        self.__ifname_by_index = None
        self.__lastboot = time.time()
        self.__netlink_gt = None
        self.__vxlan_vlan_map = {}
        self.__link_kind_map = {}
        self.__nlmonitor = netlink.Netlink(
            self._conf,
            self._logger,
            {netlink.Netlink.NEWADDR: self.__rx_rtm_newaddr,
             netlink.Netlink.DELADDR: self.__rx_rtm_deladdr,
             netlink.Netlink.NEWLINK: self.__rx_rtm_newlink,
             netlink.Netlink.DELLINK: self.__rx_rtm_dellink,
             netlink.Netlink.NEWNEIGH: self.__rx_rtm_newneigh,
             netlink.Netlink.DELNEIGH: self.__rx_rtm_delneigh,
             netlink.Netlink.NEWROUTE: self.__rx_rtm_newroute,
             netlink.Netlink.DELROUTE: self.__rx_rtm_delroute},
            pool=self._pool
        )
        self.__prev_cmd = {}
        self.__prev_cntr = {}
        self.__redispool = eventlet.pools.TokenPool(
            max_size=self.__MAX_REDIS_CONNECTIONS
        )
        self.__redisthreads = set()
        self.__reinitpool = eventlet.pools.TokenPool(max_size=1)
        self.__timers = {}
        self.__platform = self.__get_platform()

    def __run_safe_cmd(self, command):
        """Run time-limited command and return status & cmd output
        return code is 0 for successful commands and non-zero otherwise
        """
        cmd_out = retcode = None
        cmd = subprocess.Popen(command,
                               stdout=subprocess.PIPE,
                               stderr=subprocess.STDOUT,
                               shell=True)
        identifier = uuid.uuid4().hex
        green_thread = self._pool.spawn(cmd.communicate)
        green_thread.link(self.__stop_command_checker, identifier, command)
        endtime = time.time() + self.__CMD_TIMEOUT

        while True:
            if identifier in self.__command_buffer:
                cmd_out = self.__command_buffer.pop(identifier)
                if cmd_out is None:
                    retcode = -1
                else:
                    retcode = cmd.returncode
                break
            if time.time() > endtime:
                self._logger.error('Failed to execute command %s after %d '
                                   'seconds', command, self.__CMD_TIMEOUT)
                eventlet.kill(green_thread, greenlet.GreenletExit)
                retcode = -1
                break
            eventlet.sleep(1)
        if retcode != 0:
            self._logger.debug('Command %s returned %d', command, retcode)
        return retcode, cmd_out

    def __gc_collect(self):
        if self.__gc_ready:
            # Make sure that the gc_ready flag is set to False before calling
            # this method
            return
        scorestr = "{:.2f}".format(time.time())
        score = float(scorestr)
        args = [score]
        if self.__gc_keys is None:
            self.__gc_keys = set()
            cmd = Command()
            for command in self.__commands:
                cmd.key = command.key
                self.__gc_keys.add(Command.obj_to_key(cmd.__dict__))
            counter = CounterHistory()
            for key in CounterHistory.KEYS:
                self.__gc_keys.add(
                    CounterHistory.obj_to_key(counter.__dict__,
                                              key_type=key)
                )
        dynamic_keys = set()
        for cls in [MstpInfo, ClagSession, BgpSession]:
            mcls = cls.memmodel()
            for ele in mcls.query.filter(hostname=HOSTNAME):
                dynamic_keys.add(cls.obj_to_key(ele.__dict__))
        if self.__gc_keys:
            try:
                freed = scripts.gc_script(list(self.__gc_keys) +
                                          list(dynamic_keys),
                                          args)
                if freed > 0:
                    self._logger.info('gc_collect freed %s entries', freed)
            except RedisException as ex:
                self._logger.warn('gc_collect failed. Error: %s', ex)
        self.__gc_ready = True

    @staticmethod
    def __is_service_enabled(daemon):
        """Check if service is enabled. Works across systemctl & service
        models.
        """
        quagga_daemons = [Daemons.BGPD, Daemons.OSPFD, Daemons.OSPF6D,
                          Daemons.ZEBRA]

        if daemon in quagga_daemons:
            cmdstr = '/usr/bin/sudo vtysh -d %s -c quit' % daemon
        elif os.path.isfile('/bin/systemctl'):
            cmdstr = '/bin/systemctl is-enabled %s' % daemon
        else:
            cmdstr = '/usr/sbin/service %s status' % daemon

        try:
            _ = subprocess.check_output(cmdstr.split(),
                                        stderr=subprocess.STDOUT).strip()
            return True
        except subprocess.CalledProcessError:
            return False

    @staticmethod
    def __has_service_failed(daemon):
        """Check if service has failed. Works only with systemctl for now
        """
        quagga_daemons = [Daemons.BGPD, Daemons.OSPFD, Daemons.OSPF6D,
                          Daemons.ZEBRA]

        cmdstr = '/bin/systemctl is-failed %s' % daemon
        try:
            out = subprocess.check_output(cmdstr.split(),
                                          stderr=subprocess.STDOUT).strip()
            return True
        except subprocess.CalledProcessError as ex:
            # OK, failure means the service hasn't failed. Lets check the
            # individual daemon if its a quagga daemon
            out = ex.output
            if 'active' in out:
                if daemon in quagga_daemons:
                    cmdstr = '/usr/bin/sudo vtysh -d %s -c quit' % daemon
                    try:
                        _ = subprocess.check_output(cmdstr.split(),
                                                    stderr=subprocess.STDOUT)
                    except subprocess.CalledProcessError:
                        return True
            return False

    def __get_port_vlan_info(self, ifname):
        """Need to vlan info from bridge since I don't know
        how to parse netlink for this.
        """
        access_vlan = 0
        vlans = ''
        command = '/sbin/bridge -c -j vlan show dev %s' % ifname
        retcode, cmd_out = self.__run_safe_cmd(command)
        entry = {}
        if retcode == 0:
            try:
                entry = json.loads(cmd_out)
            except KeyError:
                return access_vlan, vlans
        if ifname not in entry:
            return access_vlan, vlans
        for vlanblk in entry[ifname]:
            svlan = vlanblk.get('vlan')
            flags = vlanblk.get('flags')
            if flags and 'PVID' in flags:
                access_vlan = int(svlan)
                vlans += ' %s' % svlan
            else:
                evlan = vlanblk.get('vlanEnd')
                if evlan:
                    vlans += ' %s-%s' % (svlan, evlan)
                else:
                    vlans += ' %s' % svlan
        return access_vlan, vlans

    def __load_commands(self):
        """Determine what info to push based on box configuration.
        """
        if os.path.isfile(self._conf.dbconfig):
            with open(self._conf.dbconfig, 'r') as dbfiled:
                base_config_json = json.load(dbfiled)
                base_config_json.update(self.__INT_CMDS)
                for service, commands in base_config_json.iteritems():
                    if (service == Daemons.MISC or
                            self.__is_service_enabled(service)):
                        for command in commands:
                            if all(k in command
                                   for k in ('period', 'key', 'command')):
                                # last param is None because there is no
                                # command to parse out the info and push it out
                                cmd = _Command(int(command['period']),
                                               str(command['key'].strip()),
                                               str(command['command'].strip()),
                                               str(service),
                                               callback=command.get('callback',
                                                                    None))
                                idx = bisect.bisect_left(self.__commands, cmd)
                                if (idx >= len(self.__commands) or
                                        self.__commands[idx] != cmd):
                                    bisect.insort(self.__commands, cmd)
                            else:
                                self._logger.info('Ignoring invalid line %r',
                                                  command)

        # The purpose of the DBCONFIG_RUNNING file is to share state between
        # netq-agent and netq.
        with open(DefaultPaths.DBCONFIG_RUNNING, 'w') as dbfiled:
            json.dump({'server': self._conf.server,
                       'commands': self.__commands},
                      dbfiled,
                      cls=utils.ClassEncoder)

        epoch = int(time.time())
        for cmd in self.__commands:
            self.__timers.setdefault(epoch + cmd.period, set())
            self.__timers[epoch + cmd.period].add(cmd)

    def __get_platform(self):
        """Get the platform name of this device. 'server' if its not Cumulus.
        """
        retcode, cmd_out = self.__run_safe_cmd('/usr/bin/platform-detect')
        platform = Platform.UNKNOWN
        if retcode == 0:
            platform = cmd_out.splitlines()[-1].strip()
            if platform == 'UNKNOWN':
                platform = Platform.VX
            platform = '%s,%s' % (Platform.CUMULUS, platform)
        elif os.path.exists('/etc/os-release'):
            with open('/etc/os-release', 'r') as fd:
                platform = '%s,%s' % (Platform.LINUX,
                                      fd.readline().strip().split('=')[1])
        return platform

    def __pipe_execute(self, pipeline):
        with self.__redispool.item() as _:
            self._logger.debug('Executing pipeline %s of length %d',
                               id(pipeline), len(pipeline.command_stack))
            pipeline.execute()

    def __process_command(self, info):
        """This updates a key based on new data from executing the command
        :param info: Command object
        :type info: _Command
        """
        # Execute the command:
        retcode, cmd_out = self.__run_safe_cmd(info.command)
        svc = None
        svc_failed = False

        # Update monitoring status
        if info.service != Daemons.MISC:
            if retcode != 0:
                svc_failed = self.__has_service_failed(info.service)

            svcs = Services.memmodel()
            svc = svcs.query.get(hostname=HOSTNAME, name=info.service)
            if svc:
                svc.is_monitored = (retcode == 0)
                svc.is_failed = svc_failed
                newsvc = Services()
                newsvc.copy(svc)
                newsvc.save()

        if not cmd_out:
            # I'm assuming that the parsers can all catch non-JSON input and
            # parse out an error
            cmd_out = ' '

        # Don't push the data out unless it has changed
        if cmd_out:
            if info.callback is not None:
                try:
                    retcode = info.callback(cmd_out, svc_failed)
                except Exception:  # pylint: disable=broad-except
                    self._logger.exception('Failed to execute command %s ',
                                           info.command)
                    retcode = -1
                if svc and retcode:
                    svc.is_monitored = False
                    svc.is_failed = svc_failed
                    newsvc = Services()
                    newsvc.copy(svc)
                    newsvc.save()
            else:
                newcmd = Command()
                cmdhash = hashlib.md5(cmd_out).digest()
                prev_cmd = self.__prev_cmd.get(info.key, None)
                if prev_cmd is None or prev_cmd[0] != cmdhash:
                    self.__prev_cmd[info.key] = (cmdhash, len(cmd_out))
                    newcmd.key = info.key
                    newcmd.output = cmd_out
                    newcmd.save()
        epoch = int(time.time())
        self.__timers.setdefault(epoch + info.period, set())
        self.__timers[epoch + info.period].add(info)

    def __process_counters(self):
        """Update Top talkers and such
        Push out counters per port so they can be sorted by redis.
        """
        with open('/proc/net/dev', 'r') as devfd:
            output = devfd.readlines()

        now = int(time.time())
        for line in output[2:]:
            if not line.strip():
                continue
            words = line.split()

            # If we don't have any prior info, just save it and don't push
            # any info
            ifname = words[NetDevFmt.IFACE].split(':')[0]
            if ifname not in self.__prev_cntr:
                self.__prev_cntr[ifname] = [line, now]
                return

            prev_words = self.__prev_cntr[ifname][0].split()
            prev_time = self.__prev_cntr[ifname][1]

            counter = Counter()
            counter.ifname = ifname
            counter.tx_bps = long(((long(words[NetDevFmt.TX_BYTES]) -
                                    long(prev_words[NetDevFmt.TX_BYTES])) /
                                   (now - prev_time)))
            counter.rx_bps = long(((long(words[NetDevFmt.RX_BYTES]) -
                                    long(prev_words[NetDevFmt.RX_BYTES])) /
                                   (now - prev_time)))
            counter.tx_drop_bps = long(((long(words[NetDevFmt.TX_DRP]) -
                                         long(prev_words[NetDevFmt.TX_DRP])) /
                                        (now - prev_time)))
            counter.rx_drop_bps = long(((long(words[NetDevFmt.RX_DRP]) -
                                         long(prev_words[NetDevFmt.RX_DRP])) /
                                        (now - prev_time)))
            counter.tx_err_bps = long(((long(words[NetDevFmt.TX_ERR]) -
                                        long(prev_words[NetDevFmt.TX_ERR])) /
                                       (now - prev_time)))
            counter.rx_err_bps = long(((long(words[NetDevFmt.RX_ERR]) -
                                        long(prev_words[NetDevFmt.RX_ERR])) /
                                       (now - prev_time)))
            self.__prev_cntr[ifname] = [line, now]
            counter.save()
            CounterHistory().save()

    def __check_services(self):
        """Update active/enabled/monitoring services status"""

        if self.__platform == Platform.UNKNOWN:
            return
        base_cumulus_services = []
        hardnode_services = []
        if Platform.CUMULUS in self.__platform:
            base_cumulus_services = [
                RunningService.ARP_REFRESH,
                RunningService.CLAGD,
                RunningService.LLDPD,
                RunningService.MSTPD,
                RunningService.PTMD,
                RunningService.QUAGGA,
                RunningService.VXRD,
                RunningService.VXSND
            ]
            if Platform.VX not in self.__platform:
                hardnode_services = [
                    RunningService.ACLINIT,
                    RunningService.ACLTOOL,
                    RunningService.LEDMGRD,
                    RunningService.POED,
                    RunningService.PORTWD,
                    RunningService.PWMD,
                    RunningService.SMOND,
                    RunningService.SWITCHD,
                    RunningService.WATCHDOG
                ]
            base_linux_services = [
                RunningService.NTP,
                RunningService.SSH,
                RunningService.RSYSLOG
            ]
        else:  # Platform.LINUX
            base_linux_services = [
                RunningService.NTP,
                RunningService.SSH,
                RunningService.RSYSLOG,
                RunningService.DOCKER
            ]
        all_svcs = ' '.join(base_cumulus_services +
                            base_linux_services +
                            hardnode_services)
        if not os.path.exists('/bin/systemctl'):
            self._logger.error('Non systemctl systems not supported')
            return
        cmd = '%s show -p Names,ActiveState,UnitFileState %s' % (
            '/bin/systemctl', all_svcs)
        retcode, cmd_out = self.__run_safe_cmd(cmd)
        if retcode == 0 and cmd_out:
            try:
                parsers.process_systemctl(cmd_out)
            except Exception:  # pylint: disable=broad-except
                self._logger.exception('Failed to process systemctl output. ')

    def __reinitialize_db(self):
        """ Reinitializing the database. This is called
        a. on startup
        b. when pipeline execute fails
        c. the bridge monitor or netlink monitor greenthread crash
        """
        with self.__reinitpool.item() as _:
            self._logger.info('Reinitializing the database')

            if self.__netlink_gt is not None:
                self._logger.info('Terminating netlink monitor greenthread')
                eventlet.kill(self.__netlink_gt, eventlet.StopServe)
                self.__netlink_gt = None

            # Flush the netlink cache
            self.__nlmonitor.reset()

            # Flush the pipeline
            self._logger.info('Flushing the pipeline')
            for entry in list(self.__redisthreads):
                entry.kill()
            self.__redisthreads = set()
            new_pipeline()

            # Delete all the netlink keys
            self._logger.info('Deleting netlink keys')
            timeout = 1
            while True:
                try:
                    Address.query.delete(hostname=HOSTNAME, purge=False)
                    Link.query.delete(hostname=HOSTNAME, purge=False)
                    Neighbor.query.delete(hostname=HOSTNAME, purge=False)
                    MacFdb.query.delete(hostname=HOSTNAME, purge=False)
                    Route.query.delete(hostname=HOSTNAME, purge=False)
                    BgpSession.query.delete(hostname=HOSTNAME, purge=False)
                    ClagSession.query.delete(hostname=HOSTNAME, purge=False)
                    MstpInfo.query.delete(hostname=HOSTNAME, purge=False)
                    break
                except RedisException:
                    reset_connection_settings()
                    timeout *= 2
                    self._logger.exception('Delete failed, retrying after %d '
                                           'seconds', timeout)
                    eventlet.sleep(timeout)

            if self.__netlink_gt is None:
                # Rebind netlink socket
                self._logger.info('Binding netlink socket')
                while True:
                    try:
                        self.__nlmonitor.bind()
                        break
                    except RuntimeError:
                        timeout = 10
                        self._logger.warn(
                            'Binding netlink socket after %d seconds', timeout
                        )
                        eventlet.sleep(timeout)
                self._logger.info('(Re)starting netlink monitor greenthread')
                self.__netlink_gt = (
                    self._pool.spawn(self._serve,
                                     self.__nlmonitor.socket,
                                     self.__nlmonitor.handle_netlink_msg,
                                     bufsize=netlink.Netlink.NLSOCK_BYTES)
                )
                self.__netlink_gt.link(self.__stop_monitor_checker)
                # Start the netlink dispatcher
                dispatcher_gt = self.__nlmonitor.run()
                dispatcher_gt.link(self._stop_checker)

            # Repopulating the db
            self.__ifname_by_index = {}
            self.__vxlan_vlan_map = {}
            self._pool.spawn(self.__nlmonitor.get_all_links).wait()
            self._pool.spawn_n(self.__nlmonitor.get_all_addresses)
            self._pool.spawn_n(self.__nlmonitor.get_all_neighbors)
            self._pool.spawn_n(self.__nlmonitor.get_all_routes)
            self._pool.spawn_n(self.__nlmonitor.get_all_macs)
            self.__platform = self.__get_platform()

    def __rx_rtm_newaddr(self, info):
        """Adds a new address to the DB.
        :param info: address object
        :type info: netlink.Address
        """
        self._logger.info('RX RTM_NEWADDR for ip_address %s, ifindex %s',
                          '/'.join((info.prefix, str(info.mask))),
                          info.ifindex)
        addr = Address()
        NetlinkCopy.copy_address(addr, info, self.__ifname_by_index)
        self._logger.debug('Adding new address %r to DB', addr)
        addr.save()
        return info.ifindex

    def __rx_rtm_deladdr(self, info):
        """Deletes an address from the DB.
        :param info: address object
        :type info: netlink.Address
        """
        self._logger.info('RX RTM_DELADDR for ip_address %s, ifindex %s',
                          '/'.join((info.prefix, str(info.mask))),
                          info.ifindex)
        addr = Address()
        NetlinkCopy.copy_address(addr, info, self.__ifname_by_index)
        self._logger.debug('Deleting address %r from DB', addr)
        addr.delete()
        return info.ifindex

    def __rx_rtm_newlink(self, info):
        """Adds a new link to the DB.
        :param info: link object
        :type info: netlink.Link
        """
        self._logger.info('RX RTM_NEWLINK for ifname %s, admin_state %s, '
                          'oper_state %s', info.ifname, info.admin_state,
                          info.oper_state)

        pvid = 0
        link = Link()
        self.__ifname_by_index[info.ifindex] = info.ifname

        if info.family == socket.AF_BRIDGE:
            m_link = Link.memmodel()
            entry = m_link.query.get(hostname=HOSTNAME,
                                     ifname=info.ifname)
            if entry:
                link.copy(entry)
            else:
                # Being bold here. Discard any updates we get before we
                # determine link type. Assuming we can get it all back.
                self._logger.info('Ignored AF_BRIDGE link upd8 for %s, no '
                                  'cache', info.ifname)
                return info.ifindex
        else:
            NetlinkCopy.copy_link(link, info)

        # Some of the fields have to be always copied over
        NetlinkCopy.copy_link_always(link, info)

        if link.kind == '':
            if info.ifname == 'lo':
                link.kind = LinkType.LOOPBACK
            elif info.ifname.startswith('eth'):
                link.kind = LinkType.ETH
            else:
                link.kind = LinkType.SWP

        link.managed = True
        if info.oper_state == InterfaceState.UP:
            pvid, vlans = self.__get_port_vlan_info(info.ifname)
            link.access_vlan = pvid
            if link.kind != LinkType.VXLAN:
                link.vlans = vlans

        if info.parent_if:
            link.parent_if = self.__ifname_by_index.get(info.parent_if,
                                                        str(info.parent_if))
        else:
            link.parent_if = info.ifname

        if info.kind == LinkType.VLAN:
            link.access_vlan = info.vni   

        if info.master_ifindex:
            link.master = self.__ifname_by_index.get(info.master_ifindex,
                                                     str(info.master_ifindex))
        else:
            link.master = info.ifname

        if info.kind == LinkType.VXLAN:
            # We use this cached value to handle MacFdb updates
            self.__vxlan_vlan_map[info.ifname] = {'vlan': pvid,
                                                  'vni': info.vni}
            if info.ifname not in self.__link_kind_map:
                self.__link_kind_map[info.ifname] = {}
            self.__link_kind_map[info.ifname]['vni'] = info.vni

        self._logger.debug('Adding new link %r to DB', link)
        link.save()
        return info.ifindex

    def __rx_rtm_dellink(self, info):
        """Deletes a link from the DB.
        :param info: link object
        :type info: netlink.Link
        """
        self._logger.info('RX RTM_DELLINK for ifname %s, admin_state %s, '
                          'oper_state %s', info.ifname, info.admin_state,
                          info.oper_state)
        link = Link()
        NetlinkCopy.copy_link(link, info)
        self._logger.debug('Deleting link %r from DB', link)
        link.delete()
        return info.ifindex

    def __rx_rtm_newneigh(self, info):
        """Adds a new neighbor to the DB.
        Neighbors in the kernel go through a lot of state transitions that
        we are currently not interested in tracking.  Only update redis if a
        neighbor is new...ie ignore all of the RTM_NEWNEIGH messages
        generated from the state transitions
        :param info: neighbor object
        :type info: netlink.Neighbor
        """
        self._logger.info('RX RTM_NEWNEIGH for ip_address %s, ifindex %s',
                          info.ip_address, info.ifindex)
        if info.family == socket.AF_BRIDGE:
            neighbor = MacFdb()
            self.__nlmonitor.stats.increment(netlink.NetlinkStat.RTM_NEWFDB,
                                             1)
            NetlinkCopy.copy_macfdb(neighbor, info, self.__ifname_by_index)
            if neighbor.dst:
                vinfo = self.__vxlan_vlan_map.get(neighbor.nexthop)
                if vinfo:
                    neighbor.vlan = int(vinfo['vlan'])
                else:
                    neighbor.vlan = -1
            else:
                if self.__link_kind_map.get(neighbor.nexthop, None):
                    # This is the second update to the same remote MAC
                    # but this time from the bridge, without the remote vtep
                    # address. Ignore it.
                    self._logger.debug('Ign new neighbor %r to DB', neighbor)
                    return info.ifindex
        else:
            neighbor = Neighbor() # pylint: disable=redefined-variable-type
            NetlinkCopy.copy_neighbor(neighbor, info, self.__ifname_by_index)
        if info.state == NeighborState.UPDATE:
            self._logger.debug('Adding new neighbor %r to DB', neighbor)
            neighbor.save()
        elif info.state == NeighborState.DELETE:
            self._logger.debug('Deleting neighbor %r from DB', neighbor)
            neighbor.delete()
        return info.ifindex

    def __rx_rtm_delneigh(self, info):
        """Deletes a neighbor from the DB.
        :param info: neighbor object
        :type info: netlink.Neighbor
        """
        self._logger.info('RX RTM_DELNEIGH for ip_address %s, ifindex %s',
                          info.ip_address, info.ifindex)
        if info.family == socket.AF_BRIDGE:
            neighbor = MacFdb()
            self.__nlmonitor.stats.increment(netlink.NetlinkStat.RTM_DELFDB,
                                             1)
            NetlinkCopy.copy_macfdb(neighbor, info, self.__ifname_by_index)
        else:
            neighbor = Neighbor() # pylint: disable=redefined-variable-type
            NetlinkCopy.copy_neighbor(neighbor, info, self.__ifname_by_index)
        self._logger.debug('Deleting neighbor %r from DB', neighbor)
        neighbor.delete()
        return info.ifindex

    def __rx_rtm_newroute(self, info):
        """Adds a new route to the DB.
        :param info: route object
        :type info: netlink.Route
        """
        # Skip redistribute neighbor routes in table 10
        if (info.table == self.__REDISTRIBUTE_NBR_TABLE_ID or
                (info.is_ipv6 and info.ip_address.startswith('ff02'))):
            return info.ifindex

        self._logger.info('RX RTM_NEWROUTE for ip_address %s, nexthops %s',
                          info.ip_address, info.nexthops)
        route = Route()
        NetlinkCopy.copy_route(route, info, self.__ifname_by_index)
        self._logger.debug('Adding new route %r to DB', route)
        route.save()
        return info.ifindex

    def __rx_rtm_delroute(self, info):
        """Delete a route from the DB.
        :param info: route object
        :type info: netlink.Route
        """
        self._logger.info('RX RTM_DELROUTE for ip_address %s, nexthops %s',
                          info.ip_address, info.nexthops)
        route = Route()
        NetlinkCopy.copy_route(route, info, self.__ifname_by_index)
        self._logger.debug('Deleting route %r from DB', route)
        route.delete()
        return info.ifindex

    def __stop_command_checker(self, green_thread, identifier, command):
        try:
            self.__command_buffer[identifier], _ = green_thread.wait()
        except greenlet.GreenletExit:
            pass
        except Exception:  # pylint: disable=broad-except
            self._logger.exception('Failed to execute command %s', command)
            self.__command_buffer[identifier] = None

    def __stop_monitor_checker(self, green_thread):
        try:
            green_thread.wait()
        except greenlet.GreenletExit:  # pylint: disable=no-member
            pass
        except Exception:  # pylint: disable=broad-except
            self._logger.exception('Monitor thread terminated unexpectedly')
            if self.__netlink_gt == green_thread:
                self.__netlink_gt = None
            green_thread = self._pool.spawn(self.__reinitialize_db)
            green_thread.link(self._stop_checker)

    def __stop_thread_checker(self, green_thread):
        """ Propagates exceptions to the run green thread.
        """
        entry = next((thread for thread in self.__redisthreads
                      if thread.green_thread == green_thread), None)
        if entry is not None:
            self.__redisthreads.remove(entry)
            if entry == self.__heartbeat_gt:
                self.__heartbeat_gt = None
        try:
            green_thread.wait()
        except greenlet.GreenletExit:  # pylint: disable=no-member
            pass
        except RedisException:
            if entry is not None:
                if entry.pipeline is not None:
                    self._logger.exception('Failed to execute PIPELINE %s',
                                           id(entry.pipeline))
                    green_thread = self._pool.spawn(self.__reinitialize_db)
                    green_thread.link(self._stop_checker)
                else:
                    self._logger.exception('Failed to send heartbeat')
        except Exception:  # pylint: disable=broad-except
            eventlet.kill(self._run_gt, *sys.exc_info())
        else:
            if entry is not None:
                if entry.pipeline is not None:
                    self._logger.debug('Successfully executed PIPELINE %s',
                                       id(entry.pipeline))
                else:
                    self._logger.debug('Successfully sent heartbeat')

    def __update_nodename(self):
        node = Node()
        node.lastboot = self.__lastboot
        with self.__redispool.item() as _:
            self._logger.info('Sending heartbeat to server')
            node.save(commit=True)

    def _process(self, msg):
        """ Process requests from a mgmt. client.
        :returns: result object and Exception. Latter would be None if
                  everything is good
        """
        # pylint: disable=too-many-branches,too-many-return-statements
        try:
            if msg.get('stats'):
                return repr(self.__nlmonitor.stats), None
            else:
                return None, RuntimeError('Unknown request')
        except Exception:  # pylint: disable=broad-except
            return None, RuntimeError('Bad message')

    def __run_onetime(self):
        # platform-detect
        platform = self.__platform.split(',', 1)[1]

        # OS Release
        retcode, os_release = self.__run_safe_cmd('cat /etc/os-release')
        if retcode != 0:
            os_release = None
        # Board Info
        retcode, decode_syseeprom = self.__run_safe_cmd('/usr/cumulus/bin/decode-syseeprom -j')
        if retcode != 0:
            decode_syseeprom = None
        # lscpu
        retcode, lscpu = self.__run_safe_cmd('/usr/bin/lscpu')
        if retcode != 0:
            lscpu = None
        # lscpu
        retcode, meminfo = self.__run_safe_cmd('cat /proc/meminfo')
        if retcode != 0:
            lscpu = None

        #lsblk
        retcode, lsblk = self.__run_safe_cmd(
            'lsblk -d -n -o name,size,type,vendor,tran,rev,model')
        if retcode != 0:
            lsblk = None

        # dmidecode memory
        retcode, meminfo_dmi = self.__run_safe_cmd('dmidecode -t 17')
        if retcode != 0:
            meminfo_dmi = None

        platform_json = None
        if Platform.CUMULUS in self.__platform:
            paths = ['/usr/share/cumulus-platform/common/platform-info',
                     '/usr/share/cumulus/platform-info']
            for path in paths:
                if platform_json:
                    break
                for _, _, files in os.walk(path):
                    for filen in files:
                        try:
                            fp = open(os.path.join(path, filen))
                            plat = json.load(fp)
                            fp.close()
                        except Exception: # pylint: disable=broad-except
                            pass
                        else:
                            if plat.has_key(platform):
                                platform_json = plat[platform][0]

        parsers.process_platform_info(platform, os_release, decode_syseeprom,
                                      lscpu, meminfo, platform_json,
                                      meminfo_dmi, lsblk)

    def _run(self):
        """Once upon a time...
        """
        set_connection_settings(self._conf.server, agent=True)
        self._logger.info('%s started, Redis server %s', _PROC_NAME,
                          self._conf.server)

        # Purge and reinit entries
        self.__reinitialize_db()
        # Assemble the data to be pushed
        self.__load_commands()
        self.__run_onetime()

        timers = {'pipeline': 0, 'counters': 0, 'gc': 0, 'liveliness': 0,
                  'inactivity': 0}
        while True:
            epoch = long(time.time())
            new_timers, self.__timers = self.__timers.copy(), {}
            for key in new_timers:
                if epoch > key:
                    for cmd in new_timers[key]:
                        green_thread = self._pool.spawn(self.__process_command,
                                                        cmd)
                        green_thread.link(self._stop_checker)
                else:
                    self.__timers[key] = new_timers[key]
            if epoch - timers['inactivity'] >= Heartbeat.HEARTBEAT_DEATH:
                for thread in list(self.__redisthreads):
                    if thread.stale(epoch):
                        if thread == self.__heartbeat_gt:
                            self._logger.warn('Killing heartbeat thread')
                            self.__heartbeat_gt.kill()
                        else:
                            self._logger.warn('Inactivity timeout exceeded '
                                              'for pipeline %s. Respawning...',
                                              id(thread.pipeline))
                            new_thread = thread.respawn(epoch)
                            new_thread.link(self.__stop_thread_checker)
                            self.__redisthreads.add(new_thread)
                timers['inactivity'] = epoch
            if epoch - timers['liveliness'] >= Heartbeat.LIVELINESS_RATE:
                if self.__heartbeat_gt is None:
                    self.__heartbeat_gt = _Thread.spawn(epoch,
                                                        self._pool,
                                                        self.__update_nodename)
                    self.__heartbeat_gt.link(self.__stop_thread_checker)
                    self.__redisthreads.add(self.__heartbeat_gt)
                timers['liveliness'] = epoch
            if epoch - timers['pipeline'] >= self.__PIPELINE_RATE:
                pipeline = curr_pipeline()
                if pipeline.command_stack:
                    new_pipeline()
                    thread = _Thread.spawn(epoch,
                                           self._pool,
                                           self.__pipe_execute,
                                           pipeline=pipeline)
                    thread.link(self.__stop_thread_checker)
                    self.__redisthreads.add(thread)
                timers['pipeline'] = epoch
            if epoch - timers['counters'] >= self.__COUNTERS_RATE:
                self.__process_counters()
                self.__check_services()
                timers['counters'] = epoch
            if epoch - timers['gc'] >= self.__GC_RATE and self.__gc_ready:
                self.__gc_ready = False
                green_thread = self._pool.spawn(self.__gc_collect)
                green_thread.link(self._stop_checker)
                timers['gc'] = epoch
            eventlet.sleep(1)


def main():
    # command line args
    print_options, ended_with_space, sys.argv = (
        get_network_docopt_info(sys.argv)
    )
    cli = NetworkDocopt(__doc__)
    try:
        if print_options:
            cli.print_options(ended_with_space)
        else:
            configfile = DefaultPaths.CONF_FILE
            cli.run(argv=[sys.argv[0]] + (sys.argv[1:] or ['--config',
                                                           configfile]))
            if cli.get('help'):
                return 0
            elif (not cli.get('--config') and not cli.get('--daemon') and
                  not cli.get('--server') and not cli.get('--debug') and
                  not cli.get('--uds')):
                return 1
            if cli.get('--config'):
                configfile = cli.get('<text-configfile>')
            conf = config.Config(configfile)
            conf.daemon = False
            conf.pidfile = DefaultPaths.PID_FILE
            if cli.get('--daemon'):
                conf.daemon = True
                if cli.get('--pidfile'):
                    conf.pidfile = cli.get('<text-pidfile>')
            if cli.get('--server'):
                server = cli.get('<ip-server>')
                if server is None:
                    server = cli.get('<text-server>')
                    try:
                        server = socket.getaddrinfo(server, 0)[0][4][0]
                    except socket.gaierror:
                        raise RuntimeError('Server %s is not known. Exiting...'
                                           % server)
                setattr(conf, config.Config.CommonConfig.server.name, server)
            if cli.get('--debug'):
                setattr(conf, config.Config.CommonConfig.debug.name, True)
            if cli.get('--uds'):
                setattr(conf, config.Config.CommonConfig.udsfile.name,
                        cli.get('<text-udsfile>'))

            cldbpush_inst = _ClDbPush(conf)
            return cldbpush_inst.run()
    except IOError as ex:
        # stdout is closed, no point in continuing
        # Attempt to close them explicitly to prevent cleanup problems:
        if str(ex).lower() != 'broken pipe':
            try:
                sys.stdout.close()
                sys.stderr.close()
            except IOError:
                pass
        return 1
