# vim: tabstop=4 shiftwidth=4 softtabstop=4
# Copyright 2016 Cumulus Networks, Inc. All rights reserved.
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc.
# 51 Franklin Street, Fifth Floor
# Boston, MA  02110-1301, USA.

"""
netq - Query data across all nodes in fabric

Usage:
   netq add server <ip-server>|<text-server>
   netq agent (start|stop|status|restart)
   netq [server <ip-server>|server <text-server>] check vlan [<hostname>|<hostname> <remote-interface>] [unverified] [around <text-time>] [json]
   netq [server <ip-server>|server <text-server>] check (agents|clag|ospf) [around <text-time>] [json]
   netq [server <ip-server>|server <text-server>] check bgp [vrf <vrf>] [around <text-time>] [json]
   netq [server <ip-server>|server <text-server>] check agents [<hostname>] history [json]
   netq [server <ip-server>|server <text-server>] resolve [around <text-time>]
   netq [server <ip-server>|server <text-server>] show bgp [<hostname>|<ip-session>|asn <number-asn>] [vrf <vrf>] [around <text-time>] [json]
   netq [server <ip-server>|server <text-server>] show bgp <hostname> [<remote-interface>|<ip-session>] [vrf <vrf>] [around <text-time>] [json]
   netq [server <ip-server>|server <text-server>] show bgp [<hostname>|<ip-session>|asn <number-asn>] [vrf <vrf>] history [between <text-time> and <text-endtime>] [json]
   netq [server <ip-server>|server <text-server>] show bgp <hostname> [<remote-interface>|<ip-session>] [vrf <vrf>] history [between <text-time> and <text-endtime>] [json]
   netq [server <ip-server>|server <text-server>] show changes [<hostname>] [<mac>|<ipv4>|<ipv6>|<ipv4> vrf <vrf>|<ipv6> vrf <vrf>|vrf <vrf] between <text-time> and <text-endtime> [json]
   netq [server <ip-server>|server <text-server>] show clag [<hostname>] [around <text-time>] [json]
   netq [server <ip-server>|server <text-server>] show clag [<hostname>] history [between <text-time> and <text-endtime>] [json]
   netq [server <ip-server>|server <text-server>] show interfaces [<hostname>|<hostname> <remote-interface>] [around <text-time>] [json]
   netq [server <ip-server>|server <text-server>] show interfaces [<hostname>] type (bond|bridge|eth|loopback|macvlan|swp|vlan|vrf|vxlan) [around <text-time>] [json]
   netq [server <ip-server>|server <text-server>] show interfaces [<hostname>|<hostname> <remote-interface>] history [between <text-time> and <text-endtime>]
   netq [server <ip-server>|server <text-server>] show interfaces [<hostname>] type (bond|bridge|eth|loopback|macvlan|swp|vlan|vrf|vxlan) history [between <text-time> and <text-endtime>] [json]
   netq [server <ip-server>|server <text-server>] show lldp [<hostname>|<hostname> <remote-physical-interface>] [history]  [json]
   netq [server <ip-server>|server <text-server>] show lldp [<hostname>|<hostname> <remote-physical-interface>] around <text-time> [json]
   netq [server <ip-server>|server <text-server>] show macs [<hostname>|<hostname> nexthop <interface-nexthop>] [<mac>] [vlan <0-4096>] [origin] [around <text-time>] [json]
   netq [server <ip-server>|server <text-server>] show macs [<hostname>|<hostname> nexthop <interface-nexthop>] [<mac>] [vlan <0-4096>] [origin] history [between <text-time> and <text-endtime>] [json]
   netq [server <ip-server>|server <text-server>] show inventory [<hostname>] [<inventory-search>|json] [json]
   netq [server <ip-server>|server <text-server>] show inventory [<hostname>] os [<os-version>|<os-name>|json] [json]
   netq [server <ip-server>|server <text-server>] show inventory [<hostname>] board [<board-vendor>|<board-model>|json] [json]
   netq [server <ip-server>|server <text-server>] show inventory [<hostname>] cpu [<cpu-arch>|<cpu-model>|json] [json]
   netq [server <ip-server>|server <text-server>] show inventory [<hostname>] disk [<disk-name>|<disk-size>|<disk-transport>|<disk-vendor>|json] [json]
   netq [server <ip-server>|server <text-server>] show inventory [<hostname>] asic [<asic-vendor>|<asic-model>|<asic-model-id>|json] [json]
   netq [server <ip-server>|server <text-server>] show inventory [<hostname>] memory [<memory-type>|<memory-size>|<memory-vendor>|json] [json]
   netq [server <ip-server>|server <text-server>] show ip addresses [<hostname>|<hostname> <remote-interface>] [<ipv4>|<ipv4/prefixlen>] [vrf <vrf>] [around <text-time>] [json]
   netq [server <ip-server>|server <text-server>] show ip addresses [<hostname>|<hostname> <remote-interface>] [<ipv4>|<ipv4/prefixlen>] [vrf <vrf>] history [between <text-time> and <text-endtime>] [json]
   netq [server <ip-server>|server <text-server>] show ipv6 addresses [<hostname>|<hostname> <remote-interface>] [<ipv6>|<ipv6/prefixlen>] [vrf <vrf>] [around <text-time>] [json]
   netq [server <ip-server>|server <text-server>] show ipv6 addresses [<hostname>|<hostname> <remote-interface>] [<ipv6>|<ipv6/prefixlen>] [vrf <vrf>] history [between <text-time> and <text-endtime>] [json]
   netq [server <ip-server>|server <text-server>] show ip routes [<hostname>] [<ipv4>|<ipv4/prefixlen>] [vrf <vrf>] [origin] [around <text-time>] [json]
   netq [server <ip-server>|server <text-server>] show ip routes [<hostname>] [<ipv4>|<ipv4/prefixlen>] [vrf <vrf>] [origin] history [between <text-time> and <text-endtime>] [json]
   netq [server <ip-server>|server <text-server>] show ipv6 routes [<hostname>] [<ipv6>|<ipv6/prefixlen>] [vrf <vrf>] [origin] [around <text-time>] [json]
   netq [server <ip-server>|server <text-server>] show ipv6 routes [<hostname>] [<ipv6>|<ipv6/prefixlen>] [vrf <vrf>] [origin] history [between <text-time> and <text-endtime>] [json]
   netq [server <ip-server>|server <text-server>] show ip neighbors [<hostname>] [<ipv4>|<ipv4> vrf <vrf>|vrf <vrf>] [<mac>]  [around <text-time>] [json]
   netq [server <ip-server>|server <text-server>] show ip neighbors <hostname> <remote-interface> [<ipv4>|<ipv4> vrf <vrf>|vrf <vrf>] [<mac>] [around <text-time>] [json]
   netq [server <ip-server>|server <text-server>] show ip neighbors [<hostname>] [<ipv4>|<ipv4> vrf <vrf>|vrf <vrf>] [<mac>] history [between <text-time> and <text-endtime>] [json]
   netq [server <ip-server>|server <text-server>] show ip neighbors <hostname> <remote-interface> [<ipv4>|<ipv4> vrf <vrf>|vrf <vrf>] [<mac>] history [between <text-time> and <text-endtime>] [json]
   netq [server <ip-server>|server <text-server>] show ipv6 neighbors [<hostname>] [<ipv6>|<ipv6> vrf <vrf>|vrf <vrf>] [<mac>] [around <text-time>] [json]
   netq [server <ip-server>|server <text-server>] show ipv6 neighbors <hostname> <remote-interface> [<ipv6>|<ipv6> vrf <vrf>|vrf <vrf>] [<mac>] around <text-time> [json]
   netq [server <ip-server>|server <text-server>] show ipv6 neighbors [<hostname>] [<ipv6>|<ipv6> vrf <vrf>|vrf <vrf>] [<mac>] history [between <text-time> and <text-endtime>] [json]
   netq [server <ip-server>|server <text-server>] show ipv6 neighbors <hostname> <remote-interface> [<ipv6>|<ipv6> vrf <vrf>|vrf <vrf>] [<mac>] history [between <text-time> and <text-endtime>] [json]
   netq [server <ip-server>|server <text-server>] show services [<hostname>] [<text-service-name>] [history|around <text-time>] [json]
   netq [server <ip-server>|server <text-server>] show stp topology [<hostname>] [bridge <text-brname>] [around <text-time>] [json]
   netq [server <ip-server>|server <text-server>] show top_talkers (rx|tx) [errors|drops] [count <1-15>] [json]
   netq [server <ip-server>|server <text-server>] show top_talkers (rx|tx) [errors|drops] [count <1-15>] around <text-time> [json]
   netq [server <ip-server>|server <text-server>] trace l2 <mac> vlan <1-4096> from <hostname> [around <text-time>] [json]
   netq [server <ip-server>|server <text-server>] trace l3 <ip> from (<hostname>|<ip-src>) [vrf <vrf>] [around <text-time>] [json]
   netq [server <ip-server>|server <text-server>] view <hostname> keys [json]

Options:
   add            : Update configuration
   addresses      : Interface addresses(IP or MAC) across all nodes in fabric
   agent          : Netq agent
   agents         : Check the 'liveness' of the agent across all the nodes
   around         : Go back in time to around ...
   asic           : Network Processor
   bgp            : Check the status of all the BGP sessions across the fabric
   board          : Switch Board
   bridge         : Name of bridge on device
   changes        : Show changes in interface/mac/route/neighbor state between specified times
   check          : check health of services or correctness of parameter
   clag           : Check the status of all the CLAG daemons across the fabric
   count          : Number of entries to show
   cpu            : Management Processor
   disk           : Storage Disk
   from           : Starting at node...
   help           : Show usage info
   history        : how this infomation has changed with time
   interfaces     : Interfaces across all nodes in fabric
   ip             : IPv4 related info
   ipv6           : IPv6 related info
   json           : provide output in JSON
   info           : show information available about ...
   l2             : bridged path
   l3             : routed path
   lldp           : LLDP based neighbor info
   mac            : destination mac address to L2 path trace
   macs           : Show mac address info, with optional VLAN, across the fabric
   memory         : Hardware RAM
   mtu            : Link MTU
   neighbor       : IP neighbor cache (ARP/ND) info across the fabric
   neighbors      : IP neighbor info (ARP/ND)
   origin         : owner of route
   os             : Operating System
   resolve        : Annotate input with names and interesting info
   routes         : Show IPv4 route info across the fabric
   rx             : Receive
   services       : Show various system services
   show           : Show fabric-wide info
   start          : Start agent
   stop           : Stop agent
   stp            : Spanning Tree
   status         : Display agent status
   server         : Specify IP address of DB server
   top_talkers    : Top interface talkers in fabric
   topology       : Active STP topology
   trace          : Control plane trace path across fabric
   tx             : Transmit
   type           : Interface type
   unverified     : show also the unverifiable interfaces
   view           : Show output of pre-defined commands on specific node
   vlan           : VLAN
   vrf            : VRF
   server         : IP address of DB server
   <0-4096>       : VLAN ID
   <1-4096>       : VLAN ID, between 1-4096
   <asic-vendor>  : Network ASIC Vendor
   <asic-model>   : Network ASIC Model
   <asic-model-id> : Network ASIC Model ID
   <board-vendor> : Board Vendor
   <board-model>  : Board Model
   <cpu-arch>     : CPU Architecture
   <cpu-model>    : CPU Processor Model
   <disk-name>    : Disk Name
   <disk-size>    : Disk Size
   <disk-transport> : Disk Transport
   <disk-vendor>  : Disk Vendor
   <hostname>     : Name of the remote node you want to query
   <interface-nextHop> : The name of the nexthop interface
   <inventory-search> : Search inventory for e.g., dell, trident2, x86, qsfp28, ddr3
   <ip-server>    : IP address of DB server
   <ip-session>   : IP address of BGP session (numbered)
   <ipv4>         : IPv4 address (no mask)
   <ipv6>         : IPv6 address (no mask)
   <ip>           : IPv4 or v6 address (no mask)
   <ip-src>       : Source IP address used in trace
   <ipv4/prefixlen> : IPv4 address with mask
   <ipv6/prefixlen> : IPv6 address with mask
   <ip/prefixlen> : IPv4 or IPv6 address with mask
   <mac>          : MAC address
   <vrf>          : VRF name
   <memory-type>  : Memory Type
   <memory-size>  : Memory Size
   <memory-vendor> : Memory Vendor
   <number-asn>     : BGP ASN
   <remote-interface> : Name of the interface on the remote node
   <remote-physical-interface> : Name of the physical interface on the remote node
   <os-version>   : Operating System version
   <os-name>      : Operating System name
   <text-brname>  : Name of the bridge
   <text-time>    : Time string such as 10m, 30s, 1h
   <text-endtime> : Time string such as 10m, 30s, 1h
   <text-server>  : hostname of DB server (must be DNS resolvable)
   <text-vlan>    : VLAN
   <text-service-name> : Name of service

Help:
    -h --help     Show this screen

"""
from __future__ import absolute_import

import bisect
import functools
import itertools
import json
import os
import socket
import subprocess
import sys
import traceback
from datetime import datetime
from operator import itemgetter
import syslog
import logging

import tabulate
from network_docopt import (
    NetworkDocopt,
    get_network_docopt_info
)

from netq.common import utils
from netq.common.enums import (
    BgColors,
    DiffState,
    Heartbeat
)
from netq.lib.netq import (
    NetQ,
    AgentHealth
)

_JSON = None
_EMPTY_JSON = '[{}]'


class _MyTabulate(object):
    @staticmethod
    def __line_row(colsizes, *_):
        return ' '.join('-' * colsize for colsize in colsizes)

    @classmethod
    def __build_row(cls, colsizes, sep, cell_values, _, colaligns):
        values_with_attrs = []
        new_cell_values = []
        for cell_value, colsize, colalign in zip(cell_values,
                                                 colsizes,
                                                 colaligns):
            color = None
            if colalign == 'right':
                fmt = '{0:>%d}' % colsize
            else:
                fmt = '{0:<%d}' % colsize
            key = cell_value.strip()
            if key.startswith(BgColors.RED):
                color = BgColors.RED
                key = fmt.format(utils.strip_colors(key).strip())
            elif key.startswith(BgColors.YELLOW):
                color = BgColors.YELLOW
                key = fmt.format(utils.strip_colors(key).strip())
            elif key.startswith(BgColors.GREEN):
                color = BgColors.GREEN
                key = fmt.format(utils.strip_colors(key).strip())
            else:
                key = fmt.format(key)
            if len(key) > colsize:
                idx = key.rfind(sep, 0, colsize)
                if idx == -1:
                    idx = colsize - 1
                if color:
                    new_cell_values.append(utils.color_wrap(color,
                                                            key[idx + 1:]))
                else:
                    new_cell_values.append(key[idx + 1:])
                key = key[:idx + 1] + ' ' * (colsize - idx - 1)
            else:
                new_cell_values.append('')
            if color:
                values_with_attrs.append(utils.color_wrap(color, key))
            else:
                values_with_attrs.append(key)
        line = ' '.join(values_with_attrs).rstrip()
        if any(new_cell_values):
            return line + '\n' + cls.__build_row(colsizes, sep,
                                                 new_cell_values, _,
                                                 colaligns)
        else:
            return line

    @classmethod
    def paginate(cls, data, headers, colsizes, sep=', ', first=False):
        colsizes = [max(x, len(y)) for x, y in zip(colsizes, headers)]
        linebelowheader = functools.partial(cls.__line_row, colsizes)
        headerrow = datarow = functools.partial(cls.__build_row, colsizes, sep)
        simple = tabulate.TableFormat(lineabove=None,
                                      linebelowheader=linebelowheader,
                                      linebetweenrows=None,
                                      linebelow=None,
                                      headerrow=headerrow,
                                      datarow=datarow,
                                      padding=0,
                                      with_header_hide=['lineabove',
                                                        'linebelow'])
        if first:
            return tabulate.tabulate(data, headers=headers, tablefmt=simple)
        else:
            return tabulate.tabulate(data, headers=[], tablefmt=simple)


def _build_diff(entries, state, mods):
    output = []
    for entry in entries:
        if entry is None:
            state += 1
            continue
        state_str = DiffState.MAP[state]
        if state == DiffState.MODIFIED:
            mods.append(entry)
            if len(mods) == 2:
                if mods[0][:-1] != mods[1][:-1]:
                    output.append((state_str,) + tuple(mods[0]))
                    output.append(('',) + tuple(mods[1]))
                mods[:] = []
        else:
            output.append((state_str,) + tuple(entry))
    return output, state


def _tabulate(output, headers=None, jsonify=False, first=True, colsizes=None):
    if jsonify:
        global _JSON # pylint: disable=global-statement
        out = []
        sanitized_headers = []
        _JSON = _JSON or []
        for header in headers:
            sanitized_headers.append(
                ''.join(i.lower() if idx == 0 else i.lower().title()
                        for idx, i in enumerate(header.split(' ')))
            )
        for ele in output:
            out.append(dict((key, utils.strip_colors(item))
                            for key, item in zip(sanitized_headers, ele)))
        _JSON.append(out)
    else:
        # Stringify timestamps
        new_output = []
        for row in output:
            new_ele = []
            for ele in row:
                if isinstance(ele, float):
                    try:
                        datetime.fromtimestamp(ele)
                        new_ele.append(utils.pretty_date(ele))
                        continue
                    except Exception:  # pylint: disable=broad-except
                        pass
                new_ele.append(ele)
            new_output.append(new_ele)
        if colsizes is not None:
            print _MyTabulate.paginate(new_output, headers=headers,
                                       colsizes=colsizes, first=first)
        else:
            output = tabulate.tabulate(new_output, headers)
            if first:
                print output
            else:
                print output[output.find('\n', output.find('\n') + 1) + 1:]


def _show_info(cli):
    """
    """
    mac = cli.get('<mac>') or '*'
    hostname = cli.get('<hostname>') or '*'
    ip_address = cli.get('<ip>') or cli.get('<ip/prefixlen>') or '*'
    asn = cli.get('<number-asn>') or '*'
    vlan = cli.get('<0-4096>') or '*'
    jsonify = cli.get('json')
    iface = '*'
    oif = '*'
    found = False
    key = None

    # For some reason, when an integer is specified it is taken as a hostname.
    # Let it be handled by the 'else' code below.
    if hostname.isdigit():
        asn = hostname
        hostname = '*'

    if ip_address is not '*':
        key = ip_address
        is_ipv6 = ':' in ip_address
        first = True
        for out in cli.netq.show_addresses(hostname, iface, ip_address, mac):
            if out and not jsonify and first:
                print 'Interface Address records are'
            found = True
            _tabulate(sorted(out),
                      ['IP', 'Node', 'Interface', 'Update Time'],
                      first=first,
                      jsonify=jsonify)
            first = False

        first = True
        for out in cli.netq.show_routes(ip_address, hostname, is_ipv6, False,
                                        vrf='*'):
            if out and not jsonify and first:
                print 'Route info about prefix %s in fabric' % ip_address
            found = True
            _tabulate(sorted(out),
                      ['Origin', 'Table', 'IP', 'Node',
                       'Nexthops', 'Update Time'],
                      first=first,
                      jsonify=jsonify)
            first = False

        out = cli.netq.show_router_id(ip_address)
        if out:
            if not jsonify:
                print 'List of nodes with Router ID %s' % ip_address
            found = True
            _tabulate(sorted(out),
                      ['Router ID', 'Node', 'ASN', 'Protocol'], jsonify)

    elif hostname is not '*':
        key = hostname
        found = True
        print cli.netq.show_info(ip_address, mac, hostname)

    elif mac is not '*':
        key = mac
        first = True
        for out in cli.netq.show_macvlan(mac, vlan, hostname, oif):
            if out and not jsonify and first:
                print 'List of nodes containing MAC %s' %mac
            found = True
            _tabulate(sorted(out),
                      ['MAC', 'VLAN', 'Node Name', 'Egress Port', 'Origin',
                       'Update Time'],
                      jsonify=jsonify,
                      first=first)
            first = False

        print cli.netq.show_info(ip_address, mac, hostname)

    else:
        # We will reach here if the info 'key' is not an IP, MAC or hostname.
        # For now, if its a whole number, we are looking for ASN *and* VLAN.
        # The rest is treated as junk.
        key = None
        if asn is not '*':
            key = asn
        elif vlan is not '*':
            key = vlan

        if not key.isdigit():
            msg = 'Key not found: %s' %key
            if jsonify:
                print json.dumps({'error': msg})
            else:
                print msg
            return 1
        key = int(key) # pylint: disable=redefined-variable-type

        # This one needs some love, the 'show_asn' is not
        # returning stuff in the right format.
        # First do the ASN check.
        # first = True
        # asn = value
        # for out in cli.netq.show_asn(asn):
        #    print out
        #    if out and not jsonify and first:
        #        print 'List of nodes with ASN %s' % asn
        #    found = True
        #    _tabulate(sorted(out),
        #              headers=['ASN', 'Node', 'Router ID'],
        #              jsonify=jsonify)
        #    first = False

        first = True
        vlan = key
        for out in cli.netq.show_macvlan(mac, vlan, hostname, oif):
            if out and not jsonify and first:
                print 'List of nodes containing VLAN %s' %vlan
            found = True
            _tabulate(sorted(out),
                      ['MAC', 'VLAN', 'Node Name', 'Egress Port', 'Origin',
                       'Update Time'],
                      jsonify=jsonify,
                      first=first)
            first = False

    if not found:
    # Once we figure error handling, revisit.
        msg = 'Key not found: %s' %key
        if jsonify:
            print json.dumps({'error': msg})
        else:
            print msg
        return 1
    return 0

def _run(cli):
    """Once upon a time...
       Will always return an integer code.
       0 = Success
       1-255 = Error .. .default to 1.
    """
    global _JSON # pylint: disable=global-statement
    server_addr = None

    if cli.get('server'):
        server_addr = cli.get('<ip-server>')
        if server_addr is None:
            server_name = cli.get('<text-server>')
            if server_name is not None and 'http' in server_name:
                server_addr = server_name
            else:
                try:
                    server_addr = socket.getaddrinfo(server_name, 0)[0][4][0]
                except socket.gaierror:
                    raise RuntimeError('Server %s is not known. Exiting' %server_name)

    start_time = end_time = None
    if cli.get('around') or cli.get('between'):
        start_time = cli.get('<text-time>')
    if cli.get('and'):
        end_time = cli.get('<text-endtime>')
    jsonify = cli.get('json')
    history = cli.get('history')

    cli.netq = NetQ(server_addr, start_time, end_time)
    netq = cli.netq

    # TESTED
    if cli.get('add'):
        if os.getuid() != 0:
            raise RuntimeError('Please run this command as root')
        print netq.update_config(server_addr)

    elif cli.get('agent'):
        if cli.get('start'):
            if os.getuid() != 0:
                raise RuntimeError('Please run this command as root')
            try:
                subprocess.check_output(
                    'systemctl enable netq-agent > /dev/null 2>&1',
                    shell=True
                )
                subprocess.check_output(
                    'systemctl reset-failed netq-agent'.split()
                )
                subprocess.check_output(
                    'systemctl start netq-agent'.split()
                )
                print utils.color_wrap(BgColors.GREEN, 'Success!')
            except subprocess.CalledProcessError:
                raise RuntimeError('Failed to start agent')
        elif cli.get('stop'):
            if os.getuid() != 0:
                raise RuntimeError('Please run this command as root')
            try:
                subprocess.check_output(
                    'systemctl stop netq-agent'.split()
                )
                subprocess.check_output(
                    'systemctl disable netq-agent > /dev/null 2>&1',
                    shell=True
                )
                print utils.color_wrap(BgColors.GREEN, 'Success!')
            except subprocess.CalledProcessError:
                raise RuntimeError('Failed to stop agent')
        elif cli.get('status'):
            try:
                subprocess.check_output('systemctl status netq-agent'.split())
                print utils.color_wrap(BgColors.GREEN, 'Running...')
            except subprocess.CalledProcessError:
                raise RuntimeError('Stopped...')
        elif cli.get('restart'):
            if os.getuid() != 0:
                raise RuntimeError('Please run this command as root')
            try:
                subprocess.check_output(
                    'systemctl enable netq-agent > /dev/null 2>&1',
                    shell=True
                )
                subprocess.check_output(
                    'systemctl reset-failed netq-agent'.split()
                )
                subprocess.check_output(
                    'systemctl restart netq-agent'.split()
                )
                print utils.color_wrap(BgColors.GREEN, 'Success!')
            except subprocess.CalledProcessError:
                raise RuntimeError('Failed to restart agent')
    elif cli.get('check'):
        if cli.get('mtu'):
            if not jsonify:
                print 'Not Implemented yet'
            else:
                print json.dumps({'error': 'Not implemented yet'})

        elif cli.get('vlan'):
            hostname = cli.get('<hostname>') or '*'
            ifname = cli.get('<remote-interface>')  # we want this to be not '*'
            unverified = cli.get('unverified')

            out_json = []
            unverified_lst, pvid_mismatch, output = (
                netq.check_vlan_consistency(hostname, ifname))

            if (unverified and unverified_lst) or pvid_mismatch or output:
                if not output and not pvid_mismatch:
                    if not jsonify:
                        print utils.color_wrap(BgColors.GREEN,
                                               'No mismatched links found')
                else:
                    if output:
                        if not jsonify:
                            print utils.color_wrap(BgColors.RED,
                                                   'Vlan mismatch found on '
                                                   'following links')
                        _tabulate(output,
                                  headers=['Node', 'Interface', 'Vlans',
                                           'Peer', 'Interface', 'Peer Vlans'],
                                  jsonify=jsonify)
                        # We have to convert the JSON above into something more
                        #  and save it since we have multiple prints and we
                        # want to incorporate them all into one big JSON string
                        if jsonify:
                            out_json.append([{'reason': 'Vlan mismatch',
                                              'nodes': _JSON[0]}])
                            _JSON = None
                    if pvid_mismatch:
                        if not jsonify:
                            print utils.color_wrap(BgColors.RED,
                                                   'PVID mismatch found on '
                                                   'following links')
                        _tabulate(pvid_mismatch,
                                  headers=['Node', 'Interface', 'PVID',
                                           'Peer', 'Interface', 'Peer PVID'],
                                  jsonify=jsonify)
                        if jsonify:
                            out_json.append([{'reason': 'PVID mismatch',
                                              'nodes': _JSON[0]}])
                            _JSON = None

                if unverified and unverified_lst:
                    if not jsonify:
                        print utils.color_wrap(BgColors.RED,
                                               'Vlan check could not be done '
                                               'on:')
                    _tabulate(unverified_lst,
                              headers=['Node', 'Interface', 'Vlans', 'Peer',
                                       'Interface'],
                              jsonify=jsonify)
                    if jsonify:
                        out_json.append([{'reason': 'Unverified',
                                          'nodes': _JSON[0]}])
                if jsonify:
                    _JSON = out_json
            else:
                if not jsonify:
                    print utils.color_wrap(BgColors.GREEN,
                                           'No mismatched links found')
                else:
                    print _EMPTY_JSON

        elif cli.get('agents'):
            if history:
                hostname = cli.get('<hostname>') or '*'
                out = []
                restarts = 0
                for key, grouper in itertools.groupby(
                        netq.show_agent_history(hostname=hostname),
                        key=itemgetter(0)
                ):
                    items = sorted(grouper, key=itemgetter(1))
                    if len(items) > 1:
                        restarts = len(items) - 1
                        color = BgColors.RED
                    else:
                        restarts = 0
                        color = BgColors.GREEN

                    last_beat = (datetime.utcnow() -
                                 datetime.utcfromtimestamp(int(items[-1][2])))
                    if last_beat.total_seconds() > Heartbeat.HEARTBEAT_DEATH:
                        cur_color = BgColors.RED
                    elif (last_beat.total_seconds() <=
                          Heartbeat.LIVELINESS_RATE):
                        cur_color = BgColors.GREEN
                    else:
                        cur_color = BgColors.YELLOW

                    if hostname != '*':
                        # Provide detailed output for this scenario
                        for item in items:
                            ts1 = item[1]
                            if not jsonify:
                                ts1 = datetime.utcfromtimestamp(int(ts1))
                            out.append([key, str(ts1)])
                    else:
                        ts1 = items[0][1]
                        ts2 = items[-1][1]
                        if not jsonify:
                            ts1 = datetime.utcfromtimestamp(int(ts1))
                            ts2 = datetime.utcfromtimestamp(int(ts2))
                        out.append([utils.color_wrap(color, key),
                                    str(ts1),
                                    utils.color_wrap(cur_color, str(ts2)),
                                    utils.color_wrap(color, '%d' % restarts)])

                if hostname == '*':
                    _tabulate(out,
                              headers=['Node', 'First Connect time',
                                       'Last Connect Time',
                                       'NumRestarts'], jsonify=jsonify)
                else:
                    if not jsonify and restarts:
                        print utils.color_wrap(BgColors.RED,
                                               'Number of Restarts: %d' %
                                               restarts)
                    _tabulate(out, headers=['Node', 'Connect Time'],
                              jsonify=jsonify)
            else:
                out = netq.show_status()
                new_out = []
                for nodename, ts1, ts2, status in out:
                    if status == AgentHealth.ROTTEN:
                        new_status = utils.color_wrap(BgColors.RED, 'Rotten')
                    elif status == AgentHealth.STALE:
                        new_status = utils.color_wrap(BgColors.YELLOW,
                                                      'Stale')
                    else:
                        new_status = utils.color_wrap(BgColors.GREEN, 'Fresh')
                    if jsonify:
                        bisect.insort(new_out,
                                      (nodename, ts1, ts2, new_status))
                    else:
                        bisect.insort(new_out,
                                      (nodename,
                                       datetime.utcfromtimestamp(int(ts1)),
                                       ts2,
                                       new_status))
                _tabulate(new_out,
                          headers=['Node Name', 'Connect Time',
                                   'Last Connect', 'Status'],
                          jsonify=jsonify)

        elif cli.get('bgp'):
            vrf = cli.get('<vrf>') or '*'
            good_out, out = netq.check_bgp_status(vrf)
            if jsonify:
                failed_cnt = len(out)
                out += good_out
                total_cnt = len(out)
            else:
                failed_cnt = len(out)
                total_cnt = len(good_out) + failed_cnt

            col_headers = ['Node', 'Neighbor', 'Peer ID', 'Reason', 'Time']
            if not total_cnt:
                if not jsonify:
                    print 'No BGP session info found'
                else:
                    print _EMPTY_JSON
                return 0
            elif failed_cnt:
                if not jsonify:
                    print utils.color_wrap(BgColors.RED,
                                           'Total Sessions: %d , '
                                           'Failed Sessions: %d ' %
                                           (total_cnt, failed_cnt))
                if out:
                    _tabulate([(utils.color_wrap(BgColors.RED, hostname),
                                utils.color_wrap(BgColors.RED, nbr),
                                utils.color_wrap(BgColors.RED, peerid),
                                utils.color_wrap(BgColors.RED, reason),
                                utils.color_wrap(BgColors.RED,
                                                 utils.pretty_date(rst_time /
                                                                   1000)))
                               for hostname, nbr, peerid, reason, rst_time in
                               sorted(out)],
                              headers=col_headers,
                              jsonify=jsonify)
            else:
                if not jsonify:
                    print utils.color_wrap(
                        BgColors.GREEN,
                        'Total Sessions: %d, Failed Sessions: 0' %
                        total_cnt)
                else:
                    _tabulate(sorted(out), headers=col_headers, jsonify=jsonify)

        elif cli.get('ospf'):
            good_out, out = netq.check_ospf_status()
            if jsonify:
                failed_cnt = len(out)
                out += good_out
                total_cnt = len(out)
            else:
                failed_cnt = len(out)
                total_cnt = len(good_out) + failed_cnt

            ts = cli.get('<text-time>') or None
            col_headers = ['Node', 'Interface', 'PeerID', 'IP Addr', 'Timestamp']
            if ts:
                timestr = utils.color_wrap(BgColors.BLUE,
                                           'Output retrieved around %s' %
                                           ts)
            if not total_cnt:
                if not jsonify:
                    print 'No OSPF session info found'
                else:
                    print _EMPTY_JSON
                return
            elif failed_cnt:
                if not jsonify:
                    print utils.color_wrap(BgColors.RED,
                                           'Total Sessions: %d , '
                                           'Failed Sessions: %d ' %
                                           (total_cnt, failed_cnt))
                if out:
                    _tabulate([(utils.color_wrap(BgColors.RED, hostname),
                                utils.color_wrap(BgColors.RED, nbr),
                                utils.color_wrap(BgColors.RED, peerid),
                                utils.color_wrap(BgColors.RED, addr),
                                utils.color_wrap(BgColors.RED,
                                                 utils.pretty_date(rst_time)))
                               for hostname, nbr, peerid, addr, rst_time in
                               sorted(out)],
                              headers=col_headers,
                              jsonify=jsonify)
            else:
                if not jsonify:
                    print utils.color_wrap(
                        BgColors.GREEN,
                        'Total Sessions: %d, Failed Sessions: 0' %
                        total_cnt)
                else:
                    _tabulate(sorted(out), headers=col_headers, jsonify=jsonify)

        elif cli.get('clag'):
            col_headers = ['Node', 'Reason']
            good_node_lst, warn_node_lst, failed_node_lst = netq.check_clag_status()

            failed_cnt = len(failed_node_lst)
            warn_cnt = len(warn_node_lst)
            total_cnt = len(good_node_lst) + failed_cnt + warn_cnt
            failed_node_lst += warn_node_lst

            if not total_cnt:
                if not jsonify:
                    print 'No CLAG session info found'
            elif not failed_cnt:
                if not warn_cnt:
                    if not jsonify:
                        print utils.color_wrap(BgColors.GREEN,
                                            'Checked Nodes: %d, Failed Nodes: 0'
                                            % total_cnt)
                else:
                    if not jsonify:
                        print utils.color_wrap(
                            BgColors.WARNING,
                            'Checked Nodes: %d, Warning Nodes: %d'
                            % (total_cnt, warn_cnt)
                        )
            else:
                if not jsonify:
                    if not warn_cnt:
                        print utils.color_wrap(BgColors.RED,
                                            'Checked Nodes: %d, '
                                            'Failed Nodes: %d ' % (total_cnt,
                                                                  failed_cnt))
                    else:
                        print utils.color_wrap(BgColors.RED,
                                            'Checked Nodes: %d, '
                                            'Warning Nodes: %d, '
                                            'Failed Nodes: %d ' % (total_cnt,
                                                                   warn_cnt,
                                                                  failed_cnt))

            if failed_cnt or warn_cnt or jsonify:
                new_failed_node_list = []
                for nodename, err_str in failed_node_lst:
                    if isinstance(err_str, list):
                        err_str = ', '.join(err_str)
                    if err_str:
                        new_failed_node_list.append(
                            (nodename, utils.color_wrap(BgColors.RED, err_str))
                        )
                    else:
                        new_failed_node_list.append((nodename, ''))
                colsizes = [16, 64]
                _tabulate(sorted(new_failed_node_list),
                          headers=col_headers,
                          colsizes=colsizes,
                          jsonify=jsonify)
                if jsonify:
                    out_json = []
                    out_json.append([
                        {'failedNodes': _JSON[0]},
                        {'failedNodeCount': failed_cnt},
                        {'totalCheckedNodes': total_cnt},
                        {'warningNodeCount': warn_cnt}
                        ])
                    _JSON = out_json

    elif cli.get('resolve'):
        if not sys.stdin.isatty():
            print netq.resolve_output()

    elif cli.get('trace'):
        visited_nodes = set()
        if cli.get('l2'):
            output = netq.path_trace_mac(cli.get('<mac>'),
                                         cli.get('<1-4096>'),
                                         cli.get('<hostname>'),
                                         True, visited_nodes)
        elif cli.get('l3'):
            output = netq.path_trace_route(
                cli.get('<ip>'), cli.get('<hostname>'), cli.get('<ip-src>'),
                cli.get('<vrf>'), True, visited_nodes, None, None, None
            )

        if not output:
            if cli.get('l2'):
                addr = cli.get('<mac>')
            else:
                addr = cli.get('<ip>')

            from_node = cli.get('<hostname>')
            if not from_node:
                from_node = cli.get('<ip-src>')

            if not jsonify:
                print utils.color_wrap(
                    BgColors.RED,
                    'No path to %s from %s found\n' % (addr, from_node))
            else:
                print _EMPTY_JSON
            return 0

        if jsonify:
            flattened_paths = []
        else:
            flattened_paths = None
        utils.prtree(output[0], 0, True, [], flattened_paths)
        if jsonify:
            json_out = {'totalPaths': len(flattened_paths),
                        'paths': flattened_paths}
            print json.dumps(json_out)
        else:
            print

    elif cli.get('view'):
        hostname = cli.get('<hostname>')
        if cli.get('keys'):
            _tabulate(sorted(netq.show_keys(hostname)),
                      ['Key', 'Oldest', 'Newest', 'Count'],
                      jsonify=jsonify)
        else:
            argv = cli.argv_expanded
            # Taking the hostname into account
            startidx = argv.index('view') + 2
            endidx = None
            if cli.get('around'):
                endidx = argv.index('around')

            tsp, output = netq.view(hostname, argv[startidx:endidx])
            print '\n'.join([
                utils.color_wrap(BgColors.RED, 'Output retrieved from %s' %
                                 utils.pretty_date(tsp)), output])

    elif cli.get('show'):
        if cli.get('info'):
            raise NotImplementedError('show info is not implemented yet')

        elif cli.get('bgp'):
            hostname = cli.get('<hostname>') or '*'
            session = (
                cli.get('<remote-interface>') or cli.get('<ip-session>') or '*'
            )
            asn = cli.get('<number-asn>') or '*'
            vrf = cli.get('<vrf>') or '*'

            if history:
                entries, bad = netq.get_bgp_status_history(hostname, session,
                                                           asn, vrf)
                colsizes = [16, 24, 6, 6, 24, 4, 14]
                headers = ['Node', 'Neighbor', 'ASN', 'Peer ASN',
                           'Details', 'DbState', 'Timestamp']
            else:
                entries, bad = netq.get_bgp_status_details(hostname, session,
                                                           asn, vrf)
                colsizes = [16, 24, 6, 6, 28]
                headers = ['Node', 'Neighbor', 'ASN', 'Peer ASN',
                           'Details']

            if not bad and not entries:
                if not jsonify:
                    print "No BGP Session Info Available"
                else:
                    print _EMPTY_JSON
                return 0

            if history:
                _tabulate(sorted([(utils.color_wrap(BgColors.RED, node),
                                   utils.color_wrap(BgColors.RED, nbr),
                                   utils.color_wrap(BgColors.RED, str(asn)),
                                   utils.color_wrap(BgColors.RED, str(pasn)),
                                   utils.color_wrap(BgColors.RED, details),
                                   utils.color_wrap(BgColors.RED, dbs),
                                   timestamp)
                                  for (node, nbr, asn, pasn, details, dbs,
                                       timestamp) in bad] + list(entries),
                                 key=itemgetter(7), reverse=True),
                          headers=headers, jsonify=jsonify, colsizes=colsizes)
            else:
                _tabulate(sorted([(utils.color_wrap(BgColors.RED, node),
                                   utils.color_wrap(BgColors.RED, nbr),
                                   utils.color_wrap(BgColors.RED, str(asn)),
                                   utils.color_wrap(BgColors.RED, str(pasn)),
                                   utils.color_wrap(BgColors.RED, details))
                                  for (node, nbr, asn, pasn, details) in
                                  bad] + list(entries),
                                 key=lambda x: utils.strip_colors(x[0])),
                          headers=headers, jsonify=jsonify, colsizes=colsizes)

        elif cli.get('clag'):
            hostname = cli.get('<hostname>') or '*'
            if history:
                entries, bad = netq.get_clag_status_history(hostname)
                colsizes = [16, 16, 17, 4, 6, 5, 6, 3, 14]
                headers = ['Node', 'Peer', 'SysMac', 'State', 'Backup',
                           '#Bonds', '#Dual', 'DbState', 'Timestamp']
            else:
                entries, bad = netq.get_clag_status_details(hostname)
                colsizes = [16, 16, 17, 4, 6, 6, 5]
                headers = ['Node', 'Peer', 'SysMac', 'State', 'Backup',
                           '#Bonds', '#Dual']

            if not bad and not entries:
                if not jsonify:
                    print "No CLAG Session Info Available"
                else:
                    print _EMPTY_JSON
                return 0

            if history:
                _tabulate(sorted([(utils.color_wrap(BgColors.RED, node),
                                   utils.color_wrap(BgColors.RED, peer),
                                   utils.color_wrap(BgColors.RED, sysmac),
                                   utils.color_wrap(BgColors.RED, state),
                                   utils.color_wrap(BgColors.RED, backup),
                                   utils.color_wrap(BgColors.RED, str(tbonds)),
                                   utils.color_wrap(BgColors.RED, str(dbonds)),
                                   utils.color_wrap(BgColors.RED, dbs),
                                   timestamp)
                                  for (node, peer, sysmac, state, backup,
                                       tbonds, dbonds, dbs, timestamp) in bad] +
                                 list(entries), key=itemgetter(8),
                                 reverse=True),
                          headers, jsonify=jsonify)
            else:
                _tabulate(sorted([(utils.color_wrap(BgColors.RED, node),
                                   utils.color_wrap(BgColors.RED, peer),
                                   utils.color_wrap(BgColors.RED, sysmac),
                                   utils.color_wrap(BgColors.RED, state),
                                   utils.color_wrap(BgColors.RED, backup),
                                   utils.color_wrap(BgColors.RED, str(tbonds)),
                                   utils.color_wrap(BgColors.RED, str(dbonds)))
                                  for (node, peer, sysmac, state, backup,
                                       tbonds, dbonds) in bad] + list(entries),
                                 key=lambda x: utils.strip_colors(x[0])),
                          headers, jsonify=jsonify)

        elif cli.get('interfaces'):
            hostname = cli.get('<hostname>') or '*'
            interface = cli.get('<remote-interface>') or '*'

            kind = (
                cli.get('bond') or cli.get('bridge') or cli.get('macvlan') or
                cli.get('vlan') or cli.get('eth') or cli.get('loopback') or
                cli.get('swp') or cli.get('vxlan') or cli.get('vrf') or '*'
            )
            if history:
                headers = ['Node', 'Interface', 'DbState', 'Details',
                           'Update Time', 'State']
                colsizes = [16, 12, 5, 27, 15, 5]

                out = netq.show_link_history(hostname, interface, kind)
                if out:
                    _tabulate(out, headers, jsonify=jsonify, colsizes=colsizes)
                else:
                    if not jsonify:
                        print 'No matching Link found'
                    else:
                        print _EMPTY_JSON
            else:
                headers = ['Node', 'Interface', 'Type', 'Link', 'Details',
                           'Update Time']
                colsizes = [15, 15, 8, 4, 24, 14]
                first = True
                for out in netq.show_links(hostname, interface, kind):
                    _tabulate(sorted(out), headers, jsonify=jsonify,
                              first=first, colsizes=colsizes)
                    first = False
                if first:
                    if not jsonify:
                        print 'No matching Links found'
                    else:
                        print _EMPTY_JSON

        elif cli.get('lldp'):
            node = cli.get('<hostname>') or '*'
            iface = cli.get('<remote-physical-interface>') or '*'
            out = netq.show_neighbors(node, iface)
            if out:
                if not jsonify:
                    if node is not None:
                        if iface is not None:
                            print 'LLDP peer info for %s:%s' % (node, iface)
                        else:
                            print 'LLDP Peer Info for %s' % node
                    else:
                        print 'LLDP Info for fabric'
                _tabulate(sorted(out),
                          headers=['Node', 'Interface', 'LLDP Peer',
                                   'Peer Int', 'Update Time'],
                          jsonify=jsonify)
            else:
                if not jsonify:
                    print 'No LLDP record found'
                else:
                    print _EMPTY_JSON

        elif cli.get('macs'):
            mac = cli.get('<mac>') or '*'
            vlan = cli.get('<0-4096>')
            if vlan is not None:
                vlan = int(vlan)
            else:
                vlan = '*' # pylint: disable=redefined-variable-type

            hostname = cli.get('<hostname>') or '*'
            oif = cli.get('<interface-nexthop>') or '*'
            origin = cli.get('origin') == 'origin' or '*'

            first = True

            if history:
                entries = netq.show_mac_history(mac, vlan, hostname, oif,
                                                origin)
                headers = ['MAC', 'VLAN', 'Node Name', 'Egress Port',
                           'Origin', 'Update Time', 'State']
                colsizes = [20, 8, 12, 16, 4, 14, 6]
            else:
                headers = ['MAC', 'VLAN', 'Node Name', 'Egress Port',
                           'Origin', 'Update Time']
                colsizes = [20, 8, 12, 16, 4, 16]
                entries = netq.show_macvlan(mac, vlan, hostname, oif, origin)

            for out in entries:
                if not jsonify and first:
                    msg = None
                    if mac != '*':
                        msg = 'List of nodes containing MAC %s' % mac
                        if vlan != '*':
                            msg += ' vlan %s' % vlan
                    if vlan != '*':
                        msg = ('List of nodes containing MACs with vlan %s'
                               % vlan)
                    if msg:
                        print msg
                if history:
                    _tabulate(out, headers=headers, jsonify=jsonify,
                              first=first, colsizes=colsizes)
                else:
                    _tabulate(sorted(out), headers=headers, jsonify=jsonify,
                              first=first, colsizes=colsizes)
                first = False

            if first:
                if not jsonify:
                    print 'No matching MAC entry found'
                else:
                    print _EMPTY_JSON

        elif cli.get('addresses'):
            node = cli.get('<hostname>') or '*'
            iface = cli.get('<remote-interface>') or '*'
            vrf = cli.get('<vrf>') or '*'
            if cli.get('ip'):
                ip_address = (
                    cli.get('<ipv4>') or cli.get('<ipv4/prefixlen>') or '*'
                )
                is_ipv6 = False
            else:
                ip_address = (
                    cli.get('<ipv6>') or cli.get('<ipv6/prefixlen>') or '*'
                )
                is_ipv6 = True

            if history:
                out = netq.show_address_history(node, iface, ip_address, vrf,
                                                is_ipv6)
                if out:
                    headers = ['Address', 'Node', 'Interface', 'Present',
                               'Update Time']

                    _tabulate(out, headers, jsonify=jsonify)
                else:
                    if not jsonify:
                        print 'No matching Address found'
                    else:
                        print _EMPTY_JSON
            else:
                headers = ['Address', 'Node', 'Interface', 'Update Time']
                colsizes = [28, 12, 20, 16]
                first = True
                for out in netq.show_addresses(node, iface, ip_address, vrf,
                                               is_ipv6):
                    if not jsonify and first:
                        print 'Matching interface Address records are'
                    _tabulate(sorted(out), headers, jsonify=jsonify,
                              first=first, colsizes=colsizes)
                    first = False
                if first:
                    if not jsonify:
                        print 'No matching Interface Address entry found'
                    else:
                        print _EMPTY_JSON

        elif cli.get('services'):
            hostname = cli.get('<hostname>') or '*'
            svcname = cli.get('<text-service-name>') or '*'

            out = netq.get_services_status(hostname, svcname)
            _tabulate(sorted(out),
                      ['Node', 'Service', 'Enabled', 'Active', 'Monitored',
                       'Failed', 'Timestamp'],
                      jsonify=jsonify)

        elif cli.get('inventory'):
            hostname = cli.get('<hostname>') or '*'
            if cli.get('os'):
                os_version_id = cli.get('<os-version>') or None
                os_name = cli.get('<os-name>') or None
                search_str = os_name or os_version_id or None
                out = netq.get_os_status(hostname, search_str)
                _tabulate(sorted(out), ['Node', 'OS Name', 'OS Version'],
                          jsonify=jsonify)
            elif cli.get('board'):
                vendor = cli.get('<board-vendor>') or None
                model = cli.get('<board-model>') or None
                search_str = vendor or model or None
                out = netq.get_board_status(hostname, search_str)
                _tabulate(sorted(out), ['Node', 'Vendor', 'Model', 'Base MAC',
                                        'Serial No', 'Part No', 'Rev', 'Mfg Date'],
                          jsonify=jsonify)
            elif cli.get('cpu'):
                arch = cli.get('<cpu-arch>') or None
                model = cli.get('<cpu-model>') or None
                search_str = arch or model or None
                out = netq.get_cpu_status(hostname, search_str)
                _tabulate(
                    sorted(out),
                    ['Node', 'Arch', 'Model', 'Freq', 'Cores', 'Memory'],
                    jsonify=jsonify)
            elif cli.get('asic'):
                vendor = cli.get('<asic-vendor>') or None
                model = cli.get('<asic-model>') or None
                model_id = cli.get('<asic-model-id>') or None
                search_str = vendor or model or model_id or None
                out = netq.get_asic_status(hostname, search_str)
                _tabulate(
                    sorted(out),
                    ['Node', 'Vendor', 'Model', 'Model ID', 'Core B/W', 'Ports'],
                    jsonify=jsonify)
            elif cli.get('disk'):
                name = cli.get('<disk-name>') or None
                size = cli.get('<disk-size>') or None
                transport = cli.get('<disk-transport>') or None
                vendor = cli.get('<disk-vendor>') or None
                search_str = name or size or transport or vendor or None
                out = netq.get_disk_status(hostname, search_str)
                _tabulate(
                    sorted(out),
                    ['Node', 'Name', 'Type', 'Transport', 'Size', 'Vendor',
                     'Model'],
                    jsonify=jsonify)
            elif cli.get('memory'):
                m_type = cli.get('<memory-type>') or None
                size = cli.get('<memory-size>') or None
                vendor = cli.get('<memory-vendor>') or None
                search_str = m_type or size or vendor or None
                out = netq.get_memory_status(hostname, search_str)
                _tabulate(
                    sorted(out),
                    ['Node', 'Name', 'Type', 'Size', 'Speed', 'Vendor',
                     'Serial No'],
                    jsonify=jsonify)
            else:
                out = []
                search_str = cli.get('<inventory-search>') or None
                if hostname is not '*':
                    out = netq.get_inventory_status(hostname)
                    if len(out):
                        _tabulate(sorted(out),
                                  ['Node', 'Switch', 'OS', 'CPU', 'ASIC', 'Ports'],
                                  jsonify=jsonify)
                        return 0
                    search_str = hostname
                    hostname = '*'
                if not search_str:
                    out = netq.get_inventory_status(hostname)
                    if len(out):
                        _tabulate(sorted(out),
                                  ['Node', 'Switch', 'OS', 'CPU', 'ASIC', 'Ports'],
                                  jsonify=jsonify)
                        return 0
                out = netq.get_os_status(hostname, search_str)
                if len(out):
                    _tabulate(sorted(out), ['Node', 'OS Name', 'OS Version'],
                              jsonify=jsonify)
                    return 0
                out = netq.get_cpu_status(hostname, search_str)
                if len(out):
                    _tabulate(
                        sorted(out),
                        ['Node', 'Arch', 'Model', 'Freq', 'Cores', 'Memory'],
                        jsonify=jsonify)
                    return 0
                out = netq.get_asic_status(hostname, search_str)
                if len(out):
                    _tabulate(
                        sorted(out),
                        ['Node', 'Vendor', 'Model', 'Model ID', 'Core B/W', 'Ports'],
                        jsonify=jsonify)
                    return 0
                out = netq.get_board_status(hostname, search_str)
                if len(out):
                    _tabulate(sorted(out),
                              ['Node', 'Vendor', 'Model', 'Base MAC',
                               'Serial No', 'Part No', 'Rev', 'Mfg Date'],
                              jsonify=jsonify)
                    return 0
                out = netq.get_disk_status(hostname, search_str)
                if len(out):
                    _tabulate(
                        sorted(out),
                        ['Node', 'Name', 'Type', 'Transport', 'Size', 'Vendor',
                         'Model'],
                        jsonify=jsonify)
                    return 0
                out = netq.get_memory_status(hostname, search_str)
                if len(out):
                    _tabulate(
                        sorted(out),
                        ['Node', 'Name', 'Type', 'Size', 'Speed', 'Vendor',
                         'Serial No'],
                        jsonify=jsonify)
                    return 0
                if jsonify:
                    print _EMPTY_JSON

        elif cli.get('stp'):
            brname = cli.get('<text-brname>') or '*'
            hostname = cli.get('<hostname>') or '*'

            if jsonify:
                flattened_paths = []
            else:
                flattened_paths = None

            stpmap = netq.get_stp_topo(hostname, brname, True)
            if stpmap:
                utils.prtree(stpmap[0], 0, True, [], flattened_paths)
                if len(stpmap) == 2:
                    if jsonify:
                        peerpaths = flattened_paths
                        flattened_paths = []
                    else:
                        print
                    utils.prtree(stpmap[1][0], 0, True, [], flattened_paths)
                    if jsonify:
                        flattened_paths += peerpaths

                if jsonify:
                    print json.dumps(flattened_paths)
                else:
                    print

        elif cli.get('routes'):
            hostname = cli.get('<hostname>') or '*'
            if cli.get('ip'):
                ip_address = (
                    cli.get('<ipv4>') or cli.get('<ipv4/prefixlen>') or '*'
                )
                is_ipv6 = False
            else:
                ip_address = (
                    cli.get('<ipv6>') or cli.get('<ipv6/prefixlen>') or '*'
                )
                is_ipv6 = True
            if cli.get('origin'):
                origin = True
            else:
                origin = '*' # pylint: disable=redefined-variable-type
            vrf = cli.get('<vrf>') or '*'

            if history:
                out = netq.show_route_history(ip_address, hostname,
                                              ipv6=is_ipv6, origin=origin,
                                              vrf=vrf)
                if is_ipv6:
                    colsizes = [3, 8, 32, 14, 24, 14, 5]
                else:
                    colsizes = [3, 8, 16, 14, 24, 14, 5]
                if out:
                    _tabulate(out,
                              ['Origin', 'Table', 'IP', 'Node', 'Nexthops',
                               'Update Time', 'State'],
                              jsonify=jsonify, colsizes=colsizes)
                else:
                    if not jsonify:
                        print 'No matching route found'
                    else:
                        print _EMPTY_JSON
            else:
                headers = ['Origin', 'Table', 'IP', 'Node', 'Nexthops',
                           'Update Time']
                if is_ipv6:
                    colsizes = [3, 8, 32, 16, 25, 16]
                else:
                    colsizes = [3, 8, 16, 16, 25, 16]
                first = True
                for out in netq.show_routes(ip_address, hostname, is_ipv6,
                                            origin, vrf):
                    if not jsonify and first:
                        if ip_address:
                            if hostname:
                                print('Route info about prefix %s on '
                                      'host %s' % (ip_address, hostname))
                            else:
                                print('Route info about prefix %s in '
                                      'fabric' % ip_address)
                        elif hostname:
                            print 'Routes in host %s FIB' % hostname
                        else:
                            print 'List of all routes in fabric'
                    # Print routes with origin first
                    _tabulate(sorted(out), headers, jsonify=jsonify,
                              first=first, colsizes=colsizes)
                    first = False

                if first:
                    if not jsonify:
                        print 'No matching routes found'
                    else:
                        print _EMPTY_JSON

        elif cli.get('neighbors'):
            if cli.get('ip'):
                ip_address = cli.get('<ipv4>') or '*'
                is_ipv6 = False
            else:
                ip_address = cli.get('<ipv6>') or '*'
                is_ipv6 = True

            mac = cli.get('<mac>') or '*'
            hostname = cli.get('<hostname>') or '*'
            iface = cli.get('<remote-interface>') or '*'
            if history:
                out = netq.show_ip_neighbor_history(hostname=hostname,
                                                    ip_address=ip_address,
                                                    ifname=iface,
                                                    mac=mac,
                                                    ipv6=is_ipv6)
                if out:
                    _tabulate(out,
                              ['IP', 'Node', 'Interface', 'MAC',
                               'Present', 'Update Time'],
                              jsonify)
                else:
                    if not jsonify:
                        print 'No IP neighbor entry found'
                    else:
                        print _EMPTY_JSON
            else:
                headers = ['IP', 'Node', 'Interface', 'MAC', 'Update Time']
                colsizes = [16, 16, 20, 24, 16]
                first = True
                for out in netq.show_ip_neighbors(ip_address, hostname,
                                                  iface, mac, is_ipv6):
                    if not jsonify and first:
                        if ip_address is not '*':
                            print 'IP Neighbor info for %s' % ip_address
                        else:
                            print 'IP Neighbor Info for fabric'
                    _tabulate(sorted(out), headers, jsonify=jsonify,
                              first=first, colsizes=colsizes)
                    first = False
                if first:
                    if not jsonify:
                        print 'No IP neighbor entry found'
                    else:
                        print _EMPTY_JSON

        # This has to be the last entry under 'show' to separate it from
        # the 'changes' option under the more specific objects
        elif cli.get('changes'):
            hostname = cli.get('<hostname>') or '*'
            interface = cli.get('<remote-interface>') or '*'
            mac = cli.get('<mac>') or '*'
            vlan = cli.get('<0-4096>')
            if vlan is not None:
                vlan = int(vlan)
            else:
                vlan = '*'
            vrf = cli.get('<vrf>') or '*'
            
            ip_address = (
                cli.get('<ipv4>') or cli.get('<ipv4/prefixlen>')
                or cli.get('<ipv6>') or cli.get('<ipv6/prefixlen>') or '*'
            )

            is_ipv6 = False
            if ':' in ip_address:
                is_ipv6 = True

            out_json = []
            # Show interface changes
            headers = ['Node', 'Interface', 'State', 'Details',
                       'Update Time', 'DbState']
            colsizes = [16, 12, 5, 27, 15, 5]

            if ip_address == '*' and mac == '*':
                out = netq.show_link_history(hostname, interface, '*')
                if out:
                    if not jsonify:
                        print "Interface state changes"
                    _tabulate(out, headers, jsonify=jsonify, colsizes=colsizes)
                    if jsonify:
                        out_json.append([{'interfaces': _JSON[0]}])
                        _JSON = None
                else:
                    if not jsonify:
                        print 'No link changes found'

            # Show interface address changes
            if mac == '*':
                out = netq.show_address_history(hostname, interface, ip_address,
                                                is_ipv6=is_ipv6)
                if out:
                    headers = ['Address', 'Node', 'Interface', 'Update Time',
                               'State']
                    if not jsonify:
                        print "\nInterface address changes"

                    _tabulate(out, headers, jsonify=jsonify)
                    if jsonify:
                        out_json.append([{'addresses': _JSON[0]}])
                        _JSON = None
                else:
                    if not jsonify:
                        print 'No changes to addresses found'

            # Show MAC Table changes
            if ip_address == '*':
                entries = netq.show_mac_history(mac, vlan, hostname, '*',
                                                origin='*')
                headers = ['MAC', 'VLAN', 'Node Name', 'Egress Port',
                           'Origin', 'Update Time', 'State']
                colsizes = [20, 8, 12, 16, 4, 14, 6]
                first = True
                for out in entries:

                    if not jsonify:
                        print "\nMAC table changes"

                    _tabulate(out, headers=headers, jsonify=jsonify,
                              first=first, colsizes=colsizes)
                    first = False
                if first:
                    if not jsonify:
                        print 'No changes to MAC table found'
                else:
                    if jsonify:
                        out_json.append([{'macs': _JSON[0]}])
                        _JSON = None

            # Show route changes
            if mac == '*':
                out = netq.show_route_history(ip_address, hostname,
                                              ipv6=is_ipv6, origin='*',
                                              vrf=vrf)
                if out:
                    if is_ipv6:
                        colsizes = [3, 3, 32, 14, 24, 14, 5]
                    else:
                        colsizes = [3, 3, 16, 14, 24, 14, 5]

                    if not jsonify:
                        print "\nIP Route changes"

                    _tabulate(out,
                              ['Origin', 'Table', 'IP', 'Node', 'Nexthops',
                               'Update Time', 'State'],
                              jsonify=jsonify, colsizes=colsizes)
                    if jsonify:
                        out_json.append([{'routes': _JSON[0]}])
                        _JSON = None
                else:
                    if not jsonify:
                        print 'No changes to routes found'

            # Show neighbor changes
            out = netq.show_ip_neighbor_history(hostname=hostname,
                                                ip_address=ip_address,
                                                ifname=interface, mac=mac,
                                                ipv6=is_ipv6)
            if out:
                colsizes = [16, 16, 16, 24, 14, 6]
                if not jsonify:
                    print "\nIP Neighbor changes"

                _tabulate(out,
                          ['IP', 'Node', 'Interface', 'MAC',
                           'Update Time', 'State'],
                          jsonify, colsizes=colsizes)
                if jsonify:
                    out_json.append([{'neighbors': _JSON[0]}])
                    _JSON = None
            else:
                if not jsonify:
                    print 'No IP neighbor changes found'

            # Show BGP protocol changes
            entries, bad = netq.get_bgp_status_history(hostname, '*', '*', '*')
            colsizes = [16, 24, 6, 6, 8, 16, 4, 14]
            headers = ['Node', 'Neighbor', 'ASN', 'Peer ASN',
                       'State', 'Details', 'DbState', 'Timestamp']
            if bad or entries:
                if not jsonify:
                    print "\nBGP Changes"

                _tabulate([(utils.color_wrap(BgColors.RED, node),
                            utils.color_wrap(BgColors.RED, nbr),
                            utils.color_wrap(BgColors.RED, str(asn)),
                            utils.color_wrap(BgColors.RED, str(pasn)),
                            utils.color_wrap(BgColors.RED, state),
                            utils.color_wrap(BgColors.RED, details),
                            utils.color_wrap(BgColors.RED, dbs),
                            utils.color_wrap(BgColors.RED,
                                             utils.pretty_date(timestamp)))
                           for (node, nbr, asn, pasn, state, details, dbs,
                                timestamp) in bad] + list(entries),
                          headers=headers, jsonify=jsonify, colsizes=colsizes)

                if jsonify:
                    out_json.append([{'bgpd': _JSON[0]}])
                    _JSON = None

            entries, bad = netq.get_clag_status_history(hostname)
            colsizes = [16, 16, 17, 4, 6, 5, 6, 3, 14]
            headers = ['Node', 'Peer', 'SysMac', 'State', 'Backup',
                       '#Bonds', '#Dual', 'DbState', 'Timestamp']

            if bad or entries:
                if not jsonify:
                    print "CLAG Changes\n"

                _tabulate([(utils.color_wrap(BgColors.RED, node),
                            utils.color_wrap(BgColors.RED, peer),
                            utils.color_wrap(BgColors.RED, sysmac),
                            utils.color_wrap(BgColors.RED, state),
                            utils.color_wrap(BgColors.RED, backup),
                            utils.color_wrap(BgColors.RED, str(tbonds)),
                            utils.color_wrap(BgColors.RED, str(dbonds)),
                            utils.color_wrap(BgColors.RED, dbs),
                            utils.color_wrap(BgColors.RED,
                                             utils.pretty_date(timestamp)))
                           for (node, peer, sysmac, state, backup, tbonds,
                                dbonds, dbs, timestamp) in bad] + list(entries),
                          headers, jsonify=jsonify)

                if jsonify:
                    out_json.append([{'clagd': _JSON[0]}])
                    _JSON = None

            # JSON Processing at the end
            if out_json:
                _JSON = out_json
            else:
                if jsonify:
                    print _EMPTY_JSON
                _JSON = None

        elif cli.get('top_talkers'):
            show_rx = cli.get('rx')
            show_errors = cli.get('errors')
            show_drops = cli.get('drops')
            count = cli.get('<1-15>') or 5
            if show_rx:
                api = netq.top_talkers_rx
            else:
                api = netq.top_talkers_tx
            output = api(count)
            if show_errors:
                if not output['if_err_bps']:
                    if not jsonify:
                        print 'No interfaces with errors'
                    else:
                        print _EMPTY_JSON
                else:
                    if not jsonify and output['if_err_ts']:
                        print utils.color_wrap(
                            BgColors.RED,
                            'Output retrieved from %s' %
                            utils.pretty_date(output['if_err_ts'])
                        )
                    _tabulate(output['if_err_bps'], ['Nodename', 'Ifname',
                                                     'Error Rate(bps)'],
                              jsonify)
            elif show_drops:
                if not output['if_drop_bps']:
                    if not jsonify:
                        print 'No interfaces with drops'
                    else:
                        print _EMPTY_JSON
                else:
                    if not jsonify and output['if_drop_ts']:
                        print(
                            utils.color_wrap(
                                BgColors.RED,
                                'Output retrieved from %s' %
                                utils.pretty_date(output['if_drop_ts'])
                            )
                        )
                    _tabulate(output['if_drop_bps'], ['Nodename', 'Ifname',
                                                      'Drop Rate(bps)'],
                              jsonify)
            else:
                if not output['if_bps']:
                    if not jsonify:
                        print 'Not available'
                    else:
                        print _EMPTY_JSON
                else:
                    if not jsonify and output['if_ts']:
                        print utils.color_wrap(
                            BgColors.RED,
                            'Output retrieved from %s' %
                            utils.pretty_date(output['if_ts'])
                        )
                    _tabulate(output['if_bps'],
                              ['Nodename', 'Ifname', 'Rate(bps)'],
                              jsonify)

    return 0

def _view_complete(argv, doc):
    """ Hack to remove <wildcard> hacks from network docopt
    """
    view_idx = next((idx for idx, arg in enumerate(argv) if arg == 'view'),
                    None)
    if view_idx is not None and len(argv) >= view_idx + 2:
        choices = NetQ.view_complete(argv[view_idx + 1])
        aroundstring = ' around <text-time>'
        viewstring = ('   netq [server <ip-server>|server <text-server>] '
                      'view <hostname> {key}')
        usage_idx = doc.find('Usage:')
        options_idx = doc.find('Options:')
        pre_usage = doc[:usage_idx]
        usage = doc[usage_idx:options_idx].rstrip('\n')
        post_usage = doc[options_idx:]
        new_usage = '%s\n%s\n%s\n' % (usage,
                                      '\n'.join([viewstring.format(key=choice)
                                                 for choice in choices]),
                                      '\n'.join([viewstring.format(key=choice)
                                                 + aroundstring
                                                 for choice in choices]))
        return pre_usage + new_usage + post_usage
    return doc


def main():
    '''
    '''

    logging.getLogger('network_docopt').addHandler(logging.NullHandler())
    
    (print_options, ended_with_space, sys.argv) = (
        get_network_docopt_info(sys.argv)
    )

    cli = NetworkDocopt(_view_complete(sys.argv, __doc__))

    # Add custom completers
    cli.add_tag_matcher('<hostname>', NetQ.hostname_match, True)
    cli.add_tab_complete_hook('<hostname>', NetQ.hostname_complete)
    cli.add_tag_matcher('<remote-interface>', NetQ.interface_match, True)
    cli.add_tab_complete_hook('<remote-interface>', NetQ.interface_complete)
    cli.add_tag_matcher('<remote-physical-interface>', NetQ.interface_match, True)
    cli.add_tab_complete_hook('<remote-physical-interface>', NetQ.physical_interface_complete)
    cli.add_tag_matcher('<os-version>', NetQ.os_match, True)
    cli.add_tab_complete_hook('<os-version>', NetQ.os_version_complete)
    cli.add_tag_matcher('<os-name>', NetQ.os_match, True)
    cli.add_tab_complete_hook('<os-name>', NetQ.os_name_complete)
    cli.add_tag_matcher('<cpu-arch>', NetQ.cpu_match, True)
    cli.add_tab_complete_hook('<cpu-arch>', NetQ.cpu_arch_complete)
    cli.add_tag_matcher('<cpu-model>', NetQ.cpu_match, True)
    cli.add_tab_complete_hook('<cpu-model>', NetQ.cpu_model_complete)
    cli.add_tag_matcher('<board-vendor>', NetQ.board_match, True)
    cli.add_tag_matcher('<board-model>', NetQ.board_match, True)
    cli.add_tab_complete_hook('<board-vendor>', NetQ.board_vendor_complete)
    cli.add_tab_complete_hook('<board-model>', NetQ.board_model_complete)
    cli.add_tag_matcher('<asic-vendor>', NetQ.asic_match, True)
    cli.add_tag_matcher('<asic-model>', NetQ.asic_match, True)
    cli.add_tag_matcher('<asic-model-id>', NetQ.asic_match, True)
    cli.add_tab_complete_hook('<asic-vendor>', NetQ.asic_vendor_complete)
    cli.add_tag_matcher('<disk-name>', NetQ.disk_match, True)
    cli.add_tab_complete_hook('<disk-name>', NetQ.disk_name_complete)
    cli.add_tag_matcher('<disk-size>', NetQ.disk_match, True)
    cli.add_tab_complete_hook('<disk-size>', NetQ.disk_size_complete)
    cli.add_tag_matcher('<disk-transport>', NetQ.disk_match, True)
    cli.add_tab_complete_hook('<disk-transport>', NetQ.disk_transport_complete)
    cli.add_tag_matcher('<disk-vendor>', NetQ.disk_match, True)
    cli.add_tab_complete_hook('<disk-vendor>', NetQ.disk_vendor_complete)
    cli.add_tag_matcher('<memory-type>', NetQ.memory_match, True)
    cli.add_tab_complete_hook('<memory-type>', NetQ.memory_type_complete)
    cli.add_tag_matcher('<memory-size>', NetQ.memory_match, True)
    cli.add_tab_complete_hook('<memory-size>', NetQ.memory_size_complete)
    cli.add_tag_matcher('<memory-vendor>', NetQ.memory_match, True)
    cli.add_tab_complete_hook('<memory-vendor>', NetQ.memory_vendor_complete)
    cli.add_tab_complete_hook('<asic-model>', NetQ.asic_model_complete)
    cli.add_tab_complete_hook('<asic-model-id>', NetQ.asic_model_id_complete)
    cli.add_tag_matcher('<interface-nexthop>', NetQ.interface_match, True)
    cli.add_tab_complete_hook('<interface-nexthop>', NetQ.interface_complete)
    cli.add_tag_matcher('<text-service-name>', NetQ.generic_match, True)
    cli.add_tag_matcher('<inventory-search>', NetQ.generic_match, True)
    cli.add_tag_matcher('<ip-server>', NetQ.ip_server_match, True)
    cli.add_tag_matcher('<text-server>', NetQ.generic_match, True)
    cli.add_tab_complete_hook('<vrf>', NetQ.vrf_complete)
    cli.add_tag_matcher('<vrf>', NetQ.vrf_match, True)

    try:
        if print_options:
            cli.print_options(ended_with_space)
        else:
            cli.run(argv=[sys.argv[0]] + (sys.argv[1:] or ['check',
                                                           'agents']))
            out = _run(cli)
            if _JSON:
                print json.dumps(_JSON)
            elif _JSON is not None:
                print _EMPTY_JSON
            return out
    except Exception as ex:
        if isinstance(ex, IOError):
            if str(ex).lower() == 'broken pipe':
                return 1
            try:
                sys.stdout.close()
            except IOError:
                pass
            try:
                sys.stderr.close()
            except IOError:
                pass
            return 1
        else:
            syslog.openlog(logoption=syslog.LOG_PID)
            syslog.syslog(syslog.LOG_ERR, 'Error: %s\n' %str(ex))
            if isinstance(ex, RuntimeError):
                syslog.syslog(syslog.LOG_ERR, traceback.format_exc())
            if sys.argv[-1] == 'json':
                print '[{\"error\": \"%s\"}]' %str(ex)
            else:
                print utils.color_wrap(BgColors.RED, '%s\n' %str(ex))
        return 1

# Add these back when you have it working
# '''
#    netq [server <ip-server>|server <text-server>] check (mtu|vlan) [<hostname>] [unverified] [around <text-time>] [json]
#    netq [server <ip-server>|server <text-server>] check (mtu|vlan) <hostname> [<remote-interface>] [unverified] [around <text-time>] [json]
#    netq [server <ip-server>|server <text-server>] show info (<ip>|<ip/prefixlen>|<mac>|<hostname>|<text-asn>|<text-vlan>)
#    netq [server <ip-server>|server <text-server>] show info (<ip>|<ip/prefixlen>|<mac>|<hostname>|<text-asn>|<text-vlan>) around <text-time>
# '''
