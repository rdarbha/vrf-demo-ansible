# vim: tabstop=4 shiftwidth=4 softtabstop=4
# Copyright 2016 Cumulus Networks, Inc. All rights reserved.
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc.
# 51 Franklin Street, Fifth Floor
# Boston, MA  02110-1301, USA.
"""ROM models
"""
import inspect
import time

from netq.orm import objects, HOSTNAME
from netq.orm.memdb.models import MemModel
from netq.orm.redisdb import scripts, Connection
from netq.orm.redisdb.query import RedisQuery


class _RedisModel(objects.Model):
    __memmodel = None
    query_cls = RedisQuery
    active = objects.Boolean(json_key='active')
    hostname = objects.String(json_key='hostname')
    timestamp = objects.Float(json_key='timestamp')
    deleted = objects.Boolean(json_key='deleted')

    def __init__(self):
        self.active = True
        self.deleted = False
        self.hostname = HOSTNAME
        self.timestamp = time.time()
        super(_RedisModel, self).__init__()

    @staticmethod
    def _get_connection_object(commit):
        if commit:
            return Connection.REDIS
        else:
            return Connection.PIPE

    def copy(self, src):
        for _, field in inspect.getmembers(self.__class__):
            if (isinstance(field, objects.Field) and
                    field.name != self.__class__.timestamp.name):
                src_attribute = getattr(src, field.name, None)
                if src_attribute is not None:
                    setattr(self, field.name, src_attribute)

    def delete(self, purge=False):
        if purge:
            score = self.__class__.obj_to_score(self.__dict__)
            Connection.PIPE.zremrangebyscore(
                self.__class__.obj_to_key(self.__dict__),
                min=score,
                max=score
            )
        else:
            obj = self.__class__()
            obj.copy(self)
            obj.active = False
            obj.deleted = True
            obj.save()

    @classmethod
    def exclude_fmt(cls):
        """Return the list of fields to ignore when doing a comparison to
        find the differences between two instances of an object.
        See BgpSession for an example usage"""
        return cls.timestamp, cls.active

    @classmethod
    def memmodel(cls):
        if cls.__memmodel is None:
            cls.__memmodel = type(cls.__name__, (MemModel, cls), {})
        return cls.__memmodel

    def save_entry(self, connection):

        cls = self.__class__
        mcls = cls.memmodel()
        key = cls.obj_to_key(self.__dict__)
        val = cls.obj_to_val(self.__dict__)
        score = cls.obj_to_score(self.__dict__)

        add = True
        delete = False
        old_obj = None

        if mcls is not None:
            old_objs = (
                list(mcls.query.range(start=0, end=10000, first=False,
                                      keys=[key]))
            )
            if old_objs:
                old_obj = old_objs[-1]

                if self.equals(old_obj):
                    if old_obj.active == self.active:
                        add = False
                    elif self.active and len(old_objs) >= 2:
                        delete = True

                for obj in old_objs[:-2]:
                    obj.delete_object()

        if delete:
            del_score = cls.obj_to_score(old_obj.__dict__)
            mcls.delete(key, del_score)
            connection.zremrangebyscore(key, del_score, del_score)
        elif add:
            mcls.save(key, score, val)
            connection.zadd(key, score, val)

    @classmethod
    def key_fmt(cls, key_type=None):
        raise NotImplementedError

    @classmethod
    def score_fmt(cls, key_type=None):
        raise NotImplementedError

    @classmethod
    def val_fmt(cls):
        raise NotImplementedError

class Address(_RedisModel):
    ifname = objects.String(json_key='ifName')
    prefix = objects.String(json_key='prefix')
    mask = objects.Integer(json_key='mask')
    is_ipv6 = objects.Boolean(json_key='isIPv6')

    @classmethod
    def key_fmt(cls, key_type=None):
        return (cls.__name__, cls.hostname, cls.ifname, cls.prefix,
                cls.mask, cls.is_ipv6)

    @classmethod
    def score_fmt(cls, key_type=None):
        return cls.timestamp

    @classmethod
    def val_fmt(cls):
        return cls.timestamp, cls.active, cls.deleted

    def save(self, commit=False):
        connection = self._get_connection_object(commit)
        super(Address, self).save_entry(connection)


class BgpSession(_RedisModel):
    """Store BGP Session specific info
    """
    peer_name = objects.String(json_key='peerName')
    state = objects.String(json_key='peerState')
    peer_router_id = objects.String(json_key='bgpRouterId')
    peer_asn = objects.Integer(json_key='peerAsn')
    peer_hostname = objects.String(json_key='peerHostname')
    asn = objects.Integer(json_key='bgpAsn')
    reason = objects.String(json_key='reason')
    ipv4_pfx_rcvd = objects.Integer(json_key='ipv4PrefixRx')
    ipv6_pfx_rcvd = objects.Integer(json_key='ipv6PrefixRx')
    last_reset_time = objects.Long(json_key='lastResetTime')
    up_time = objects.Long(json_key='upTime')
    conn_estd = objects.Integer(json_key='connEstd')
    conn_dropped = objects.Integer(json_key='connDropped')
    upd8_rx = objects.Integer(json_key='upd8Rx')
    upd8_tx = objects.Integer(json_key='upd8Tx')
    vrfid = objects.Integer(json_key='vrfId')
    vrf = objects.String(json_key='vrfName')

    @classmethod
    def exclude_fmt(cls):
        return (cls.timestamp, cls.active, cls.last_reset_time, cls.up_time,
                cls.upd8_tx, cls.upd8_rx)

    @classmethod
    def key_fmt(cls, key_type=None):
        return cls.__name__, cls.hostname, cls.peer_name, cls.asn, cls.vrf

    @classmethod
    def score_fmt(cls, key_type=None):
        return cls.timestamp

    @classmethod
    def val_fmt(cls):
        return (cls.state, cls.peer_router_id, cls.peer_asn, cls.peer_hostname,
                cls.reason, cls.ipv4_pfx_rcvd, cls.ipv6_pfx_rcvd, cls.timestamp,
                cls.last_reset_time, cls.conn_estd, cls.conn_dropped,
                cls.upd8_rx, cls.vrfid, cls.upd8_tx, cls.up_time, cls.active,
                cls.deleted)

    def save(self, commit=False):
        connection = self._get_connection_object(commit)
        super(BgpSession, self).save_entry(connection)


class ClagSession(_RedisModel):
    role = objects.String(json_key='role')
    peer_role = objects.String(json_key='peerRole')
    peer_state = objects.Boolean(json_key='peerState')
    peer_if = objects.String(json_key='clagPeerIf')
    clag_sysmac = objects.String(json_key='sysMac')
    backup_ip_active = objects.Boolean(json_key='backupIpActive')
    backup_ip = objects.String(json_key='backupIp')
    single_bonds = objects.Json(json_key='singleBonds')
    dual_bonds = objects.Json(json_key='dualAttachedBonds')
    conflicted_bonds = objects.Json(json_key='conflictedBonds')
    proto_down_bonds = objects.Json(json_key='protoDownBonds')

    @classmethod
    def key_fmt(cls, key_type=None):
        return cls.__name__, cls.hostname, cls.clag_sysmac

    @classmethod
    def score_fmt(cls, key_type=None):
        return cls.timestamp

    @classmethod
    def val_fmt(cls):
        return (cls.peer_role, cls.role, cls.peer_state, cls.peer_if,
                cls.backup_ip, cls.backup_ip_active, cls.single_bonds,
                cls.dual_bonds, cls.timestamp, cls.conflicted_bonds,
                cls.proto_down_bonds, cls.active, cls.deleted)

    def save(self, commit=False):
        connection = self._get_connection_object(commit)
        super(ClagSession, self).save_entry(connection)


class Command(_RedisModel):
    key = objects.String(json_key='key')
    output = objects.String(json_key='output')

    @classmethod
    def key_fmt(cls, key_type=None):
        return cls.__name__, cls.hostname, cls.key

    @classmethod
    def score_fmt(cls, key_type=None):
        return cls.timestamp

    @classmethod
    def val_fmt(cls):
        return cls.output,

    def save(self, commit=False):
        connection = self._get_connection_object(commit)
        connection.zadd(Command.obj_to_key(self.__dict__),
                        Command.obj_to_score(self.__dict__),
                        Command.obj_to_val(self.__dict__))


class Counter(_RedisModel):
    ifname = objects.String(json_key='ifName')
    rx_bps = objects.Long(json_key='rxBps')
    rx_drop_bps = objects.Long(json_key='rxDropBps')
    rx_err_bps = objects.Long(json_key='rxErrBps')
    tx_bps = objects.Long(json_key='txBps')
    tx_drop_bps = objects.Long(json_key='txDropBps')
    tx_err_bps = objects.Long(json_key='txErrBps')

    TX_BPS = 0
    TX_DROP_BPS = 1
    TX_ERR_BPS = 2
    RX_BPS = 3
    RX_DROP_BPS = 4
    RX_ERR_BPS = 5
    KEYS = [RX_BPS, RX_DROP_BPS, RX_ERR_BPS, TX_BPS, TX_DROP_BPS, TX_ERR_BPS]

    @classmethod
    def key_fmt(cls, key_type=None):
        if key_type == cls.TX_BPS:
            return cls.__name__, cls.tx_bps.name
        elif key_type == cls.TX_DROP_BPS:
            return cls.__name__, cls.tx_drop_bps.name
        elif key_type == cls.TX_ERR_BPS:
            return cls.__name__, cls.tx_err_bps.name
        elif key_type == cls.RX_BPS:
            return cls.__name__, cls.rx_bps.name
        elif key_type == cls.RX_DROP_BPS:
            return cls.__name__, cls.rx_drop_bps.name
        elif key_type == cls.RX_ERR_BPS:
            return cls.__name__, cls.rx_err_bps.name
        else:
            raise RuntimeError('Invalid key type %s' % key_type)

    @classmethod
    def score_fmt(cls, key_type=None):
        key_type = key_type or cls.TX_BPS
        if key_type == cls.TX_BPS:
            return cls.tx_bps
        elif key_type == cls.TX_DROP_BPS:
            return cls.tx_drop_bps
        elif key_type == cls.TX_ERR_BPS:
            return cls.tx_err_bps
        elif key_type == cls.RX_BPS:
            return cls.rx_bps
        elif key_type == cls.RX_DROP_BPS:
            return cls.rx_drop_bps
        elif key_type == cls.RX_ERR_BPS:
            return cls.rx_err_bps

    @classmethod
    def val_fmt(cls):
        return cls.hostname, cls.ifname

    def save(self, commit=False):
        connection = self._get_connection_object(commit)
        intf_key = Counter.obj_to_val(self.__dict__)
        for key in self.KEYS:
            connection.zadd(Counter.obj_to_key(self.__dict__,
                                               key_type=key),
                            Counter.obj_to_score(self.__dict__,
                                                 key_type=key),
                            intf_key)


class CounterHistory(Counter):
    data = objects.Json(json_key='data')

    @classmethod
    def key_fmt(cls, key_type=None):
        return cls.__name__, Counter.key_fmt(key_type)[1]

    @classmethod
    def score_fmt(cls, key_type=None):
        return cls.timestamp

    @classmethod
    def val_fmt(cls):
        return cls.data,

    def save(self, commit=False):
        connection = self._get_connection_object(commit)
        keys = []
        args = [time.time()]
        scores = []
        for key in self.KEYS:
            keys.append(Counter.obj_to_key(self.__dict__, key_type=key))
            args.append(CounterHistory.obj_to_key(self.__dict__,
                                                  key_type=key))
            scores.append(Counter.score_fmt(key_type=key).name)
        args.extend(scores)
        scripts.update_counters_script(keys=keys, args=args, client=connection)


class Link(_RedisModel):
    ifname = objects.String(json_key='ifName')
    ifindex = objects.Integer(json_key='ifIndex')
    mac_address = objects.MacAddress(json_key='macAddress')
    admin_state = objects.String(json_key='adminState')
    oper_state = objects.String(json_key='operState')
    managed = objects.Boolean(json_key='managed')
    kind = objects.String(json_key='kind')
    mtu = objects.Integer(json_key='mtu')
    master = objects.String(json_key='master')
    is_vlan_filtering = objects.Boolean(json_key='isVlanFiltering')
    vlans = objects.String(json_key='vlans')
    access_vlan = objects.Integer(json_key='accessVlan')
    dstport = objects.Integer(json_key='dstPort')
    localip = objects.String(json_key='localIp')
    vni = objects.Integer(json_key='vni')
    vrf = objects.String(json_key='vrfName')
    rt_table_id = objects.Integer(json_key='routeTableId')
    parent_if = objects.String(json_key='parentIf')

    @classmethod
    def key_fmt(cls, key_type=None):
        """We need to query sometimes by VNI and so we stick VNI in the key.
        Its 0 for anything but Vxlan.
        """
        return (cls.__name__, cls.hostname, cls.ifname, cls.kind, cls.vni,
                cls.master)

    @classmethod
    def score_fmt(cls, key_type=None):
        return cls.timestamp

    @classmethod
    def val_fmt(cls):
        return (cls.admin_state, cls.oper_state, cls.managed, cls.mtu,
                cls.ifindex, cls.is_vlan_filtering, cls.timestamp,
                cls.vlans, cls.access_vlan, cls.localip,
                cls.vrf, cls.rt_table_id, cls.parent_if,
                cls.mac_address, cls.dstport, cls.active, cls.deleted)

    def save(self, commit=False):
        connection = self._get_connection_object(commit)
        super(Link, self).save_entry(connection)


class MacFdb(_RedisModel):
    mac_address = objects.MacAddress(json_key='macAddress')
    origin = objects.Boolean(json_key='origin')
    nexthop = objects.String(json_key='nextHop')
    vlan = objects.Integer(json_key='vlan')
    dst = objects.String(json_key='dst')
    port = objects.String(json_key='port')

    @classmethod
    def key_fmt(cls, key_type=None):
        return cls.__name__, cls.hostname, cls.mac_address, cls.vlan

    @classmethod
    def score_fmt(cls, key_type=None):
        return cls.timestamp

    @classmethod
    def val_fmt(cls):
        return (cls.origin, cls.nexthop, cls.dst, cls.port, cls.timestamp,
                cls.active, cls.deleted)

    def save(self, commit=False):
        connection = self._get_connection_object(commit)
        super(MacFdb, self).save_entry(connection)


class MstpInfo(_RedisModel):
    """Store MSTP non-port-specific info for troubleshooting
    """
    bridge_name = objects.String(json_key='bridgeName')
    state = objects.Boolean(json_key='state')
    root_port_name = objects.String(json_key='rootPortName')
    root_bridge = objects.String(json_key='rootBridge')
    topo_chg_ports = objects.Json(json_key='topoChangePort')
    time_since_tcn = objects.Long(json_key='timeSinceLastTcn')
    topo_chg_cntr = objects.Long(json_key='toptChangeCntr')
    bridge_id = objects.String(json_key='bridgeId')
    edge_ports = objects.Json(json_key='edgePorts')
    network_ports = objects.Json(json_key='networkPorts')
    disputed_ports = objects.Json(json_key='disputedPorts')
    bpduguard_ports = objects.Json(json_key='bpduguardPorts')
    bpduguard_err_ports = objects.Json(json_key='bpduguardErrPorts')
    ba_inconsistent_ports = objects.Json(json_key='baInconsistentPorts')
    bpdufilter_ports = objects.Json(json_key='bpdufilterPorts')
    is_vlan_filtering = objects.Boolean(json_key='isVlanFiltering')
    ports = objects.Json(json_key='ports')

    @classmethod
    def exclude_fmt(cls):
        return cls.timestamp, cls.active, cls.time_since_tcn

    @classmethod
    def key_fmt(cls, key_type=None):
        return cls.__name__, cls.hostname, cls.bridge_name

    @classmethod
    def score_fmt(cls, key_type=None):
        return cls.timestamp

    @classmethod
    def val_fmt(cls):
        return (cls.root_port_name, cls.topo_chg_ports, cls.time_since_tcn,
                cls.topo_chg_cntr, cls.ports, cls.edge_ports, cls.state,
                cls.network_ports, cls.disputed_ports, cls.bpduguard_ports,
                cls.root_bridge, cls.bridge_id, cls.bpduguard_err_ports,
                cls.ba_inconsistent_ports, cls.bpdufilter_ports,
                cls.is_vlan_filtering, cls.active, cls.deleted,
                cls.timestamp)

    def save(self, commit=False):
        connection = self._get_connection_object(commit)
        super(MstpInfo, self).save_entry(connection)


class OspfNbr(_RedisModel):
    peer_id = objects.String(json_key='peerId')
    peer_addr = objects.String(json_key='peerAddress')
    state = objects.String(json_key='state')
    ifname = objects.String(json_key='ifName')
    is_ipv6 = objects.String(json_key='isIPv6')

    @classmethod
    def key_fmt(cls, key_type=None):
        return cls.__name__, cls.hostname, cls.peer_id

    @classmethod
    def score_fmt(cls, key_type=None):
        return cls.timestamp

    @classmethod
    def val_fmt(cls):
        return (cls.state, cls.timestamp, cls.ifname, cls.is_ipv6,
                cls.peer_addr, cls.active, cls.deleted)

    def save(self, commit=False):
        connection = self._get_connection_object(commit)
        super(OspfNbr, self).save_entry(connection)


class OspfIf(_RedisModel):
    ifname = objects.String(json_key='ifName')
    is_unnumbered = objects.Boolean(json_key='isUnnumbered')
    area = objects.String(json_key='area')
    network_type = objects.String(json_key='networkType')
    nbr_count = objects.Integer(json_key='nbrCount')
    nbr_adj_count = objects.Integer(json_key='nbrAdjCount')
    cost = objects.Integer(json_key='cost')
    is_passive = objects.Boolean(json_key='isPassive')

    @classmethod
    def key_fmt(cls, key_type=None):
        return cls.__name__, cls.ifname, cls.area

    @classmethod
    def score_fmt(cls, key_type=None):
        return cls.timestamp

    @classmethod
    def val_fmt(cls):
        return (cls.network_type, cls.timestamp, cls.nbr_count,
                cls.nbr_adj_count, cls.is_unnumbered, cls.is_passive, cls.cost,
                cls.active, cls.deleted)

    def save(self, commit=False):
        connection = self._get_connection_object(commit)
        super(OspfIf, self).save_entry(connection)


class Neighbor(_RedisModel):
    ifname = objects.String(json_key='ifName')
    ifindex = objects.Integer(json_key='ifIndex')
    ip_address = objects.String(json_key='ipAddress')
    mac_address = objects.MacAddress(json_key='macAddress')
    is_ipv6 = objects.Boolean(json_key='isIPv6')

    @classmethod
    def key_fmt(cls, key_type=None):
        return (cls.__name__, cls.hostname, cls.ifname,
                cls.ip_address, cls.mac_address, cls.is_ipv6)

    @classmethod
    def score_fmt(cls, key_type=None):
        return cls.timestamp

    @classmethod
    def val_fmt(cls):
        return cls.ifindex, cls.timestamp, cls.active, cls.deleted

    def save(self, commit=False):
        connection = self._get_connection_object(commit)
        super(Neighbor, self).save_entry(connection)


class Node(_RedisModel):
    lastboot = objects.Float(json_key='lastBoot')

    def __str__(self):
        return self.hostname

    @classmethod
    def key_fmt(cls, key_type=None):
        return cls.__name__, cls.hostname

    @classmethod
    def score_fmt(cls, key_type=None):
        return cls.timestamp

    @classmethod
    def val_fmt(cls):
        return cls.lastboot,

    def save(self, commit=False):
        connection = self._get_connection_object(commit)
        key = Node.obj_to_key(self.__dict__)
        score = Node.obj_to_score(self.__dict__)
        val = Node.obj_to_val(self.__dict__)
        connection.zadd(key, score, val)


class Route(_RedisModel):
    prefix = objects.String(json_key='prefix')
    protocol = objects.String(json_key='protocol')
    route_type = objects.Integer(json_key='routeType')
    origin = objects.Boolean(json_key='origin')
    nexthops = objects.Json(json_key='nextHops')
    src = objects.String(json_key='src')
    is_ipv6 = objects.Boolean(json_key='isIPv6')
    rt_table_id = objects.Integer(json_key='routeTableId')

    @classmethod
    def key_fmt(cls, key_type=None):
        # The exact sequence of key fields here is assumed in the lpm LUA script
        # Do not change one without changing the other
        return (cls.__name__, cls.hostname, cls.prefix, cls.route_type,
                cls.rt_table_id, cls.is_ipv6, cls.origin, cls.protocol)

    @classmethod
    def score_fmt(cls, key_type=None):
        return cls.timestamp

    @classmethod
    def val_fmt(cls):
        return (cls.nexthops, cls.src, cls.timestamp, cls.active, cls.deleted)

    def save(self, commit=False):
        connection = self._get_connection_object(commit)
        super(Route, self).save_entry(connection)


class Services(_RedisModel):
    name = objects.String(json_key='name')
    is_enabled = objects.Boolean(json_key='isEnabled')
    is_active = objects.Boolean(json_key='isActive')
    is_monitored = objects.Boolean(json_key='isMonitored')
    is_failed = objects.Boolean(json_key='isFailed')

    @classmethod
    def key_fmt(cls, key_type=None):
        return cls.__name__, cls.hostname, cls.name

    @classmethod
    def score_fmt(cls, key_type=None):
        return cls.timestamp

    @classmethod
    def val_fmt(cls):
        return (cls.is_active, cls.is_enabled, cls.is_monitored, cls.is_failed,
                cls.active, cls.timestamp, cls.deleted)

    def save(self, commit=False):
        connection = self._get_connection_object(commit)
        super(Services, self).save_entry(connection)


class OS(_RedisModel):
    name = objects.String(json_key='name')
    version = objects.String(json_key='version')
    version_id = objects.String(json_key='version_id')

    @classmethod
    def key_fmt(cls, key_type=None):
        return cls.__name__, cls.hostname, cls.name, cls.version, cls.version_id

    @classmethod
    def score_fmt(cls, key_type=None):
        return cls.timestamp

    @classmethod
    def val_fmt(cls):
        return (cls.timestamp,)

    def save(self, commit=False):
        connection = self._get_connection_object(commit)
        super(OS, self).save_entry(connection)

class CPU(_RedisModel):
    arch = objects.String(json_key='arch')
    nos = objects.String(json_key='nos')
    model = objects.String(json_key='model')
    max_freq = objects.String(json_key='max_freq')
    mem_total = objects.String(json_key='mem_total')

    @classmethod
    def key_fmt(cls, key_type=None):
        return (cls.__name__, cls.hostname, cls.arch, cls.nos, cls.model,
                cls.max_freq, cls.mem_total)

    @classmethod
    def score_fmt(cls, key_type=None):
        return cls.timestamp

    @classmethod
    def val_fmt(cls):
        return (cls.timestamp,)

    def save(self, commit=False):
        connection = self._get_connection_object(commit)
        super(CPU, self).save_entry(connection)

class ASIC(_RedisModel):
    vendor = objects.String(json_key='vendor')
    model = objects.String(json_key='model')
    model_id = objects.String(json_key='model_id')
    core_bw = objects.String(json_key='core_bw')
    ports = objects.String(json_key='ports')

    @classmethod
    def key_fmt(cls, key_type=None):
        return (cls.__name__, cls.hostname, cls.vendor, cls.model, cls.model_id,
                cls.core_bw, cls.ports)

    @classmethod
    def score_fmt(cls, key_type=None):
        return cls.timestamp

    @classmethod
    def val_fmt(cls):
        return (cls.timestamp,)

    def save(self, commit=False):
        connection = self._get_connection_object(commit)
        super(ASIC, self).save_entry(connection)

class Disk(_RedisModel):
    name = objects.String(json_key='name')
    size = objects.String(json_key='size')
    d_type = objects.String(json_key='d_type')
    vendor = objects.String(json_key='vendor')
    transport = objects.String(json_key='transport')
    rev = objects.String(json_key='rev')
    model = objects.String(json_key='model')

    @classmethod
    def key_fmt(cls, key_type=None):
        return (cls.__name__, cls.hostname, cls.name, cls.size, cls.d_type,
                cls.vendor, cls.transport, cls.rev, cls.model)

    @classmethod
    def score_fmt(cls, key_type=None):
        return cls.timestamp

    @classmethod
    def val_fmt(cls):
        return (cls.timestamp,)

    def save(self, commit=False):
        connection = self._get_connection_object(commit)
        super(Disk, self).save_entry(connection)

class Board(_RedisModel):
    vendor = objects.String(json_key='vendor')
    model = objects.String(json_key='model')
    base_mac = objects.String(json_key='base_mac')
    part_number = objects.String(json_key='part_number')
    mfg_date = objects.String(json_key='mfg_date')
    serial_number = objects.String(json_key='serial_number')
    label_revision = objects.String(json_key='label_revision')

    @classmethod
    def key_fmt(cls, key_type=None):
        return (cls.__name__, cls.hostname, cls.vendor, cls.model, cls.base_mac,
                cls.part_number, cls.mfg_date, cls.serial_number,
                cls.label_revision)

    @classmethod
    def score_fmt(cls, key_type=None):
        return cls.timestamp

    @classmethod
    def val_fmt(cls):
        return (cls.timestamp,)

    def save(self, commit=False):
        connection = self._get_connection_object(commit)
        super(Board, self).save_entry(connection)

class Memory(_RedisModel):
    vendor = objects.String(json_key='vendor')
    size = objects.String(json_key='size')
    speed = objects.String(json_key='speed')
    name = objects.String(json_key='name')
    m_type = objects.String(json_key='m_type')
    serial_number = objects.String(json_key='serial_number')

    @classmethod
    def key_fmt(cls, key_type=None):
        return (cls.__name__, cls.hostname, cls.name, cls.size, cls.speed, cls.m_type,
                cls.vendor, cls.serial_number)

    @classmethod
    def score_fmt(cls, key_type=None):
        return cls.timestamp

    @classmethod
    def val_fmt(cls):
        return (cls.timestamp,)

    def save(self, commit=False):
        connection = self._get_connection_object(commit)
        super(Memory, self).save_entry(connection)
