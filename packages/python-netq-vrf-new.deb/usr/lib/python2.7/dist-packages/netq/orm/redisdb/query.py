# vim: tabstop=4 shiftwidth=4 softtabstop=4
# Copyright 2016 Cumulus Networks, Inc. All rights reserved.
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc.
# 51 Franklin Street, Fifth Floor
# Boston, MA  02110-1301, USA.
"""ROM queries
"""
import re
import time

from netq.orm.objects import Model
from netq.orm.query import Query, Q
from netq.orm.redisdb import Connection, scripts

class RedisQuery(Query):
    """
    """
    __LUA_MAGIC_CHARACTERS = ['(', ')', '.', '%', '+', '-', '*', '?', '[',
                              '^', '$']
    PAGE_SIZE = 100

    WILDCARD = '*'

    def __init__(self, cls):
        self.__cls = cls

    def __escape_kwargs(self, kwargs):
        escape_kwargs = {}
        for key, kwarg in kwargs.iteritems():
            new_kwarg = []
            for token in re.split(
                    '(\W)', #pylint: disable=anomalous-backslash-in-string
                    str(kwarg)):
                if token in self.__LUA_MAGIC_CHARACTERS:
                    new_kwarg.append('%' + token)
                else:
                    new_kwarg.append(token)
            escape_kwargs[key] = ''.join(new_kwarg)
        return escape_kwargs

    def __range(self, rangeapi, key_type=None, start=-1, end=-1, first=True,
                active=None, **kwargs):
        for key, val, score in self.__scan_iter(kwargs, key_type=key_type,
                                                rangeapi=rangeapi, start=start,
                                                end=end, first=first):
            obj = self.__cls.key_to_obj(key, key_type=key_type)
            obj = self.__cls.val_to_obj(val, obj=obj)
            if active is not None and obj.active != active:
                continue
            yield self.__cls.score_to_obj(score, obj=obj, key_type=key_type)

    def __scan_iter(self, kwargs, key_type=None, rangeapi='zrange',
                    start=-1, end=-1, first=True, count=PAGE_SIZE):
        exclude = kwargs.pop('exclude', None)
        match = self.__cls.obj_to_key(kwargs, wildcard=self.WILDCARD,
                                      key_type=key_type)
        nmatch = '.*'
        if isinstance(exclude, Q):
            nmatch = '^%s$' % self.__cls.obj_to_key(
                self.__escape_kwargs(exclude.kwargs),
                wildcard='.*',
                key_type=exclude.key_type
            )
        keys = [match, nmatch, 0]
        if count is not None:
            keys.append(count)
        args = [rangeapi, start, end, int(first)]
        cursor = None
        while cursor != 0:
            cursor, data = scripts.scanregex_script(keys=keys, args=args)
            keys[2] = cursor
            for key, val, score in data:
                yield key, val, score

    def all(self, key_type=None, timestamp=None):
        if timestamp is None:
            for key, val, score in self.__scan_iter({}, key_type=key_type):
                obj = self.__cls.key_to_obj(key, key_type=key_type)
                obj = self.__cls.val_to_obj(val, obj=obj)
                # Only return entries that are present
                if not obj.active:
                    continue
                if score is not None:
                    obj = self.__cls.score_to_obj(score, obj=obj,
                                                  key_type=key_type)
                yield obj
        else:
            for ele in self.rangebyscore(start=timestamp,
                                         end=0,
                                         key_type=key_type,
                                         first=True,
                                         active=True,
                                         reverse=True):
                yield ele

    @staticmethod
    def count(keys):
        return scripts.count_script(keys=keys, args=[])

    def delete(self, key_type=None, purge=False, **kwargs):
        match = self.__cls.obj_to_key(kwargs,
                                      wildcard=self.WILDCARD,
                                      key_type=key_type)
        keys = scripts.keys_script(keys=[match], args=[])
        if keys:
            scorestr = "{:.2f}".format(time.time())
            score = float(scorestr)
            ret = scripts.delregex_script(keys=keys, args=[score, purge])
            mcls = self.__cls.memmodel()
            mcls.flush()
            if mcls is not None:
                for key, score, val in ret:
                    mcls.save(key, score, val)

    def filter(self, key_type=None, timestamp=None, endtimestamp=None,
               **kwargs):
        if timestamp is None:
            for key, val, score in self.__scan_iter(kwargs,
                                                    key_type=key_type):
                obj = self.__cls.key_to_obj(key, key_type=key_type)
                obj = self.__cls.val_to_obj(val, obj=obj)
                # Only return entries that are present
                if not obj.active:
                    continue
                if score is not None:
                    obj = self.__cls.score_to_obj(score, obj=obj,
                                                  key_type=key_type)
                yield obj
        elif endtimestamp is None:
            for entry in self.rangebyscore(start=timestamp,
                                           end=0,
                                           key_type=key_type,
                                           reverse=True,
                                           first=True,
                                           active=True,
                                           **kwargs):
                yield entry
        else:
            new = list(self.rangebyscore(start=timestamp,
                                         end=0,
                                         key_type=key_type,
                                         reverse=True,
                                         first=True,
                                         **kwargs))
            old = list(self.rangebyscore(start=endtimestamp,
                                         end=0,
                                         key_type=key_type,
                                         reverse=True,
                                         first=True,
                                         **kwargs))
            diff = []
            for ele in new:
                old_ele = next((item for item in old
                                if item.signature() == ele.signature()), None)
                if old_ele is not None and ele.equals(
                        old_ele, exclude=(ele.__class__.timestamp,)):
                    continue
                diff.append((ele, old_ele))
            for ele, old_ele in diff:
                if ele.active and (old_ele is None or not old_ele.active):
                    yield ele
            yield None
            for ele, old_ele in diff:
                if ele.active and (old_ele is not None and old_ele.active):
                    yield ele
                    yield old_ele
            yield None
            for ele, old_ele in diff:
                if (not ele.active and
                        (old_ele is not None and old_ele.active)):
                    yield ele

    def keys(self, key_type=None, **kwargs):
        match = self.__cls.obj_to_key(kwargs, wildcard=self.WILDCARD,
                                      key_type=key_type)
        return Connection.REDIS.keys(match)

    def lpm(self, prefix, hostnames, table, timestamp=None, is_ipv6=False):
        keys = hostnames
        if table != '*':
            object_dict = {
                self.__cls.prefix.name: prefix + '*',
                self.__cls.rt_table_id.name: table,
            }
        else:
            object_dict = {
                self.__cls.prefix.name: prefix + '*',
            }
        match = self.__cls.obj_to_key(object_dict,
                                      wildcard=RedisQuery.WILDCARD)
        args = [match,
                prefix.split('/')[0],
                timestamp or time.time(),
                int(is_ipv6),
                Model.SEPERATOR]
        ret = scripts.lpm_script(keys=keys, args=args)
        out = []
        for key, val, score in ret:
            obj = self.__cls.key_to_obj(key)
            obj = self.__cls.val_to_obj(val, obj=obj)
            # Only return entries that are present
            if not obj.active:
                continue
            out.append(self.__cls.score_to_obj(score, obj=obj))
        return out

    def get(self, key_type=None, timestamp=None, **kwargs):
        return next(self.filter(timestamp=timestamp, key_type=key_type,
                                **kwargs), None)

    def latest(self, key_type=None, **kwargs):
        return next(self.range(key_type=key_type, start=-1, end=-1, **kwargs),
                    None)

    def range(self, key_type=None, reverse=False, start=-1, end=-1,
              first=True, **kwargs):
        rangeapi = 'ZREVRANGE' if reverse else 'ZRANGE'
        for obj in self.__range(rangeapi, key_type=key_type, start=start,
                                end=end, first=first, **kwargs):
            yield obj

    def rangebyscore(self, key_type=None, reverse=False, start=-1, end=-1,
                     first=True, **kwargs):
        rangeapi = 'ZREVRANGEBYSCORE' if reverse else 'ZRANGEBYSCORE'
        for obj in self.__range(rangeapi, key_type=key_type, start=start,
                                end=end, first=first, **kwargs):
            yield obj
